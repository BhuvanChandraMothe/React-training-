import React, { useEffect, useState } from "react";
import AppCardShimmer from "./components/AppCardShimmer";
import AppCard from "./components/AppCard";
import ConfiguredCard from "./components/ConfiguredCard";
import { Row, Col, InputGroup, Form } from "react-bootstrap";
import "./index.css";
import { FaSearch } from "react-icons/fa";
import { get } from "../../../api/io";

const ModelsComponent = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [models, setModels] = useState([]);
  const [configuredModels, setConfiguredModels] = useState([]);
  const [configuredSearchTerm, setConfiguredSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchModels = async () => {
    try {
      setLoading(true);
      const response = await get(
        "https://api-dev.covasant.io/model-providers/"
      );
      setModels(response);
    } catch (error) {
      console.error("Error fetching model providers:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchModels();
  }, []);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleClearSearch = () => {
    setSearchTerm("");
  };

  const handleConfiguredSearchChange = (e) => {
    setConfiguredSearchTerm(e.target.value);
  };

  const handleClearConfiguredSearch = () => {
    setConfiguredSearchTerm("");
  };

  const handleAddToConfigured = (model) => {
    setConfiguredModels((prev) =>
      prev.find((c) => c.id === model.id) ? prev : [...prev, model]
    );
  };

  const handleRemoveConfigured = (model) => {
    setConfiguredModels((prev) => prev.filter((c) => c.id !== model.id));
  };

  const handleConfigureCard = (model) => {};

  const filteredModels = models.filter((model) => {
    if (!searchTerm.trim()) return true;
    return model.provider.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const filteredConfiguredModels = configuredModels.filter((model) => {
    if (!configuredSearchTerm.trim()) return true;
    return model.provider
      .toLowerCase()
      .includes(configuredSearchTerm.toLowerCase());
  });

  return (
    <div className="models-page">
      {configuredModels.length > 0 ? (
        <div className="px-4 pb-4 categories-nav">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <h3 className="mb-0">Configure Your Models</h3>
            <div className="search-container mt-2">
              <InputGroup>
                <Form.Control
                  placeholder="Search configured models..."
                  value={configuredSearchTerm}
                  onChange={handleConfiguredSearchChange}
                  className="search-input"
                />
                <InputGroup.Text
                  className="search-icon-wrapper"
                  onClick={configuredSearchTerm ? handleClearConfiguredSearch : undefined}
                  style={configuredSearchTerm ? { cursor: "pointer" } : {}}
                >
                  {configuredSearchTerm ? "×" : <FaSearch />}
                </InputGroup.Text>
              </InputGroup>
            </div>
          </div>
          <Row className="g-3">
            {filteredConfiguredModels.map((model) => (
              <Col xl={3} lg={4} md={6} sm={6} key={model.id}>
                <ConfiguredCard
                  model={model}
                  onConfigure={handleConfigureCard}
                  onRemove={handleRemoveConfigured}
                />
              </Col>
            ))}
          </Row>
        </div>
      ) : null}

      <div className="px-4 pt-2 pb-0">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h3 className="mb-0">Discover Models</h3>
          <div className="search-container mt-2">
            <InputGroup>
              <Form.Control
                placeholder="Search models..."
                value={searchTerm}
                onChange={handleSearchChange}
                className="search-input"
              />
              <InputGroup.Text
                className="search-icon-wrapper"
                onClick={searchTerm ? handleClearSearch : undefined}
                style={searchTerm ? { cursor: "pointer" } : {}}
              >
                {searchTerm ? "×" : <FaSearch />}
              </InputGroup.Text>
            </InputGroup>
          </div>
        </div>
        <p className="text-muted">
          Use these template models instantly or Add and manage your own
          models
        </p>
      </div>
      <div className="apps-grid px-4 pb-2">
        {loading ? (
          <Row className="g-3">
            {[...Array(6)].map((_, idx) => (
              <Col xl={3} lg={4} md={6} sm={6} key={idx}>
                <AppCardShimmer />
              </Col>
            ))}
          </Row>
        ) : filteredModels.length > 0 ? (
          <Row className="g-3">
            {filteredModels.map((model) => (
              <Col xl={3} lg={4} md={6} sm={6} key={model.id}>
                <AppCard
                  model={model}
                  onAddToConfigured={handleAddToConfigured}
                />
              </Col>
            ))}
          </Row>
        ) : (
          <div className="text-center py-5 empty-state">
            <div className="empty-icon mb-3">
              <FaSearch />
            </div>
            <h5>No models found</h5>
            <p className="text-muted">
              No models match your current filters.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ModelsComponent;
