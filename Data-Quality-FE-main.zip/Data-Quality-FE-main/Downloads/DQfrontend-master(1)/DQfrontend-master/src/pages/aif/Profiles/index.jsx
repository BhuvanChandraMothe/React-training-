import React, { useState, useEffect, useMemo } from "react";
import { Card, Row, Col, Badge, Button, Form, InputGroup, Table, Pagination, Modal } from "react-bootstrap";
// import { useAuthContext } from "../../../context/useAuthContext";
import Loader from "../../../components/Loader";
import PageTitle from "../../../components/PageTitle";
import { fetchDashboardSummary, getAllConnections, getForProfilingRunResults, getTableGroups, triggerProfiling } from "../../../api/dbapi";
import { useToaster } from "../../../Toaster/Toaster";
const ProfileRuns = () => {
  const [openModel, setModelOpen] = useState(false)
  // const { user } = useAuthContext();
  const [logs, setLogs] = useState([]);
  const [connections, setConnections] = useState([]);
  const [tableGroups, setTableGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingConnections, setLoadingConnections] = useState(false);
  const [loadingTableGroups, setLoadingTableGroups] = useState(false);
  const [expandedLogId, setExpandedLogId] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [filter, setFilter] = useState({
    service: "",
    action: "",
    status: "",
    dateRange: "all"
  });
  const { showToast } = useToaster();
  const [selectedConnection, setSelectedConnection] = useState('');
  const [selectedTableGroup, setSelectedTableGroup] = useState('');
  const [submitting, setSubmitting] = useState(false);
  useEffect(() => {
    if (open) {
      loadConnections();
    }
  }, [open]);

  useEffect(() => {
    if (!open) {
      setSelectedConnection('');
      setSelectedTableGroup('');
      setTableGroups([]);
    }
  }, [open]);


  const loadConnections = async () => {
    setLoadingConnections(true);
    try {
      const data = await getAllConnections();
      setConnections(data);
    } catch (error) {
      console.error('Failed to load connections:', error);
    } finally {
      setLoadingConnections(false);
    }
  };

  const loadTableGroups = async (connectionId) => {
    setLoadingTableGroups(true);
    try {
      const data = await getTableGroups(connectionId);
      setTableGroups(data);
    } catch (error) {
      console.error('Failed to load table groups:', error);
    } finally {
      setLoadingTableGroups(false);
    }
  };
  const handleTableGroupChange = (event) => {
    setSelectedTableGroup(event.target.value);
  };
  const handleConnectionChange = (event) => {
    const connId = event.target.value;
    setSelectedConnection(connId);
    setSelectedTableGroup('');
    loadTableGroups(connId);
  };


  const handleModalClose = () => {
    setModelOpen(false);
    setFormErrors({});
  };
  const [searchQuery, setSearchQuery] = useState("");

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortConfig, setSortConfig] = useState({ key: 'timestamp', direction: 'desc' });

  // Fetch logs data
  useEffect(() => {
    fetchConnections()

  }, []);
  const fetchConnections = async () => {
    try {
      setLoading(true);
      const data = await fetchDashboardSummary();
      setLogs(data.runs);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error("Error fetching connections:", error);
    }
  };
  const fetchProfileRunResults = async (item) => {
    try {
      setLoading(true);
      const data = await getForProfilingRunResults(item?.database_connection_id, item?.schema_table_group_uuid, item?.run_uuid);
      setTableDetails(data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error("Error fetching connections:", error);
    }
  };
  // Filter and search logs
  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      // Apply filters
      //   if (filter.service && log.service !== filter.service) return false;
      //   if (filter.action && log.action !== filter.action) return false;
      //   if (filter.status && log.status !== filter.status) return false;



      return true;
    });
  }, [logs, filter, searchQuery]);


  // Apply sorting
  const sortedLogs = useMemo(() => {
    const sorted = [...filteredLogs];
    if (sortConfig.key) {
      sorted.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sorted;
  }, [filteredLogs, sortConfig]);

  // Paged logs
  const pagedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedLogs.slice(start, start + pageSize);
  }, [sortedLogs, currentPage, pageSize]);

  // Total pages
  const totalPages = Math.ceil(sortedLogs.length / pageSize);

  // Handle sorting
  const handleSort = (key) => {
    setSortConfig(prevSortConfig => ({
      key,
      direction: prevSortConfig.key === key && prevSortConfig.direction === 'asc' ? 'desc' : 'asc'
    }));
  };



  // Render pagination controls
  const renderPagination = () => {
    return (
      <>

        <div className="d-flex justify-content-between align-items-center mt-3">
          <div>
            <Form.Select
              className="d-inline-block me-2"
              style={{ width: 'auto' }}
              value={pageSize}
              onChange={e => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
            >
              <option value={10}>10 rows</option>
              <option value={25}>25 rows</option>
              <option value={50}>50 rows</option>
            </Form.Select>
            <span className="text-muted">
              Showing {Math.min(sortedLogs.length, (currentPage - 1) * pageSize + 1)} to {Math.min(sortedLogs.length, currentPage * pageSize)} of {sortedLogs.length} entries
            </span>
          </div>

          <Pagination className="mb-0">
            <Pagination.First
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
            />
            <Pagination.Prev
              onClick={() => setCurrentPage(curr => Math.max(curr - 1, 1))}
              disabled={currentPage === 1}
            />

            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const pageNum = currentPage <= 3
                ? i + 1
                : currentPage >= totalPages - 2
                  ? totalPages - 4 + i
                  : currentPage - 2 + i;

              if (pageNum <= totalPages && pageNum > 0) {
                return (
                  <Pagination.Item
                    key={pageNum}
                    active={pageNum === currentPage}
                    onClick={() => setCurrentPage(pageNum)}
                  >
                    {pageNum}
                  </Pagination.Item>
                );
              }
              return null;
            })}

            <Pagination.Next
              onClick={() => setCurrentPage(curr => Math.min(curr + 1, totalPages))}
              disabled={currentPage === totalPages || totalPages === 0}
            />
            <Pagination.Last
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages || totalPages === 0}
            />
          </Pagination>
        </div>
      </>
    );
  };

  // Sort indicator
  const getSortIndicator = (key) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };
  const handleRunProfiling = async () => {
    const errors = {};

    if (!selectedConnection) {
      errors.selectedConnection = "Connection is required.";
    }

    if (!selectedTableGroup) {
      errors.selectedTableGroup = "Table group is required.";
    }
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    setFormErrors({});
    setSubmitting(true);

    try {
      const result = await triggerProfiling({
        connection_id: selectedConnection,
        table_group_id: selectedTableGroup,
      });
      showToast(`${result.message}`, "success", "");
    } catch (error) {
      console.error('Failed to trigger profiling:', error);
    } finally {
      setSubmitting(false);
      // setTimeout(() => {
      setLoading(false)
      setModelOpen(false)
      // }, 100);
      setSelectedConnection("")
      setSelectedTableGroup("")

    }
  };
  const [expandedRunId, setExpandedRunId] = useState(null);
  const [tableDetails, setTableDetails] = useState(null);
  const [loadingTableDetails, setLoadingTableDetails] = useState(false);
  const [errorTableDetails, setErrorTableDetails] = useState(null);
  const handleRowClick = (data) => {
    setExpandedRunId(prevId => prevId === data?.run_uuid ? null : data?.run_uuid);
    fetchProfileRunResults(data)
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "Complete":
        return <Badge bg="success">Complete</Badge>;
      case "failure":
        return <Badge bg="danger">Failure</Badge>;
      case "info":
        return <Badge bg="info">Info</Badge>;
      default:
        return <Badge bg="secondary">{status}</Badge>;
    }
  };
  return (
    <>
      <PageTitle
        breadCrumbItems={[
          { label: "Dashboard", path: "/aif/dashboard" },
          { label: "Profile Run Results", path: "/aif/logs", active: true },
        ]}
        title={"Profile Run Results"}
      />

      <Row>
        <Col>
          <Card>
            <Card.Body>
              {/* <h4 className="header-title mb-3">Profile Run Results</h4> */}

              <Row className="mb-3 mt-2">
                <Col md={9}>
                  <InputGroup>
                    <InputGroup.Text>
                      <i className="mdi mdi-magnify"></i>
                    </InputGroup.Text>
                    <Form.Control
                      placeholder="Search profile run Results..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </InputGroup>
                </Col>
                <Col md={3}>
                  <div className="d-flex justify-content-end">
                    <Button
                      variant="primary"
                      onClick={() => {
                        setModelOpen(true),
                          setFormErrors({});
                      }}
                    >
                      <i className="mdi mdi-plus me-1"></i>  New Run
                    </Button>
                  </div>
                </Col>
              </Row>

              {loading ? (
                <div className="d-flex justify-content-center my-5">
                  <Loader />
                </div>
              ) : (
                <>
                  {filteredLogs.length === 0 ? (
                    <div className="text-center py-5">
                      <i className="mdi mdi-file-search text-muted" style={{ fontSize: '3rem' }}></i>
                      <h5 className="mt-3">No connections found</h5>
                      <p className="text-muted">
                        Try adjusting your search or filter criteria
                      </p>
                      {/* <Button variant="light" onClick={handleResetFilters}>
                        Reset Filters
                      </Button> */}
                    </div>
                  ) : (
                    <>
                      {expandedLogId && (
                        <></>
                        // renderLogDetails(logs.find(log => log.id === expandedLogId))
                      )}

                      <div className="table-responsive">
                        <Table striped hover>
                          <thead>
                            <tr>
                              <th
                                className="sortable"
                                onClick={() => handleSort('connectionId')}
                                style={{ cursor: 'pointer' }}
                              >
                                Connection Id {getSortIndicator('connectionId')}
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort('connectionId')}
                                style={{ cursor: 'pointer' }}
                              >
                                Database Name {getSortIndicator('connectionId')}
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort('tablegrpid')}
                                style={{ cursor: 'pointer' }}
                              >
                                Table Group Name{getSortIndicator('tablegrpid')}
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort('schemaName')}
                                style={{ cursor: 'pointer' }}
                              >
                                Scheme Name {getSortIndicator('schemaName')}
                              </th>

                              <th
                                className="sortable"
                                onClick={() => handleSort('status')}
                                style={{ cursor: 'pointer' }}
                              >
                                Status {getSortIndicator('status')}
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort('createdAt')}
                                style={{ cursor: 'pointer' }}
                              >
                                Created At {getSortIndicator('createdAt')}
                              </th>

                            </tr>
                          </thead>
                          <tbody>
                            {pagedLogs.map(log => {
                              const isExpanded = expandedRunId === log.run_uuid;
                              return [
                                <tr key={log.database_connection_id} onClick={() => handleRowClick(log)} style={{ cursor: 'pointer', backgroundColor: isExpanded ? '#e9ecef' : 'inherit' }}>
                                  <td>{log.database_connection_id}</td>
                                  <td>{log.database_name}</td>
                                  <td>{log.table_group_name}</td>
                                  <td>{log.schema_name}</td>

                                  <td>{getStatusBadge(log.status)}</td>
                                  <td>{log?.run_display_id}</td>
                                </tr>,
                                isExpanded && (
                                  <tr key={`${log.run_uuid}-details`}>
                                    <td colSpan="6" className="bg-white">
                                      <Card className="mt-3 mb-3 p-3 shadow bg-white">
                                        {tableDetails.length > 0 && (
                                          <div style={{ overflowX: 'auto' }}>
                                            <div style={{ width: '1000px' }}>
                                              <table className="w-full text-sm border-collapse border border-gray-300">
                                                <thead>
                                                  <tr className="bg-gray-100">
                                                    <th className="border px-4 py-2">Table  Name</th>
                                                    <th className="border px-4 py-2">Column Name</th>
                                                    <th className="border px-4 py-2">Type</th>
                                                    <th className="border px-4 py-2">Average Length</th>
                                                    <th className="border px-4 py-2">Data Type Suggestion</th>
                                                    <th className="border px-4 py-2">Null Count</th>
                                                    <th className="border px-4 py-2">Distinct Values</th>
                                                    <th className="border px-4 py-2">Min Text</th>
                                                    <th className="border px-4 py-2">Max Text</th>
                                                    <th className="border px-4 py-2">Min Date</th>
                                                    <th className="border px-4 py-2">Max Date</th>
                                                    <th className="border px-4 py-2">Boolean True Count</th>
                                                    <th className="border px-4 py-2">Top patterns</th>
                                                    <th className="border px-4 py-2">Functional Data   Type</th>
                                                    <th className="border px-4 py-2">Functional Table   Type</th>
                                                  </tr>
                                                </thead>
                                                <tbody>
                                                  {tableDetails.map((col) => (
                                                    <tr key={col.id}>
                                                      <td className="border px-4 py-2">{col.table_name}</td>
                                                      <td className="border px-4 py-2">{col.column_name}</td>
                                                      <td className="border px-4 py-2">{col.column_type}</td>
                                                      <td className="border px-4 py-2">{col.avg_length}</td>
                                                      <td className="border px-4 py-2">{col.datatype_suggestion || '-'}</td>
                                                      <td className="border px-4 py-2">{col.null_value_ct ?? 0}</td>
                                                      <td className="border px-4 py-2">{col.distinct_value_ct ?? '-'}</td>
                                                      <td className="border px-4 py-2">{col.min_text ?? '-'}</td>
                                                      <td className="border px-4 py-2">{col.max_text ?? '-'}</td>
                                                      <td className="border px-4 py-2">{col.min_date?.slice(0, 10) || '-'}</td>
                                                      <td className="border px-4 py-2">{col.max_date?.slice(0, 10) || '-'}</td>
                                                      <td className="border px-4 py-2">{col.boolean_true_ct ?? '-'}</td>
                                                      <td className="border px-4 py-2">{col.top_patterns ?? '-'}</td>
                                                      <td className="border px-4 py-2">{col.functional_data_type ?? '-'}</td>
                                                      <td className="border px-4 py-2">{col.functional_table_type ?? '-'}</td>
                                                    </tr>
                                                  ))}
                                                </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        )}
                                      </Card>
                                    </td>
                                  </tr>

                                  // <tr key={`${log.run_uuid}-details`}>
                                  //   <td colSpan="6" className="bg-white">
                                  //     <Card className="mt-3 mb-3 p-3 shadow bg-white">
                                  //       {tableDetails.length > 0 && (
                                  //         <div style={{ maxHeight: '300px', overflow: 'auto' }}>
                                  //           <div style={{ width: '1000px' }}>
                                  //             <table className="table text-sm border-collapse border border-gray-300 w-100">
                                  //               <thead>
                                  //                 <tr className="bg-gray-100">
                                  //                   <th className="border px-4 py-2">Table Name</th>
                                  //                   <th className="border px-4 py-2">Column Name</th>
                                  //                   <th className="border px-4 py-2">Type</th>
                                  //                   <th className="border px-4 py-2">Average Length</th>
                                  //                   <th className="border px-4 py-2">Data Type Suggestion</th>
                                  //                   <th className="border px-4 py-2">Null Count</th>
                                  //                   <th className="border px-4 py-2">Distinct Values</th>
                                  //                   <th className="border px-4 py-2">Min Date</th>
                                  //                   <th className="border px-4 py-2">Max Text</th>
                                  //                   <th className="border px-4 py-2">Min Text</th>
                                  //                   <th className="border px-4 py-2">Max Date</th>
                                  //                   <th className="border px-4 py-2">Boolean True Count</th>
                                  //                   <th className="border px-4 py-2">Top Patterns</th>
                                  //                   <th className="border px-4 py-2">Functional Data Type</th>
                                  //                   <th className="border px-4 py-2">Functional Table Type</th>
                                  //                 </tr>
                                  //               </thead>
                                  //               <tbody>
                                  //                 {tableDetails.map((col) => (
                                  //                   <tr key={col.id}>
                                  //                     <td className="border px-4 py-2">{col.table_name}</td>
                                  //                     <td className="border px-4 py-2">{col.column_name}</td>
                                  //                     <td className="border px-4 py-2">{col.column_type}</td>
                                  //                     <td className="border px-4 py-2">{col.avg_length}</td>
                                  //                     <td className="border px-4 py-2">{col.datatype_suggestion || '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.null_value_ct ?? 0}</td>
                                  //                     <td className="border px-4 py-2">{col.distinct_value_ct ?? '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.min_date?.slice(0, 10) || '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.max_text ?? '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.min_text ?? '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.max_date?.slice(0, 10) || '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.boolean_true_ct ?? '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.top_patterns ?? '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.functional_data_type ?? '-'}</td>
                                  //                     <td className="border px-4 py-2">{col.functional_table_type ?? '-'}</td>
                                  //                   </tr>
                                  //                 ))}
                                  //               </tbody>
                                  //             </table>
                                  //           </div>
                                  //         </div>
                                  //       )}
                                  //     </Card>
                                  //   </td>
                                  // </tr>

                                )
                              ];
                            })}
                          </tbody>

                        </Table>
                      </div>

                      {renderPagination()}
                    </>
                  )}
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      <Modal
        show={openModel}
        onHide={handleModalClose}
        centered
        dialogClassName="custom-modal"
      >
        <Modal.Header closeButton>
          <Modal.Title>New Profiling Run</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form>
            <Row>
              <Col md={12}>
                <Form.Group className="mb-3">
                  <Form.Label>Connection</Form.Label>
                  <Form.Select
                    name="sql_flavor"
                    value={selectedConnection}
                    onChange={handleConnectionChange}
                    isInvalid={!!formErrors.selectedConnection}
                  >
                    <option value="" >
                      Select Connection Type
                    </option>
                    {connections.map((type) => (
                      <option key={type.connection_id} value={type.connection_id}>
                        {type.connection_name || `Connection ${type.connection_id}`}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.selectedConnection}
                  </Form.Control.Feedback>
                
                </Form.Group>


                <Form.Group className="mb-3">
                  <Form.Label>Table Group</Form.Label>
                  <Form.Select
                    name="sql_flavor"
                    value={selectedTableGroup}
                    onChange={handleTableGroupChange}
                    isInvalid={!!formErrors.selectedTableGroup}
              
                  >
                    <option value="" >
                      Select Table Group
                    </option>
                    {tableGroups.map((type) => (
                      <option key={type.id} value={type.id}>
                        {type.table_groups_name}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.selectedTableGroup}
                  </Form.Control.Feedback>
                 
                </Form.Group>
              </Col>
            </Row>
          </Form>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Cancel
          </Button>

          <Button
            variant="primary"
            onClick={handleRunProfiling}
          //   disabled={!selectedConnection || !selectedTableGroup}
          >
            Run Profile
          </Button>
        </Modal.Footer>
      </Modal>

    </>
  );
};

export default ProfileRuns
