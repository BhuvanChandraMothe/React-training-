import React, { useState } from "react";
import { Card, Dropdown, Modal, Button, Form, Badge } from "react-bootstrap";
import { FaFlask, FaFileAlt, FaGlobe } from "react-icons/fa";
import { BsThreeDotsVertical } from "react-icons/bs";
import "./AppCard.css";

const ConfiguredCard = ({ model, onConfigure, onRemove }) => {
  const [showModal, setShowModal] = useState(false);
  const [apiUrl, setApiUrl] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfigured, setIsConfigured] = useState(false);

  const getIconComponent = (iconName) => {
    const iconMap = {
      flask: <FaFlask className="fs-4" />,
      "file-alt": <FaFileAlt className="fs-4" />,
      globe: <FaGlobe className="fs-4" />,
    };
    return iconMap[iconName] || <FaFileAlt className="fs-4" />;
  };

  const handleConfigure = () => {
    setShowModal(true);
    if (onConfigure) onConfigure(model);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setIsSubmitting(false);
  };

  const pickRandomColor = () => {
    const colors = ["#2563eb", "#f97316", "#10b981", "#3b82f6", "#ef4444"];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // const response = await fetch(apiUrl, {
      //   method: "POST",
      //   headers: {
      //     "Content-Type": "application/json",
      //     Authorization: `Bearer ${apiKey}`,
      //   },
      //   body: JSON.stringify({ modelId: model.id }),
      // });
      // const data = await response.json();

      const data = { modelId: model.id, apiUrl: apiUrl, apiKey: apiKey };
      setIsConfigured(true);
      setShowModal(false);
    } catch (error) {
      console.error("API error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="h-100 border app-card position-relative">
      <Dropdown className="position-absolute top-0 end-0 m-2">
        <Dropdown.Toggle
          as="button"
          className="btn btn-link p-0 border-0 shadow-none"
          style={{ color: "#6c757d", fontSize: "1.2rem" }}
        >
          <BsThreeDotsVertical />
        </Dropdown.Toggle>
        <Dropdown.Menu
          align="end"
          style={{
            minWidth: 160,
            borderRadius: 12,
            boxShadow: "0 4px 24px rgba(0,0,0,0.10)",
          }}
        >
          <Dropdown.Item
            onClick={handleConfigure}
            style={{
              fontWeight: 500,
              color: "#4e73df",
              borderRadius: 8,
              marginBottom: 2,
            }}
          >
            <i
              className="mdi mdi-cog-outline me-2"
              style={{ color: "#4e73df" }}
            ></i>
            {isConfigured ? "Edit Configuration" : "Configure Card"}
          </Dropdown.Item>
          <Dropdown.Item
            onClick={() => onRemove && onRemove(model)}
            className="text-danger"
            style={{ fontWeight: 500, borderRadius: 8 }}
          >
            <i
              className="mdi mdi-trash-can-outline me-2"
              style={{ color: "#e74c3c" }}
            ></i>
            Remove
          </Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>

      <Card.Body className="p-3">
        <div className="d-flex flex-column h-100">
          <div className="mb-2 d-flex align-items-center">
            <div
              className="app-icon rounded-circle d-flex align-items-center justify-content-center me-2"
              style={{
                backgroundColor: model.iconBg ?? "#2563eb",
                color: model.iconColor ?? "#ffffff",
              }}
            >
              {getIconComponent(model.iconName)}
            </div>
            <div className="d-flex flex-column justify-content-center">
              <h6 className="card-title mb-0 text-capitalize">
                {model.provider}
              </h6>
              <span className="app-type text-muted mt-1">
                {model.type ?? "Chatflow"}
              </span>
            </div>
          </div>
          <p className="app-description text-muted mb-0">{model.description}</p>
        </div>
      </Card.Body>
      {isConfigured && (
        <Badge
          bg="dark"
          className=""
          style={{
            color: "white",
            fontSize: "0.9rem",
            padding: "0.3rem 0.3rem",
          }}
        >
          Configured
        </Badge>
      )}
      <Modal show={showModal} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>
            {isConfigured ? "Edit Configuration" : "Configure your model"}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Enter your API url</Form.Label>
              <Form.Control
                type="text"
                placeholder="https://api.example.com/endpoint"
                value={apiUrl}
                onChange={(e) => setApiUrl(e.target.value)}
                disabled={isSubmitting}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Enter your API key</Form.Label>
              <Form.Control
                type="text"
                placeholder="Your API key here"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                disabled={isSubmitting}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={handleCloseModal}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={handleSubmit}
            disabled={isSubmitting || !apiUrl || !apiKey}
          >
            {isSubmitting ? "Submitting..." : "Submit"}
          </Button>
        </Modal.Footer>
      </Modal>
    </Card>
  );
};

export default ConfiguredCard;
