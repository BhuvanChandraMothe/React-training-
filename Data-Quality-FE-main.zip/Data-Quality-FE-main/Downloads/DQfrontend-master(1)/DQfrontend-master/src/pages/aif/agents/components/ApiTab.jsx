import React, { useState } from 'react';
import {
  Card,
  Form,
  Button,
  Badge,
  Alert,
  Row,
  Col,
  Table,
} from 'react-bootstrap';
import { FaKey, FaCopy, FaEye, FaEyeSlash, FaRegClock } from 'react-icons/fa';
import { toast } from 'react-toastify';

const ApiTab = ({ formData, onFormChange }) => {
  const [showKey, setShowKey] = useState(false);
  const [apiKey, setApiKey] = useState('sk_live_51Nx...'); // Replace with actual API key

  const handleCopyKey = () => {
    navigator.clipboard.writeText(apiKey);
    toast.success('API key copied to clipboard!');
  };

  const handleRegenerateKey = () => {
    // Add API key regeneration logic here
    toast.success('API key regenerated successfully!');
  };

  return (
    <div className="ps-3 pe-2 pb-2" style={{ height: "80vh", overflowY: "auto" }}>
      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-api me-2"></i>API Access
        </h5>
        
        <Card className="border-0 bg-light">
          <Card.Body>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <div>
                <h6 className="mb-1">API Key</h6>
                <p className="text-muted small mb-0">Use this key to authenticate your API requests</p>
              </div>
              <Button
                variant="outline-primary"
                size="sm"
                onClick={handleRegenerateKey}
              >
                <FaRegClock className="me-1" />
                Regenerate
              </Button>
            </div>

            <div className="d-flex align-items-center bg-white p-2 rounded border">
              <FaKey className="text-primary me-2" />
              <div className="flex-grow-1">
                <code className="user-select-all">
                  {showKey ? apiKey : '••••••••••••••••••••••••••••••'}
                </code>
              </div>
              <div className="d-flex gap-2">
                <Button
                  variant="light"
                  size="sm"
                  onClick={() => setShowKey(!showKey)}
                >
                  {showKey ? <FaEyeSlash /> : <FaEye />}
                </Button>
                <Button
                  variant="light"
                  size="sm"
                  onClick={handleCopyKey}
                >
                  <FaCopy />
                </Button>
              </div>
            </div>
          </Card.Body>
        </Card>
      </div>

      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-code-braces me-2"></i>API Documentation
        </h5>

        <Card className="border-0">
          <Card.Body>
            <div className="mb-4">
              <h6 className="mb-3">Base URL</h6>
              <div className="bg-light p-2 rounded">
                <code>https://api.aifabric.com/v1</code>
              </div>
            </div>

            <div className="mb-4">
              <h6 className="mb-3">Authentication</h6>
              <p className="text-muted small">
                Include your API key in the Authorization header of your requests:
              </p>
              <div className="bg-light p-2 rounded">
                <code>Authorization: Bearer YOUR_API_KEY</code>
              </div>
            </div>

            <div className="mb-4">
              <h6 className="mb-3">Endpoints</h6>
              <Table hover className="align-middle">
                <thead>
                  <tr>
                    <th>Method</th>
                    <th>Endpoint</th>
                    <th>Description</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><Badge bg="success">POST</Badge></td>
                    <td><code>/chat/completions</code></td>
                    <td>Create a chat completion</td>
                  </tr>
                  <tr>
                    <td><Badge bg="primary">GET</Badge></td>
                    <td><code>/models</code></td>
                    <td>List available models</td>
                  </tr>
                  <tr>
                    <td><Badge bg="info">GET</Badge></td>
                    <td><code>/usage</code></td>
                    <td>Get API usage statistics</td>
                  </tr>
                </tbody>
              </Table>
            </div>

            <div className="mb-4">
              <h6 className="mb-3">Rate Limits</h6>
              <Alert variant="info" className="mb-0">
                <i className="mdi mdi-information-outline me-2"></i>
                Free tier: 100 requests per minute
              </Alert>
            </div>
          </Card.Body>
        </Card>
      </div>

      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-shield-check me-2"></i>Security Settings
        </h5>

        <Card className="border-0">
          <Card.Body>
            <Form>
              <Form.Group className="mb-3">
                <Form.Check
                  type="switch"
                  id="enable-ip-restriction"
                  label="IP Restriction"
                  className="mb-2"
                />
                <Form.Text className="text-muted">
                  Restrict API access to specific IP addresses
                </Form.Text>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Allowed IP Addresses</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  placeholder="Enter IP addresses (one per line)"
                  className="bg-light"
                />
              </Form.Group>

              <Form.Group>
                <Form.Check
                  type="switch"
                  id="enable-webhook"
                  label="Enable Webhooks"
                  className="mb-2"
                />
                <Form.Text className="text-muted">
                  Receive notifications for important events
                </Form.Text>
              </Form.Group>
            </Form>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
};

export default ApiTab; 