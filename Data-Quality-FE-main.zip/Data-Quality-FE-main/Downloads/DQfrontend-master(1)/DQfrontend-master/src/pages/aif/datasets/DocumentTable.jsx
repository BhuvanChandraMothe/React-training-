import React, { useEffect, useState } from "react";
import { Table, Modal, Button } from "react-bootstrap";
import { format } from "date-fns";
import { toast } from "react-toastify";
import { useAuthContext } from "../../../context/useAuthContext";
import { del } from "../../../api/io";

// Add CSS animation to head
const injectCss = () => {
  if (!document.getElementById("skeleton-animation-style")) {
    const style = document.createElement("style");
    style.id = "skeleton-animation-style";
    style.innerHTML = `
      @keyframes pulse {
        0% { opacity: 0.5; }
        50% { opacity: 0.9; }
        100% { opacity: 0.5; }
      }
    `;
    document.head.appendChild(style);
  }
};

const TableSkeleton = () => {
  // Create an array of 5 rows for the skeleton loader
  const rows = Array(5).fill(0);

  return (
    <>
      <tbody>
        {rows.map((_, index) => (
          <tr key={index}>
            {Array(7)
              .fill(0)
              .map((_, cellIndex) => (
                <td key={cellIndex}>
                  <div
                    style={{
                      height: 20,
                      width: "auto",
                      borderRadius: 4,
                      backgroundColor: "#dee2e6",
                      animation: "pulse 1.5s infinite ease-in-out",
                    }}
                  />
                </td>
              ))}
          </tr>
        ))}
      </tbody>
    </>
  );
};

const DocumentTable = ({ documents, loading, refreshDocuments }) => {
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState(null);
  // const { user } = useAuthContext();

  // console.log(documents);

  // Inject CSS for skeleton loading animation
  useEffect(() => {
    injectCss();
  }, []);

  const handleDeleteClick = (e, doc) => {
    e.stopPropagation();
    setDocumentToDelete(doc);
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = async () => {
    if (!documentToDelete) return;
    setIsDeleting(true);
    try {
      await del(`/documents/${documentToDelete.id}`);
      toast.success(`${documentToDelete.name} has been deleted successfully`);
      setShowDeleteModal(false);
      setIsDeleting(false);
      if (refreshDocuments) {
        refreshDocuments();
      }
    } catch (error) {
      console.error("Error deleting document:", error);
      toast.error(
        error.response?.data?.message || "Failed to delete document"
      );
    }
  };

  return (
    <div className="table-container">
      <div className="document-title mb-3">Documents</div>
      <Table responsive className="table-centered mb-0">
        <thead>
          <tr>
            <th>Name</th>
            <th>File Name</th>
            <th>Type</th>
            <th>Status</th>
            <th>Position</th>
            <th>Created At</th>
            <th>Actions</th>
          </tr>
        </thead>
        {loading ? (
          <TableSkeleton />
        ) : documents && documents.length > 0 ? (
          <tbody>
            {documents?.map((doc, index) => (
              <tr key={index}>
                <td>
                  <div className="d-flex align-items-center">
                    <i className="mdi mdi-file-document font-18 text-primary me-1"></i>
                    <div>
                      <span className="d-block">
                        {doc.doc_metadata?.original_filename || doc.name}
                      </span>
                      <small className="text-muted">
                        {doc.doc_metadata?.content_type}
                      </small>
                    </div>
                  </div>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    <i className="mdi mdi-file-document font-18 text-primary me-1"></i>
                    <div>
                      <span className="d-block">{doc.name}</span>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="text-muted">
                    {doc.doc_type || "Not specified"}
                  </span>
                </td>
                <td>
                  <span
                    className={`badge bg-${
                      {
                        waiting: "warning",
                        completed: "success",
                        failed: "danger",
                        processing: "info",
                      }[doc.indexing_status] || "secondary"
                    }-subtle text-${
                      {
                        waiting: "warning",
                        completed: "success",
                        failed: "danger",
                        processing: "info",
                      }[doc.indexing_status] || "secondary"
                    }`}
                  >
                    {doc.indexing_status}
                  </span>
                </td>
                <td>
                  <span className="text-muted">#{doc.position}</span>
                </td>
                <td>
                  <div>
                    <span className="d-block">
                      {format(new Date(doc.created_at), "MMM dd, yyyy")}
                    </span>
                    <small className="text-muted">
                      {format(new Date(doc.created_at), "hh:mm a")}
                    </small>
                  </div>
                </td>
                <td>
                  <div className="d-flex gap-2">
                    <button
                      className="btn btn-light btn-sm px-2"
                      title="Download"
                      onClick={() =>
                        window.open(doc.doc_metadata?.file_url, "_blank")
                      }
                    >
                      <i className="mdi mdi-download"></i>
                    </button>
                    <button
                      className="btn btn-light btn-sm px-2"
                      title="Delete"
                      onClick={(e) => handleDeleteClick(e, doc)}
                    >
                      <i className="mdi mdi-delete"></i>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        ) : (
          <tbody>
            <tr>
              <td colSpan="7" className="text-center py-5">
                <div className="empty-state">
                  <i className="mdi mdi-file-document-outline text-muted font-48"></i>
                  <h5 className="mt-3">No documents found</h5>
                  <p className="text-muted">
                    {documents && documents.length === 0
                      ? "This knowledge base doesn't have any documents yet. Add your first document to get started."
                      : "No documents match your search criteria. Try adjusting your search."}
                  </p>
                </div>
              </td>
            </tr>
          </tbody>
        )}
      </Table>

      {/* Delete Confirmation Modal */}
      <Modal
        show={showDeleteModal}
        onHide={() => setShowDeleteModal(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Delete Document</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete the document
          <strong> "{documentToDelete?.name}"</strong>? This action cannot be
          undone.
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => setShowDeleteModal(false)}
            disabled={isDeleting}
          >
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={handleConfirmDelete}
            disabled={isDeleting}
          >
            {isDeleting ? (
              <>
                <span
                  className="spinner-border spinner-border-sm me-1"
                  role="status"
                  aria-hidden="true"
                ></span>
                Deleting...
              </>
            ) : (
              "Delete Document"
            )}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default DocumentTable;
