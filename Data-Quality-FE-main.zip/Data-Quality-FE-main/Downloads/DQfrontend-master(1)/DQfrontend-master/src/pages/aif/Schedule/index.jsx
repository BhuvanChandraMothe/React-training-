import React, { useState, useEffect, useMemo } from "react";
import {
    Card,
    Row,
    Col,
    Badge,
    Button,
    Form,
    InputGroup,
    Table,
    Pagination,
    Modal,
    OverlayTrigger,
    Tooltip,
} from "react-bootstrap";
import { MdOutlineRemoveRedEye } from "react-icons/md";
import { GoEyeClosed } from "react-icons/go";
// import { useAuthContext } from "../../../context/useAuthContext";
import Loader from "../../../components/Loader";
import PageTitle from "../../../components/PageTitle";
import {
    getSchedules, postSchedules, deleteSchedule,
    updateSchedule,
    getTableGroup,
    getAllConnections,
    getTableGroups
} from "../../../api/dbapi";
import "../Logs/logs.css";
import { useToaster } from "../../../Toaster/Toaster";

const schedule = () => {
    const { showToast } = useToaster();
    const [testStatus, setTestStatus] = useState(null);
    const [openModel, setModelOpen] = useState(false);
    const [openTableGroup, setOpenTableGroupData] = useState(false);
    // const { user } = useAuthContext();
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [expandedLogId, setExpandedLogId] = useState(null);
    const [filter, setFilter] = useState({
        service: "",
        action: "",
        status: "",
        dateRange: "all",
    });
    const openDatabasePopup = () => {
        setModelOpen(true);
        setFormData({
            conn_id: "",
            group_id: "",
            schedule_cron_expression: ""
        });
        setSelectedConnection('');
        setSelectedTableGroup('');
        setFormErrors({});

    }
    const [formData, setFormData] = useState({
        conn_id: "",
        group_id: "",
        schedule_cron_expression: ""
    });

    const [formErrors, setFormErrors] = useState({});
    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        setFormErrors((prev) => ({ ...prev, [name]: "" }));
    };

    const handleSubmit = async () => {
        setIsSubmitting(true);
        setTestStatus(null);
        const errors = {};

        if (!formData.conn_id && !selectedConnection) {
            errors.conn_id = "Connection is required.";
        }
        if (!formData.group_id && !selectedTableGroup) {
            errors.group_id = "Table Group is required.";
        }
        if (!formData.schedule_cron_expression) {
            errors.schedule_cron_expression = "Cron expression is required.";
        }

        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            setIsSubmitting(false);
            return;
        }
        try {
            setLoading(true);
            const savePayload = {
                conn_id: selectedConnection || formData?.conn_id,
                group_id: selectedTableGroup || formData?.group_id,
                cron_expression: formData.schedule_cron_expression
            };


            if (formData?.scheduled_job_id) {
                try {
                    const updatedSchedule = await updateSchedule(formData.scheduled_job_id, savePayload);
                    showToast("Schedule updated successfully!", "success");
                } catch (error) {
                    console.error('Update failed:', error);
                    showToast("Failed to update schedule.", "error");
                    return; // Exit to prevent closing modal or clearing form
                }
            } else {
                try {
                    await postSchedules(savePayload);
                    showToast("Schedule created successfully!", "success");
                } catch (error) {
                    console.error('Create failed:', error);
                    showToast("Failed to create schedule.", "error");
                    return;
                }
            }

            // Only run these if no error
            setModelOpen(false);
            fetchConnections();
            setFormData({
                conn_id: "",
                group_id: "",
                schedule_cron_expression: "",
            });

        } catch (error) {
            const errorMessage = error.message || "Something went wrong.";
            showToast(errorMessage, "error");
        } finally {
            setIsSubmitting(false);
            setLoading(false);
        }
    };
    const [connections, setConnections] = useState([]);
    const [selectedConnection, setSelectedConnection] = useState('');
    const [selectedTableGroup, setSelectedTableGroup] = useState('');
    const handleModalClose = () => {
        setModelOpen(false);
        setFormErrors({});
    };
    const handleTableGroupChange = (event) => {
        setSelectedTableGroup(event.target.value);
    };
    const handleConnectionChange = (event) => {
        const connId = event.target.value;
        setSelectedConnection(connId);
        setSelectedTableGroup('');
        loadTableGroups(connId);
    };
    const loadConnections = async () => {
        //   setLoadingConnections(true);
        try {
            const data = await getAllConnections();
            setConnections(data);
        } catch (error) {
            console.error('Failed to load connections:', error);
        } finally {
            // setLoadingConnections(false);
        }
    };
    useEffect(() => {

        loadConnections();

    }, []);
    const [tableGroups, setTableGroups] = useState([]);
    const [loadingTableGroups, setLoadingTableGroups] = useState(false);
    const loadTableGroups = async (connectionId) => {
        setLoadingTableGroups(true);
        try {
            const data = await getTableGroups(connectionId);
            setTableGroups(data);
        } catch (error) {
            console.error('Failed to load table groups:', error);
        } finally {
            setLoadingTableGroups(false);
        }
    };
    const [searchQuery, setSearchQuery] = useState("");
    const [sortConfig, setSortConfig] = useState({
        key: "timestamp",
        direction: "desc",
    });
    useEffect(() => {
        fetchConnections();
    }, []);
    const fetchConnections = async () => {
        try {
            setLoading(true);
            const data = await getSchedules();
            setLogs(data);
            setLoading(false);
        } catch (error) {
            setLoading(false);
        }
    };
    // Filter and search logs
    const filteredLogs = useMemo(() => {
        return logs.filter((log) => {
            // Apply filters
            if (filter.service && log.service !== filter.service) return false;
            if (filter.action && log.action !== filter.action) return false;
            if (filter.status && log.status !== filter.status) return false;
            return true;
        });
    }, [logs, filter, searchQuery]);
    const [deleteDialogOpen, setDeleteDialogOpen] = React.useState(false); // State for delete confirmation dialog
    const onEdit = (data) => {
        console.log(data)
        loadTableGroups(data?.conn_id);
        setSelectedConnection(data.conn_id);
        setSelectedTableGroup(data.group_id);
        setFormData(data);
        setFormErrors({});
        setModelOpen(true);

    };
    const addTableGroup = (data) => {
        setFormData(data);
        setOpenTableGroupData(true);
    };
    const handleCloseModal = () => setDeleteDialogOpen(false);
    const handleCloseModals = () => setOpenTableGroupData(false);
    const handleDelete = async (data) => {
        try {
            await deleteSchedule(data?.scheduled_job_id, 'delete_permanent'); // or 'deactivate'
            alert('Schedule deleted successfully!');
            fetchConnections()
        } catch (error) {
            alert('Failed to delete schedule.');
        }
    };
    const now = new Date();

    // Extract current date values
    const minute = now.getMinutes();
    const hour = now.getHours();
    const day = now.getDate();
    const month = now.getMonth() + 1; // Months are 0-based
    const cronExample = `${minute} ${hour} ${day} ${month} *`;

    // Format the display (e.g., 12:25 PM on May 28)
    const formattedTime = now.toLocaleString("default", {
        hour: "numeric",
        minute: "numeric",
        hour12: true,
        month: "long",
        day: "numeric",
    });
    // Handle sorting
    const handleSort = (key) => {
        setSortConfig((prevSortConfig) => ({
            key,
            direction:
                prevSortConfig.key === key && prevSortConfig.direction === "asc"
                    ? "desc"
                    : "asc",
        }));
    };
    const getSortIndicator = (key) => {
        if (sortConfig.key !== key) return null;
        return sortConfig.direction === "asc" ? "↑" : "↓";
    };
    // Apply sorting
    const sortedLogs = useMemo(() => {
        const sorted = [...filteredLogs];
        if (sortConfig.key) {
            sorted.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.direction === "asc" ? -1 : 1;
                }
                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.direction === "asc" ? 1 : -1;
                }
                return 0;
            });
        }
        return sorted;
    }, [filteredLogs, sortConfig]);
    // Paged logs
    const pagedLogs = useMemo(() => {
        const start = (currentPage - 1) * pageSize;
        return sortedLogs.slice(start, start + pageSize);
    }, [sortedLogs, currentPage, pageSize]);
    return (
        <>
            <PageTitle
                breadCrumbItems={[
                    { label: "Dashboard", path: "/aif/dashboard" },
                    { label: "Schedules", path: "/aif/logs", active: true },
                ]}
                title={"Schedules"}
            />

            <Row>
                <Col>
                    <Card>
                        <Card.Body>
                            {/* <h4 className="header-title mb-3">Schedules</h4> */}

                            <Row className="mb-3 mt-2">
                                <Col md={9}>
                                    <InputGroup>
                                        <InputGroup.Text>
                                            <i className="mdi mdi-magnify"></i>
                                        </InputGroup.Text>
                                        <Form.Control
                                            placeholder="Search Schedules..."
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                        />
                                    </InputGroup>
                                </Col>
                                <Col md={3}>
                                    <div className="d-flex justify-content-end">
                                        <Button
                                            variant="primary"
                                            onClick={
                                                openDatabasePopup
                                            }
                                        >
                                            <i className="mdi mdi-plus me-1"></i> Add Schedule
                                        </Button>
                                    </div>
                                </Col>
                            </Row>
                            <>
                                {filteredLogs.length === 0 ? (
                                    <div className="text-center py-5">
                                        <i
                                            className="mdi mdi-file-search text-muted"
                                            style={{ fontSize: "3rem" }}
                                        ></i>
                                        <h5 className="mt-3">No schedules found</h5>
                                        <p className="text-muted">
                                            Try adjusting your search or filter criteria
                                        </p>

                                    </div>
                                ) : (
                                    <>
                                        {expandedLogId &&
                                            renderLogDetails(
                                                logs.find((log) => log.id === expandedLogId)
                                            )}

                                        <div className="table-responsive">
                                            <Table striped hover>
                                                <thead>
                                                    <tr>
                                                        <th
                                                            className="sortable"
                                                            onClick={() => handleSort("conn_id")}
                                                            style={{ cursor: "pointer" }}
                                                        >
                                                            Connection Name{getSortIndicator("conn_id")}
                                                        </th>
                                                        <th
                                                            className="sortable"
                                                            onClick={() => handleSort("group_id")}
                                                            style={{ cursor: "pointer" }}
                                                        >
                                                            Table Group Name {getSortIndicator("group_id")}
                                                        </th>
                                                        <th
                                                            className="sortable"
                                                            onClick={() => handleSort("scheduled_job_id")}
                                                            style={{ cursor: "pointer" }}
                                                        >
                                                            Schedule  Id{" "}
                                                            {getSortIndicator("scheduled_job_id")}
                                                        </th>
                                                        <th
                                                            className="sortable"
                                                            onClick={() => handleSort("schedule_cron_expression")}
                                                            style={{ cursor: "pointer" }}
                                                        >
                                                            Cron Expression {getSortIndicator("schedule_cron_expression")}
                                                        </th>
                                                        <th>Action</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {pagedLogs.map((log) => (
                                                        <tr key={log.id}>
                                                            {/* <td>{log?.id}</td> */}
                                                            <td>{log.connection_name}</td>
                                                            <td>{log.table_group_name}</td>
                                                            <td>{log.scheduled_job_id}</td>
                                                            <td>{log.schedule_cron_expression}</td>
                                                            {/* <td>{log.is_active}</td> */}


                                                            <td className=" border-b border-gray-300 text-sm text-gray-500 bg-white font-normal cursor-pointer whitespace-nowrap ">
                                                                <div className="d-flex justify-content-center gap-2 pointer" style={{ cursor: 'pointer' }}>
                                                                    <i
                                                                        className="mdi mdi-pencil mdi-24px ml-3 pointer"
                                                                        title="Edit"
                                                                        onClick={() => onEdit(log)}
                                                                    ></i>{" "}
                                                                    <i
                                                                        className="mdi mdi-delete mdi-24px ml-4 pointer"
                                                                        title="Delete"
                                                                        onClick={() => handleDelete(log)}
                                                                    ></i>
                                                                </div>
                                                            </td>

                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </Table>
                                        </div>

                                        {/* {renderPagination()} */}
                                    </>
                                )}
                            </>
                            {/* )} */}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
            <Modal
                show={openModel}
                onHide={handleModalClose}
                centered>
                <Modal.Header closeButton>
                    <Modal.Title>
                        {formData?.id ? "Update Schedule" : "Create Schedule"}
                    </Modal.Title>
                </Modal.Header>

                <Modal.Body>
                    <Form>
                        <Row>
                            <Col md={12}>
                                <Form.Group className="mb-3">
                                    <Form.Label>Connection</Form.Label>
                                    <Form.Select
  name="connection_id"
  value={formData?.connection_id || formData?.conn_id}
  onChange={(e) => {
    const value = e.target.value;
    setFormData((prev) => ({ ...prev, connection_id: value, group_id: "" }));
    setSelectedConnection(value);
    setSelectedTableGroup('');
    loadTableGroups(value); // send the actual conn_id
  }}
  isInvalid={!!formErrors.connection_id}
>
  <option value="">Select Connection</option>
  {connections.map((type) => (
    <option key={type.connection_id} value={type.connection_id}>
      {type.connection_name || `Connection ${type.connection_id}`}
    </option>
  ))}
</Form.Select>
                                    <Form.Control.Feedback type="invalid" className="text-danger">
                                        {formErrors.conn_id}
                                    </Form.Control.Feedback>
                                </Form.Group>
                                <Form.Group className="mb-3">
                                    <Form.Label>Table Group</Form.Label>
                                    <Form.Select
                                        name="sql_flavor"
                                        value={ formData?.group_id}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            setFormData((prev) => ({ ...prev, group_id: value }));
                                            setSelectedTableGroup(value);
                                        }}
                                        isInvalid={!!formErrors.group_id}
                                    >
                                        <option value="" disabled>
                                            Select Database Type
                                        </option>
                                        {tableGroups.map((type) => (
                                            <option key={type.id} value={type.id}>
                                                {type.table_groups_name}
                                            </option>
                                        ))}
                                    </Form.Select>
                                    <Form.Control.Feedback type="invalid" className="text-danger">
                                        {formErrors.group_id}
                                    </Form.Control.Feedback>
                                </Form.Group>
                                <Form.Group className="mb-3">
                                    <Form.Label>
                                        Cron Expression{" "}
                                        <OverlayTrigger
                                            placement="right"
                                            overlay={
                                                <Tooltip>
                                                    Format: <code>minute hour day month weekday</code>
                                                    <br />
                                                    Example: <code>{cronExample}</code> → {formattedTime}
                                                </Tooltip>
                                            } >
                                            <i
                                                className="mdi mdi-information-outline ms-1"
                                                style={{ cursor: "pointer" }}
                                            ></i>
                                        </OverlayTrigger>
                                    </Form.Label>
                                    <Form.Control
                                        name="schedule_cron_expression"
                                        type="text"
                                        value={formData.schedule_cron_expression}
                                        onChange={handleInputChange}
                                        placeholder="e.g. 25 12 28 5 *"
                                        isInvalid={!!formErrors.schedule_cron_expression}
                                    />
                                    <Form.Control.Feedback type="invalid" className="text-danger">
                                        {formErrors.schedule_cron_expression}
                                    </Form.Control.Feedback>
                                    <Form.Text className="text-muted">
                                        Format: <strong>minute hour day month weekday</strong><br />
                                        • Minute: 0–59<br />
                                        • Hour: 0–23<br />
                                        • Day: 1–31<br />
                                        • Month: 1–12<br />
                                        • Weekday: 0–6 (0 = Sunday)<br />
                                        <br />
                                    </Form.Text>
                                </Form.Group>
                            </Col>
                        </Row>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleModalClose}>
                        Cancel
                    </Button>
                    <Button
                        variant="primary"
                        onClick={() => handleSubmit()}
                        disabled={isSubmitting}
                    >{formData?.id ? 'Update' : 'Submit'}

                    </Button>
                </Modal.Footer>
            </Modal>

        </>
    );
};

export default schedule;


