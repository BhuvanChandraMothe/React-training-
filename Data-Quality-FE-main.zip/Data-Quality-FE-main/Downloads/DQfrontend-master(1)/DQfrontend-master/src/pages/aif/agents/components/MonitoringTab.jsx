import React, { useState } from 'react';
import {
  Card,
  Form,
  Button,
  Badge,
  Row,
  Col,
  ProgressBar,
  Table,
} from 'react-bootstrap';
import { FaChartLine, FaExclamationTriangle, FaCheckCircle } from 'react-icons/fa';

const MonitoringTab = () => {
  const [timeRange, setTimeRange] = useState('24h');

  // Mock data for metrics
  const metrics = {
    requests: {
      total: 1234,
      success: 1200,
      failed: 34,
      successRate: 97.2,
    },
    performance: {
      avgResponseTime: 1.2,
      p95ResponseTime: 2.5,
      p99ResponseTime: 3.8,
    },
    usage: {
      tokens: 45678,
      cost: 0.45,
      quota: 1000,
      quotaUsed: 45.6,
    },
  };

  // Mock data for recent issues
  const recentIssues = [
    {
      id: 1,
      type: 'error',
      message: 'High latency detected',
      timestamp: '2024-03-20 10:30:45',
      status: 'resolved',
    },
    {
      id: 2,
      type: 'warning',
      message: 'Token usage approaching limit',
      timestamp: '2024-03-20 09:15:22',
      status: 'active',
    },
  ];

  return (
    <div className="ps-3 pe-2 pb-2" style={{ height: "80vh", overflowY: "auto" }}>
      <div className="mb-4">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h5 className="text-primary mb-0">
            <i className="mdi mdi-chart-line me-2"></i>Monitoring
          </h5>
          <div className="d-flex gap-2">
            <Button
              variant={timeRange === '24h' ? 'primary' : 'light'}
              size="sm"
              onClick={() => setTimeRange('24h')}
            >
              24h
            </Button>
            <Button
              variant={timeRange === '7d' ? 'primary' : 'light'}
              size="sm"
              onClick={() => setTimeRange('7d')}
            >
              7d
            </Button>
            <Button
              variant={timeRange === '30d' ? 'primary' : 'light'}
              size="sm"
              onClick={() => setTimeRange('30d')}
            >
              30d
            </Button>
          </div>
        </div>

        <Row>
          <Col md={3}>
            <Card className="border-0 bg-light">
              <Card.Body>
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="text-muted mb-0">Success Rate</h6>
                  <Badge bg="success">{metrics.requests.successRate}%</Badge>
                </div>
                <ProgressBar
                  now={metrics.requests.successRate}
                  variant="success"
                  className="mb-2"
                />
                <div className="d-flex justify-content-between small">
                  <span>Success: {metrics.requests.success}</span>
                  <span>Failed: {metrics.requests.failed}</span>
                </div>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="border-0 bg-light">
              <Card.Body>
                <h6 className="text-muted mb-2">Avg Response Time</h6>
                <h3 className="mb-0">{metrics.performance.avgResponseTime}s</h3>
                <div className="d-flex justify-content-between small text-muted mt-2">
                  <span>P95: {metrics.performance.p95ResponseTime}s</span>
                  <span>P99: {metrics.performance.p99ResponseTime}s</span>
                </div>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="border-0 bg-light">
              <Card.Body>
                <h6 className="text-muted mb-2">Token Usage</h6>
                <h3 className="mb-0">{metrics.usage.tokens.toLocaleString()}</h3>
                <div className="d-flex justify-content-between small text-muted mt-2">
                  <span>Cost: ${metrics.usage.cost}</span>
                  <span>Quota: {metrics.usage.quotaUsed}%</span>
                </div>
              </Card.Body>
            </Card>
          </Col>
          <Col md={3}>
            <Card className="border-0 bg-light">
              <Card.Body>
                <h6 className="text-muted mb-2">System Status</h6>
                <div className="d-flex align-items-center">
                  <FaCheckCircle className="text-success me-2" />
                  <span>All Systems Operational</span>
                </div>
                <div className="d-flex justify-content-between small text-muted mt-2">
                  <span>Uptime: 99.9%</span>
                  <span>Last Check: 5m ago</span>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </div>

      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-alert-circle-outline me-2"></i>Recent Issues
        </h5>

        <Card className="border-0">
          <Card.Body>
            <Table hover className="align-middle">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Message</th>
                  <th>Timestamp</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentIssues.map((issue) => (
                  <tr key={issue.id}>
                    <td>
                      {issue.type === 'error' ? (
                        <FaExclamationTriangle className="text-danger" />
                      ) : (
                        <FaExclamationTriangle className="text-warning" />
                      )}
                    </td>
                    <td>{issue.message}</td>
                    <td>{issue.timestamp}</td>
                    <td>
                      <Badge
                        bg={issue.status === 'resolved' ? 'success' : 'warning'}
                      >
                        {issue.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Card.Body>
        </Card>
      </div>

      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-chart-bar me-2"></i>Performance Metrics
        </h5>

        <Row>
          <Col md={6}>
            <Card className="border-0">
              <Card.Body>
                <h6 className="text-muted mb-3">Response Time Distribution</h6>
                <div className="bg-light p-3 rounded">
                  {/* Add chart component here */}
                  <div className="text-center text-muted">
                    Chart placeholder
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
          <Col md={6}>
            <Card className="border-0">
              <Card.Body>
                <h6 className="text-muted mb-3">Request Volume</h6>
                <div className="bg-light p-3 rounded">
                  {/* Add chart component here */}
                  <div className="text-center text-muted">
                    Chart placeholder
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </div>

      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-cog me-2"></i>Monitoring Settings
        </h5>

        <Card className="border-0">
          <Card.Body>
            <Form>
              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Alert Thresholds</Form.Label>
                    <Form.Control
                      type="number"
                      placeholder="Response time (ms)"
                      className="bg-light"
                    />
                    <Form.Text className="text-muted">
                      Alert when response time exceeds this value
                    </Form.Text>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Notification Channels</Form.Label>
                    <Form.Check
                      type="checkbox"
                      label="Email"
                      className="mb-2"
                    />
                    <Form.Check
                      type="checkbox"
                      label="Slack"
                      className="mb-2"
                    />
                    <Form.Check
                      type="checkbox"
                      label="Webhook"
                    />
                  </Form.Group>
                </Col>
              </Row>
            </Form>
          </Card.Body>
        </Card>
      </div>
    </div>
  );
};

export default MonitoringTab; 