import React, { useState } from 'react';
import {
  Card,
  Form,
  Button,
  Badge,
  Table,
  Row,
  Col,
  InputGroup,
} from 'react-bootstrap';
import { FaSearch, FaFilter, FaDownload, FaTrash } from 'react-icons/fa';
import { toast } from 'react-toastify';

const LogsTab = () => {
  const [selectedLogs, setSelectedLogs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Mock data for logs
  const logs = [
    {
      id: 1,
      timestamp: '2024-03-20 10:30:45',
      level: 'INFO',
      message: 'Agent started processing request',
      requestId: 'req_123456',
      duration: '1.2s',
    },
    {
      id: 2,
      timestamp: '2024-03-20 10:30:46',
      level: 'DEBUG',
      message: 'Using model: gpt-3.5-turbo',
      requestId: 'req_123456',
      duration: '0.5s',
    },
    {
      id: 3,
      timestamp: '2024-03-20 10:30:47',
      level: 'ERROR',
      message: 'Failed to process request: Invalid input',
      requestId: 'req_123457',
      duration: '0.8s',
    },
  ];

  const getLevelBadge = (level) => {
    const variants = {
      INFO: 'info',
      DEBUG: 'secondary',
      WARNING: 'warning',
      ERROR: 'danger',
    };
    return <Badge bg={variants[level] || 'secondary'}>{level}</Badge>;
  };

  const handleExportLogs = () => {
    toast.success('Logs exported successfully!');
  };

  const handleClearLogs = () => {
    toast.success('Logs cleared successfully!');
  };

  return (
    <div className="ps-3 pe-2 pb-2" style={{ height: "80vh", overflowY: "auto" }}>
      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-text-box-search me-2"></i>Logs
        </h5>

        <Card className="border-0">
          <Card.Body>
            <Row className="mb-3">
              <Col md={6}>
                <InputGroup>
                  <InputGroup.Text className="bg-light border-end-0">
                    <FaSearch className="text-muted" />
                  </InputGroup.Text>
                  <Form.Control
                    type="text"
                    placeholder="Search logs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-light border-start-0"
                  />
                </InputGroup>
              </Col>
              <Col md={6} className="d-flex justify-content-end gap-2">
                <Button
                  variant="outline-primary"
                  size="sm"
                  className="d-flex align-items-center"
                >
                  <FaFilter className="me-1" />
                  Filters
                </Button>
                <Button
                  variant="outline-primary"
                  size="sm"
                  className="d-flex align-items-center"
                  onClick={handleExportLogs}
                >
                  <FaDownload className="me-1" />
                  Export
                </Button>
                <Button
                  variant="outline-danger"
                  size="sm"
                  className="d-flex align-items-center"
                  onClick={handleClearLogs}
                >
                  <FaTrash className="me-1" />
                  Clear
                </Button>
              </Col>
            </Row>

            <div className="table-responsive">
              <Table hover className="align-middle">
                <thead>
                  <tr>
                    <th>
                      <Form.Check
                        type="checkbox"
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedLogs(logs.map(log => log.id));
                          } else {
                            setSelectedLogs([]);
                          }
                        }}
                      />
                    </th>
                    <th>Timestamp</th>
                    <th>Level</th>
                    <th>Message</th>
                    <th>Request ID</th>
                    <th>Duration</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id}>
                      <td>
                        <Form.Check
                          type="checkbox"
                          checked={selectedLogs.includes(log.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedLogs([...selectedLogs, log.id]);
                            } else {
                              setSelectedLogs(selectedLogs.filter(id => id !== log.id));
                            }
                          }}
                        />
                      </td>
                      <td>{log.timestamp}</td>
                      <td>{getLevelBadge(log.level)}</td>
                      <td>{log.message}</td>
                      <td>
                        <code className="bg-light px-2 py-1 rounded">
                          {log.requestId}
                        </code>
                      </td>
                      <td>{log.duration}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>

            <div className="d-flex justify-content-between align-items-center mt-3">
              <div className="text-muted small">
                Showing {logs.length} of {logs.length} logs
              </div>
              <div className="d-flex gap-2">
                <Button variant="light" size="sm" disabled>
                  Previous
                </Button>
                <Button variant="light" size="sm" disabled>
                  Next
                </Button>
              </div>
            </div>
          </Card.Body>
        </Card>
      </div>

      <div className="mb-4">
        <h5 className="text-primary mb-3">
          <i className="mdi mdi-chart-line me-2"></i>Log Statistics
        </h5>

        <Row>
          <Col md={4}>
            <Card className="border-0 bg-light">
              <Card.Body>
                <h6 className="text-muted mb-2">Total Requests</h6>
                <h3 className="mb-0">1,234</h3>
                <small className="text-success">
                  <i className="mdi mdi-arrow-up"></i> 12% from last period
                </small>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="border-0 bg-light">
              <Card.Body>
                <h6 className="text-muted mb-2">Error Rate</h6>
                <h3 className="mb-0">0.5%</h3>
                <small className="text-danger">
                  <i className="mdi mdi-arrow-up"></i> 2% from last period
                </small>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="border-0 bg-light">
              <Card.Body>
                <h6 className="text-muted mb-2">Avg. Response Time</h6>
                <h3 className="mb-0">1.2s</h3>
                <small className="text-success">
                  <i className="mdi mdi-arrow-down"></i> 5% from last period
                </small>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default LogsTab; 