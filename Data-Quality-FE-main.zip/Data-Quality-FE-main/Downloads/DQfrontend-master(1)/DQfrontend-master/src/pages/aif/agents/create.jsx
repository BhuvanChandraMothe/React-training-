import React, { useState } from "react";
import {
  Container,
  Card,
  Form,
  Button,
  Row,
  Col,
  Spinner,
} from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { post } from "../../../api/io";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const CreateAgent = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error("Agent name is required");
      return;
    }

    setIsSubmitting(true);

    try {
      // Add the fixed values to the payload
      const payload = {
        ...formData,
        icon: "mdi-brain", // fixed value
        mode: "agent", // fixed value
        status: "normal", // fixed value
      };

      const response = await post("/apps/", payload);
      toast.success("Agent created successfully!");

      // Navigate to agent config page after 1.5 seconds
      setTimeout(() => {
        navigate(`/agents/${response.id}`);
      }, 1500);
    } catch (error) {
      console.error("Error creating agent:", error);
      toast.error(error.message || "Failed to create agent");
      setIsSubmitting(false);
    }
  };

  return (
    <Container>
      <ToastContainer position="top-right" autoClose={3000} />

      <Row className="justify-content-center mt-4">
        <Col md={8} lg={6}>
          <div className="d-flex align-items-center mb-4">
            <button
              className="btn btn-link text-muted p-0 me-3"
              onClick={() => navigate("/aif/agents")}
            >
              <i className="mdi mdi-arrow-left font-18"></i>
            </button>
            <h4 className="mb-0">Create New Agent</h4>
          </div>

          <Card className="border-0 shadow-sm">
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-4">
                  <Form.Label>Agent Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter agent name"
                    required
                    autoFocus
                  />
                </Form.Group>

                <Form.Group className="mb-4">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Describe what this agent does"
                    rows={4}
                  />
                </Form.Group>

                <div className="d-flex align-items-center justify-content-between mt-4">
                  <Button
                    variant="light"
                    onClick={() => navigate("/aif/agents")}
                    disabled={isSubmitting}
                  >
                    Cancel
                  </Button>

                  <Button
                    variant="primary"
                    type="submit"
                    disabled={isSubmitting}
                    className="px-4 d-flex align-items-center"
                  >
                    {isSubmitting ? (
                      <>
                        <Spinner
                          as="span"
                          animation="border"
                          size="sm"
                          role="status"
                          aria-hidden="true"
                          className="me-2"
                        />
                        Creating...
                      </>
                    ) : (
                      "Create Agent"
                    )}
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>

          <div className="text-center mt-3">
            <p className="text-muted small">
              <i className="mdi mdi-information-outline me-1"></i>
              The agent will be created with AI capabilities
            </p>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default CreateAgent;
