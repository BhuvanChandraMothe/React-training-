import React, { useEffect, useState } from "react";
// import "./styles.css";

import { Row, Col, Button, Alert, Card,Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useAuthContext } from "../../../context/useAuthContext";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { get } from "../../../api/io";
import RecentProfileRuns from '../../../components/RecentProfileRuns'
import RadialGauge from '../../../components/RadialGauge '
import { fetchDashboardSummary, getAllConnections, getDashboardOverview, getOverviewMetric, getOverviewMetrics, getTableGroup, getTableGroups, profileRunTrend, profileRunTrends } from '../../../api/dbapi';
import ProfileRunTrendChart from "./components/ProfileRunTrendChart";
import ColumnStatsDistribution from "./components/ColumnStatsDistribution";

function index() {
    const formatNumber = (num) => {
    if (num === null || num === undefined) return 'N/A';
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
};

  const [connections, setConnections] = useState([]);
   const [selectedConnection, setSelectedConnection] = useState('');
    const [selectedTbGroup, setselectedTbGroup] = useState('');
    const handleConnectionChange = (event) => {
    const connId = event.target.value;
    setSelectedConnection(connId);
    fetchDashboardDatas(connId,selectedTbGroup)
    fetchRunTrend(connId,selectedTbGroup)
     fetchTableData(connId)
  };
   const handleTbChnage = (event) => {
    const connId = event.target.value;
    setselectedTbGroup(connId);
    fetchDashboardDatas(selectedConnection,connId)
    fetchRunTrends(selectedConnection,connId)
  };
  
   useEffect(() => {
        loadConnections();
        
    }, []);
    const fetchTableData = async (connectId) => {
            try {
              // setLoading(true);
              const data = await getTableGroups(connectId);
              setTableGroup(data);
              // setLoading(false);
            } catch (error) {
              // setLoading(false);
              console.error("Error fetching connections:", error);
            }
          };
    const loadConnections = async () => {
      try {
        const data = await getAllConnections();
        setConnections(data);
      } catch (error) {
        console.error('Failed to load connections:', error);
      } finally {
      }
    };
 const [totalScoreTrend] = useState([85, 88, 90, 87, 92, 95, 93, 91, 89, 86]);
    const [cdeScoreTrend] = useState([70, 75, 72, 78, 80, 82, 79, 76, 73, 70]);
    const [profilingScoreTrend] = useState([90, 92, 91, 93, 95, 94, 96, 97, 98, 99]);

  const [errorDashboard, setErrorDashboard] = useState(null);
 const [dashboardData, setDashboardData] = useState(null);
 const [tableGroup,setTableGroup]=useState([])
 const [runs,setRuns] = useState(null)
   useEffect(() => {
        fetchDashboardData();
        profileRunTrend();
        recentprofilerunsdata();
    }, []);
  
    const fetchDashboardData = async () => {
            try {
                const data = await getOverviewMetrics(selectedConnection,selectedTbGroup);
                // console.log(data)
                setDashboardData(data);
                setErrorDashboard(null);
                if (data.recentRuns && data.recentRuns.length > 0) {
                    // onSelectRun(data.recentRuns[0].profiling_id); // Automatically select the first run
                }
            } catch (err) {
                setErrorDashboard(err);
                console.error('Error fetching dashboard overview:', err);
            } finally {
                // setLoadingDashboard(false);
            }
        };

        const recentprofilerunsdata = async ()=>{
          try{
                const data = await  fetchDashboardSummary();
                setRuns(data)
                setErrorDashboard(null);
          }catch(err){
            setErrorDashboard(err);          
          }
        }
        const fetchDashboardDatas = async (datas,data1) => {
            try {
              if(datas && data1){
               const data = await getOverviewMetric(datas,data1);
                setDashboardData(data);
                setErrorDashboard(null);
                if (data.recentRuns && data.recentRuns.length > 0) {
                    // onSelectRun(data.recentRuns[0].profiling_id); // Automatically select the first run
                }
              }
                
            } catch (err) {
                setErrorDashboard(err);
                console.error('Error fetching dashboard overview:', err);
            } finally {
                // setLoadingDashboard(false);
            }
        };
         const fetchRunTrends = async (datas,data1) => {
            try {
                const data = await profileRunTrends(datas,data1);
              
            } catch (err) {
                setErrorDashboard(err);
                console.error('Error fetching dashboard overview:', err);
            } finally {
                // setLoadingDashboard(false);
            }
        };
         const fetchRunTrend = async (datas,data1) => {
            try {
                const data = await profileRunTrend(datas,data1);
              
            } catch (err) {
                setErrorDashboard(err);
                console.error('Error fetching dashboard overview:', err);
            } finally {
                // setLoadingDashboard(false);
            }
        };
  return (
   <div className="mt-4">
       <h4 className="header-title mb-2"> Data Profile Dashboard</h4>
      <div>
         <Form>
            <Row>
              <Col md={3}>
                <Form.Group className="mb-3">
                  <Form.Label>Database</Form.Label>
                   <Form.Select
                     name="sql_flavor"
                     value={selectedConnection}
                    onChange={handleConnectionChange}
                   >
                     <option value="" >
                       Select Connection Type
                     </option>
                     {connections.map((type) => (
                       <option key={type.connection_id} value={type.connection_id}>
                         {type.connection_name || `Connection ${type.connection_id}`}
                       </option>
                     ))}
                   </Form.Select>
 
                </Form.Group>
                </Col>
                <Col md={3}>
                 <Form.Group className="mb-3">
                  <Form.Label>Table Group</Form.Label>
                   <Form.Select
                                name="table_groups_id"
                                value={selectedTbGroup}
                                onChange={handleTbChnage}
                              >
                                <option value="" >
                                  Select Table Group
                                </option>
                                {tableGroup.map((type) => (
                                  <option key={type?.id} value={type?.id}>
                                    {type?.table_groups_name}
                                  </option>
                                ))}
                              </Form.Select>
 
                </Form.Group>
             </Col>
            </Row>
          </Form>
           <div className="row mb-3">
  <div className="col-12">
<div className="row">
   <div className="col-6 col-sm-3">
    <div className="card text-center p-3">
      <h4 className="mb-1">{dashboardData?.total_profiles}</h4>
      {/* <h3 className="mb-1">237</h3> */}
      <div className="text-muted">Total Profiles</div>
    </div>
  </div>
  <div className="col-6 col-sm-3">
    <div className="card text-center p-3">
         {/* <h3 className="mb-1">5,822</h3> */}
      <h4 className="mb-1">{dashboardData?.columns_profiled}</h4>
      <div className="text-muted">Column Profilled </div>
    </div>
  </div>
 
  <div className="col-6 col-sm-3">
    <div className="card text-center p-3">
           {/* <h3 className="mb-1">98.5%</h3> */}
      <h4 className="mb-1">{dashboardData?.success_rate}</h4>
      <div className="text-muted">Success Rate <span style={{fontSize:'10px'}}>+{dashboardData?.success_rate_change}%</span></div>
    </div>
  </div>
 
  <div className="col-6 col-sm-3">
    <div className="card text-center p-3">
                   {/* <h3 className="mb-1">4</h3> */}
      <h4 className="mb-1">{dashboardData?.failed_profiles}</h4>
      <div className="text-muted">Failed Profiles</div>
    </div>
  </div>
</div>
  </div>
  <div className="col-8">
    <div className="card rounded"><ProfileRunTrendChart /></div>
  </div>
  <div className="col-4">
    <div className="card rounded"><ColumnStatsDistribution /></div>
  </div>
  
</div>
 
<RecentProfileRuns data={runs || []} />
      </div>
    </div>
  )
}

export default index
