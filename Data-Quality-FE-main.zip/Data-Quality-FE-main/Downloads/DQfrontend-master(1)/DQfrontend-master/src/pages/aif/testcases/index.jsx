import React, { useState, useEffect, useMemo } from "react";
import {
  Card,
  Row,
  Col,
  Badge,
  Button,
  Form,
  InputGroup,
  Table,
  Pagination,
  Modal,
} from "react-bootstrap";
// import { useAuthContext } from "../../../context/useAuthContext";
import Loader from "../../../components/Loader";
import PageTitle from "../../../components/PageTitle";
import { addTestSuites, deleteTestCase, fetchTestSuites, getAllConnections, getTableGroup, getTestsuiteResults, getTestSuitesTableGroup, testExicutionResults, updateTestSuites } from "../../../api/dbapi";
import { useToaster } from "../../../Toaster/Toaster";
const TestCasesPage = () => {
  const { showToast } = useToaster();
  const [openModel, setModelOpen] = useState(false);
  // const { user } = useAuthContext();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedLogId, setExpandedLogId] = useState(null);
  const [filter, setFilter] = useState({
    service: "",
    action: "",
    status: "",
    dateRange: "all",
  });
  const SUPPORTED_DB_TYPES_FOR_SELECT = [
    "PostgreSQL",
    "MSSQL",
    "Oracle",
    "SQL Server",
    "Snowflake",
    "Redshift",
  ];
  const [tableGroup, setTableGroup] = useState([])

  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    test_suite: "",
    test_suite_description: "",
    severity: "",
    table_groups_id: "",
  });
  const [testStatus, setTestStatus] = useState(null);
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setFormErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handleModalClose = () => {
    setModelOpen(false);
    setFormErrors({});
  };
  const handleSubmit = async () => {

    const errors = {};

    // Validation logic
    if (!formData.test_suite?.trim()) {
      errors.test_suite = "Test Suite Name is required";
    }
    if (!formData.table_groups_id) {
      errors.table_groups_id = "Table Group is required";
    }
    if (!formData.severity) {
      errors.severity = "Severity is required";
    }

    setFormErrors(errors);

    if (Object.keys(errors).length > 0) {
      return; // prevent submission
    }

    setIsSubmitting(true);
    try {
      // setLoading(true);
      const testPayload = {
        strTableGroupsID: formData.table_groups_id,
        severity: formData.severity,
        description: formData?.test_suite_description,
        strTestSuite: formData?.test_suite,
      };
      if (formData?.id) {

        const result = await updateTestSuites(formData?.id, testPayload);
        if (result.status) {
          showToast("Test case Updated successfully!", "success");
          setTestStatus({ type: "success", message: result.message });
        } else {
          showToast(result.message || " Test case failed.", "error");
          setTestStatus({ type: "error", message: result.message });
        }
      }
      else {
        const result = await addTestSuites(testPayload);
        if (result.status) {
          showToast(" Test case added successfully!", "success");
          setTestStatus({ type: "success", message: result.message });
        } else {
          showToast(result.message || "Test case failed.", "error");
          setTestStatus({ type: "error", message: result.message });
        }
      }
      fetchTestSuites()
    }
    catch (error) {
      const errorMessage = error.message || "Test case failed.";
      showToast(errorMessage, "error");
    } finally {
      setIsSubmitting(false);
      setLoading(false);
      setModelOpen(false)
      setFormData({})
    }
  };

  const [searchQuery, setSearchQuery] = useState("");

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortConfig, setSortConfig] = useState({
    key: "timestamp",
    direction: "desc",
  });

  // Fetch logs data
  useEffect(() => {
    fetchConnections();
    fetchTableData()
  }, []);
  const fetchTableData = async () => {
    try {
      setLoading(true);
      const data = await getTableGroup();
      setTableGroup(data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error("Error fetching connections:", error);
    }
  };
  const fetchConnections = async () => {
    try {
      setLoading(true);
      const data = await fetchTestSuites();
      const sortedLogs=[...data].reverse()
      setLogs(sortedLogs);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error("Error fetching connections:", error);
    }
  };
  // Filter and search logs
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      // Apply filters
      if (filter.service && log.service !== filter.service) return false;
      if (filter.action && log.action !== filter.action) return false;
      if (filter.status && log.status !== filter.status) return false;

      return true;
    });
  }, [logs, filter, searchQuery]);

  // Apply sorting
  const sortedLogs = useMemo(() => {
    const sorted = [...filteredLogs];
    if (sortConfig.key) {
      sorted.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    }
    return sorted;
  }, [filteredLogs, sortConfig]);

  // Paged logs
  const pagedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedLogs.slice(start, start + pageSize);
  }, [sortedLogs, currentPage, pageSize]);
  const [deleteDialogOpen, setDeleteDialogOpen] = React.useState(false); // State for delete confirmation dialog
  const [selectedConnectionId, setSelectedConnectionId] = React.useState(null);
  // Total pages
  const totalPages = Math.ceil(sortedLogs.length / pageSize);
  const onEdit = (data) => {
    setFormData(data);
    setModelOpen(true);
  };
  const handleCloseModal = () => setDeleteDialogOpen(false);
  const onDelete = (data) => {
    setSelectedConnectionId(data?.id); // Set the ID of the connection to delete
    setDeleteDialogOpen(true);
  };
  const exicution = (data) => {
    testExicution(data)
  }
  const testExicution = async (item) => {
    try {
      setLoading(true);
      let payload = {
        strTableGroupsID: item?.table_groups_id,
        strTestSuite: item?.test_suite,
        strProjectCode: item?.strProjectCode,
        strProjectCode: "DEFAULT"
      }
      const data = await testExicutionResults(payload);
      setLoading(false);
      fetchConnections();
      showToast("Execution test in background", 'success', '')
    } catch (error) {
      setLoading(false);
      console.error("Error fetching connections:", error);
    }

  };
  const confirmDelete = async () => {
    try {
      // Call the API function to delete the connection
      await deleteTestCase(selectedConnectionId);
      showToast(
        "testcases Deleted successfully!",
        "success",
        "Your data was saved."
      );
      fetchTestSuites();
    } catch (error) {
      console.error("Error deleting connection:", error);
      // Optionally show an error message to the user
    } finally {
      // Close the dialog and reset selected ID
      setDeleteDialogOpen(false);
      setSelectedConnectionId(null);
    }
  };
  const [expandedRunId, setExpandedRunId] = useState(null);
  const [tableDetails, setTableDetails] = useState(null);
  const handleRowClick = (data) => {
    setExpandedRunId(prevId => prevId === data?.id ? null : data?.id);
    fetchProfileRunResults(data)
  };
  const fetchProfileRunResults = async (item) => {
    try {
      setLoading(true);
      const data = await getTestsuiteResults(item?.id);
      setTableDetails(data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error("Error fetching connections:", error);
    }
  };

  const renderPagination = () => {
    return (
      <div className="d-flex justify-content-between align-items-center mt-3">
        <div>
          <Form.Select
            className="d-inline-block me-2"
            style={{ width: "auto" }}
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
          >
            <option value={10}>10 rows</option>
            <option value={25}>25 rows</option>
            <option value={50}>50 rows</option>
          </Form.Select>
          <span className="text-muted">
            Showing{" "}
            {Math.min(sortedLogs.length, (currentPage - 1) * pageSize + 1)} to{" "}
            {Math.min(sortedLogs.length, currentPage * pageSize)} of{" "}
            {sortedLogs.length} entries
          </span>
        </div>

        <Pagination className="mb-0">
          <Pagination.First
            onClick={() => setCurrentPage(1)}
            disabled={currentPage === 1}
          />
          <Pagination.Prev
            onClick={() => setCurrentPage((curr) => Math.max(curr - 1, 1))}
            disabled={currentPage === 1}
          />

          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const pageNum =
              currentPage <= 3
                ? i + 1
                : currentPage >= totalPages - 2
                  ? totalPages - 4 + i
                  : currentPage - 2 + i;

            if (pageNum <= totalPages && pageNum > 0) {
              return (
                <Pagination.Item
                  key={pageNum}
                  active={pageNum === currentPage}
                  onClick={() => setCurrentPage(pageNum)}
                >
                  {pageNum}
                </Pagination.Item>
              );
            }
            return null;
          })}

          <Pagination.Next
            onClick={() =>
              setCurrentPage((curr) => Math.min(curr + 1, totalPages))
            }
            disabled={currentPage === totalPages || totalPages === 0}
          />
          <Pagination.Last
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage === totalPages || totalPages === 0}
          />
        </Pagination>
      </div>
    );
  };

  return (
    <>
      <PageTitle
        breadCrumbItems={[
          { label: "Dashboard", path: "/aif/dashboard" },
          { label: "Test Cases", path: "/aif/logs", active: true },
        ]}
        title={"Test Cases"}
      />

      <Row>
        <Col>
          <Card>
            <Card.Body>
              {/* <h4 className="header-title mb-3">Test Cases</h4> */}

              <Row className="mb-3 mt-2">
                <Col md={9}>
                  <InputGroup>
                    <InputGroup.Text>
                      <i className="mdi mdi-magnify"></i>
                    </InputGroup.Text>
                    <Form.Control
                      placeholder="Search Schemas..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </InputGroup>
                </Col>
                <Col md={3}>
                  <div className="d-flex justify-content-end">
                    <Button
                      variant="primary"
                      onClick={() => {
                        setModelOpen(true), setFormErrors({});
                      }}
                    >
                      <i className="mdi mdi-plus me-1"></i> Add Test Case
                    </Button>
                  </div>
                </Col>
              </Row>

              {loading ? (
                <div className="d-flex justify-content-center my-5">
                  <Loader />
                </div>
              ) : (
                <>
                  {filteredLogs.length === 0 ? (
                    <div className="text-center py-5">
                      <i
                        className="mdi mdi-file-search text-muted"
                        style={{ fontSize: "3rem" }}
                      ></i>
                      <h5 className="mt-3">No Test suites found</h5>
                      <p className="text-muted">
                        Try adjusting your search or filter criteria
                      </p>

                    </div>
                  ) : (
                    <>


                      <div className="table-responsive" style={{ overflowX: 'auto' }}>
                        <Table striped hover className="min-w-full table-fixed">
                          <thead>
                            <tr>
                              <th
                                className="sortable"
                                style={{ cursor: "pointer" }}
                              >
                                Test Suite Name
                              </th>
                              <th
                                className="sortable"
                                style={{ cursor: "pointer" }}
                              >
                                description
                              </th>
                              <th
                                className="sortable"
                                style={{ cursor: "pointer" }}
                              >
                                severity
                              </th>
                              {/* <th
                                className="sortable"
                                style={{ cursor: "pointer" }}
                              >
                                strGenerationSet
                              </th> */}
                              <th
                                className="sortable"
                                style={{ cursor: "pointer" }}
                              >
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {pagedLogs?.map((log,index) => {
                              const isExpanded = expandedRunId === log.id;
                              return [
                                <tr key={log.id} style={{ cursor: 'pointer', backgroundColor: isExpanded ? '#e9ecef' : 'inherit' }}>
                                  {/* <td>{log?.table_groups_id}</td> */}
                                  <td>{log?.test_suite}</td>
                                  <td>{log?.test_suite_description}</td>
                                  <td>{log?.severity || 'NA'}</td>
                                  {/* <td>{log?.strGenerationSet}</td> */}
                                  <td className=" border-b border-gray-300 text-sm text-gray-500 bg-white font-normal cursor-pointer whitespace-nowrap ">
                                    <div>
                                      <i
                                        className="mdi mdi-pencil mdi-24px ml-3"
                                        title="Edit"
                                        onClick={() => onEdit(log)}
                                      ></i>{" "}
                                      <i
                                        className="mdi mdi-delete mdi-24px ml-4"
                                        title="Delete"
                                        onClick={() => onDelete(log)}
                                      ></i>
                                      <Button
                                        variant="primary"
                                        className="ml-4"
                                        style={{ marginLeft: "20px" }}
                                        onClick={() => log?.has_test_results ? handleRowClick(log) : exicution(log)}
                                      >
                                        {log?.has_test_results ? 'View Results' : 'Run Test'}
                                      </Button>
                                    </div>
                                  </td>
                                </tr>,
                                isExpanded && (
                                  <tr key={`${index}`}>
                                    <td colSpan="5" className="bg-white">
                                      <Card className="mt-3 mb-3 p-3 shadow bg-white">
                                        {tableDetails?.length > 0 && (
                                          <div style={{ overflowX: 'auto' }}>
                                            <div style={{ width: '1000px' }}>
                                              <table className="w-full text-sm border-collapse border border-gray-300">
                                                <thead>
                                                  <tr className="bg-gray-100">
                                                    <th>Table Name</th>
                                                    <th className="border px-4 py-2">Column Name</th>
                                                     <th className="border px-4 py-2">Schema Name</th>
                                                    <th className="border px-4 py-2">Test Type</th>
                                                    {/* <th className="border px-4 py-2">Observability Status</th> */}
                                                    <th className="border px-4 py-2">Result Message</th>
                                                    <th className="border px-4 py-2">Result Status</th>
                                                   
                                                    <th className="border px-4 py-2">Severity</th>
                                                    {/* <th className="border px-4 py-2">Test Type</th> */}
                                                    <th className="border px-4 py-2">Test Description</th>
                                                  </tr>
                                                </thead>
                                                <tbody>
                                                  {tableDetails?.map((col) => (
                                                    <tr key={col.id}>
                                                      <td className="border px-4 py-2">{col?.table_name}</td>
                                                      <td className="border px-4 py-2">{col.column_names}</td>
                                                      <td className="border px-4 py-2">{col.schema_name?.slice(0, 10) || '-'}</td>
                                                      <td className="border px-4 py-2">{col.test_name_long}</td>
                                                      {/* <td className="border px-4 py-2">{col.observability_status || '-'}</td> */}
                                                      <td className="border px-4 py-2">{col.result_message ?? 0}</td>
                                                      <td className="border px-4 py-2">{col.result_status ?? '-'}</td>
                                                      
                                                      <td className="border px-4 py-2">{col.severity?.slice(0, 10) || '-'}</td>
                                                      {/* <td className="border px-4 py-2">{col.test_type ?? '-'}</td> */}
                                                      <td className="border px-4 py-2">{col.test_description ?? '-'}</td>

                                                    </tr>
                                                  ))}
                                                </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        )}
                                      </Card>
                                    </td>
                                  </tr>
                                )
                              ]
                            })}
                          </tbody>
                        </Table>
                      </div>

                      {renderPagination()}
                    </>
                  )}
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Modal
        show={openModel}
        onHide={handleModalClose}
        centered
        dialogClassName="custom-modal"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {formData?.id ? "Update Test Suite" : "Add Test Suite"}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-2">
                  <Form.Label>Test Suite Name</Form.Label>
                  <Form.Control
                    name="test_suite"
                    type="text"
                    value={formData.test_suite}
                    onChange={handleInputChange}
                    placeholder="Enter Test Suite Name"
                    isInvalid={!!formErrors.test_suite}
                  />
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.test_suite}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group className="mb-2">
                  <Form.Label>Table Group</Form.Label>
                  <Form.Select
                    name="table_groups_id"
                    value={formData.table_groups_id}
                    onChange={handleInputChange}
                    isInvalid={!!formErrors.table_groups_id}
                  >
                    <option value="" disabled>
                      Select Database Type
                    </option>
                    {tableGroup.map((type) => (
                      <option key={type?.id} value={type?.id}>
                        {type?.table_groups_name}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.table_groups_id}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>

              <Col md={12}>
                <Form.Group className="mb-2">
                  <Form.Label>Severity</Form.Label>
                  <Form.Select
                    name="severity"
                    value={formData.severity}
                    onChange={handleInputChange}
                    isInvalid={!!formErrors.severity}
                  >
                    <option value="" disabled>
                      Select Severity
                    </option>
                    <option value="Inherit">Inherit</option>
                    <option value="Failed">Failed</option>
                    <option value="Warning">Warning</option>
                  </Form.Select>

                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.severity}
                  </Form.Control.Feedback>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    name="test_suite_description"
                    as="textarea"
                    rows={3}
                    value={formData?.test_suite_description}
                    onChange={handleInputChange}
                    placeholder="Enter Description"
                  />
                </Form.Group>
              </Col>
            </Row>
          </Form>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Cancel
          </Button>

          <Button
            variant="primary"
            onClick={() => handleSubmit()}
            disabled={isSubmitting}
          >
            {isSubmitting
              ? "Creating..."
              : formData?.id
                ? "Update Test Suite"
                : "Save Test Suite"}
          </Button>
        </Modal.Footer>
      </Modal>
      <Modal show={deleteDialogOpen} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Delete Test case</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p style={{ fontSize: "16px" }}>
            Are you sure you want to delete this test case?
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Cancel
          </Button>
          <Button variant="primary" onClick={confirmDelete}>
            Yes, Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default TestCasesPage;
