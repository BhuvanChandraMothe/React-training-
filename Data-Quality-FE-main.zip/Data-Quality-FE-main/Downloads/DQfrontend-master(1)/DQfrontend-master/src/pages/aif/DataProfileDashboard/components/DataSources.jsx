const DataSourcesPanel = () => {
  const sources = [
    { name: 'Sales DB', score: 95, status: 'Active' },
    { name: 'Customer Data Lake', score: 89, status: 'Active' },
    { name: 'Events DB', score: 94, status: 'Active' },
  ];

  return (
    <div className="bg-white card text-black rounded shadow-sm">
      <h6 className=" p-2 pb-0 m-2 mb-0">Data Sources</h6>
   <div className="table-responsive card p-2">
      <table className="table table-white table-striped table-sm">
        <thead className="text-muted small">
          <tr>
            <th>Name</th>
            <th>Data Quality Score</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {sources.map((src, i) => (
            <tr key={i}>
              <td>{src.name}</td>
              <td>{src.score}</td>
              <td>
                <span className="badge bg-success">{src.status}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
};
export default DataSourcesPanel