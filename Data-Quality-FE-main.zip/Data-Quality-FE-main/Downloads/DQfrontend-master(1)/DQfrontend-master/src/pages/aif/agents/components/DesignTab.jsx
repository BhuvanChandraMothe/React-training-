import React, { useState, useEffect } from "react";
import {
  Button,
  Form,
  Row,
  Col,
  Badge,
  Spinner,
  Alert,
  Modal,
} from "react-bootstrap";
import { FaFolder, FaPlus, FaTimes, FaRobot } from "react-icons/fa";
import { toast } from "react-toastify";
import { patch, post, get } from "../../../../api/io";

const DesignTab = ({
  formData,
  datasets,
  onFormChange,
  onToolToggle,
  onFormSubmit,
  saving,
  isAgent,
}) => {
  const [showDatasetModal, setShowDatasetModal] = useState(false);
  const [showAgentModal, setShowAgentModal] = useState(false);
  const [selectedDatasets, setSelectedDatasets] = useState([]);
  const [selectedAgents, setSelectedAgents] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [availableAgents, setAvailableAgents] = useState([]);

  const configs = formData.configs || {};
  const prePrompt = configs.pre_prompt || "";
  const tools = configs.tools || ["RAGTool"];

  // Initialize selected datasets from formData
  useEffect(() => {
    if (formData.dataset_ids) {
      setSelectedDatasets(
        datasets.filter((dataset) => formData.dataset_ids.includes(dataset.id))
      );
    }
  }, [formData.dataset_ids, datasets]);

  // Mock data for available agents
  useEffect(() => {
    // Mock data for demonstration
    const mockAgents = [
      {
        id: 1,
        name: "Customer Support Agent",
        description: "Handles customer inquiries and support tickets",
      },
      {
        id: 2,
        name: "Sales Assistant",
        description: "Helps with sales inquiries and product information",
      },
      {
        id: 3,
        name: "Technical Support",
        description: "Provides technical assistance and troubleshooting",
      },
    ];
    setAvailableAgents(mockAgents);
  }, []);

  const handleDatasetSelect = (dataset) => {
    const isSelected = selectedDatasets.some((d) => d.id === dataset.id);
    let newSelectedDatasets;

    if (isSelected) {
      newSelectedDatasets = selectedDatasets.filter((d) => d.id !== dataset.id);
    } else {
      newSelectedDatasets = [...selectedDatasets, dataset];
    }

    setSelectedDatasets(newSelectedDatasets);
    onFormChange({
      target: {
        name: "dataset_id",
        value: newSelectedDatasets[0].id,
      },
    });
  };

  const handleDatasetRemove = (datasetId) => {
    const newSelectedDatasets = selectedDatasets.filter(
      (d) => d.id !== datasetId
    );
    setSelectedDatasets(newSelectedDatasets);
    onFormChange({
      target: {
        name: "dataset_id",
        value: newSelectedDatasets[0].id,
      },
    });
  };

  const handleAgentSelect = (agent) => {
    const isSelected = selectedAgents.some((a) => a.id === agent.id);
    let newSelectedAgents;

    if (isSelected) {
      newSelectedAgents = selectedAgents.filter((a) => a.id !== agent.id);
    } else {
      newSelectedAgents = [...selectedAgents, agent];
    }

    setSelectedAgents(newSelectedAgents);
  };

  const handleAgentRemove = (agentId) => {
    const newSelectedAgents = selectedAgents.filter((a) => a.id !== agentId);
    setSelectedAgents(newSelectedAgents);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      const configData = {
        ...formData,
        configs: {
          ...formData.configs,
          dataset_id: selectedDatasets[0].id,
        },
      };

      if (formData.id) {
        await patch(`/app-model-configs/${formData.id}`, configData);
        toast.success("Agent configuration updated successfully!");
      } else {
        await post("/app-model-configs/", configData);
        toast.success("Agent configuration saved successfully!");
      }
    } catch (error) {
      console.error("Error saving config:", error);
      toast.error("Failed to save agent configuration");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      className="ps-3 pe-2 pb-2"
      style={{ height: "80vh", overflowY: "auto" }}
    >
      <Form onSubmit={handleFormSubmit}>
        {!formData.app_id && (
          <Alert variant="warning" className="mb-3">
            <i className="mdi mdi-alert-circle-outline me-2"></i>
            App ID is missing. Please ensure the agent is created properly.
          </Alert>
        )}

        <div className="mb-3">
          <h5 className="text-primary mb-2">
            <i className="mdi mdi-brain me-2"></i>
            {isAgent ? "Agent" : "Chatbot"} Archestration
          </h5>

          <Form.Group className="mb-1">
            <Form.Label className="fw-medium">Instructions</Form.Label>
            <Form.Control
              as="textarea"
              rows={6}
              name="configs.pre_prompt"
              value={prePrompt}
              onChange={onFormChange}
              placeholder="Enter instructions for the AI"
              className="border-info border-2 border-opacity-50 bg-light"
            />
            <Form.Text className="text-muted">
              This defines the behavior and capabilities of your agent
            </Form.Text>
          </Form.Group>

          <Form.Group>
            <Form.Label className="fw-medium">Opening Statement</Form.Label>
            <Form.Control
              as="textarea"
              rows={1}
              name="opening_statement"
              value={formData.opening_statement || ""}
              onChange={onFormChange}
              placeholder="Enter an opening message for your agent"
            />
            <Form.Text className="text-muted">
              This will be shown when a user starts a conversation
            </Form.Text>
          </Form.Group>
        </div>

        <div className="mb-2">
          <div className="d-flex justify-content-between align-items-center mb-1">
            <div>
              <h5 className="text-primary mb-1">
                <i className="mdi mdi-database me-2"></i>Knowledge Base
              </h5>
              <p className="text-muted small mb-0">
                Select knowledge bases for your agent to use
              </p>
            </div>
            <Button
              variant="outline-primary"
              size="sm"
              onClick={() => setShowDatasetModal(true)}
            >
              <FaPlus className="me-1" />
              Add
            </Button>
          </div>

          {selectedDatasets.length > 0 ? (
            <div className="d-flex flex-wrap gap-2">
              {selectedDatasets.map((dataset) => (
                <div
                  key={dataset.id}
                  className="p-2 rounded bg-light border border-primary d-flex align-items-center"
                  style={{ minWidth: "200px" }}
                >
                  <FaFolder color="#6f42c1" size={20} className="me-2" />
                  <div className="flex-grow-1">
                    <span className="fw-medium d-block">{dataset.name}</span>
                    {dataset.description && (
                      <small className="text-muted">
                        {dataset.description}
                      </small>
                    )}
                  </div>
                  <Button
                    variant="link"
                    size="sm"
                    className="text-danger p-0"
                    onClick={() => handleDatasetRemove(dataset.id)}
                  >
                    <FaTimes />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <Alert variant="info" className="mb-0">
              <i className="mdi mdi-information-outline me-2"></i>
              No knowledge bases selected. Click "Add" to select.
            </Alert>
          )}
        </div>

        {isAgent && (
          <div>
            <div className="mb-4">
              <div className="d-flex justify-content-between align-items-center mb-1">
                <div>
                  <h5 className="text-primary mb-1">
                    <i className="mdi mdi-robot me-2"></i>Bound Agents
                  </h5>
                  <p className="text-muted small mb-0">
                    Select other agents to bind with this agent
                  </p>
                </div>
                <Button
                  variant="outline-primary"
                  size="sm"
                  onClick={() => setShowAgentModal(true)}
                >
                  <FaPlus className="me-1" />
                  Add
                </Button>
              </div>

              {selectedAgents?.length > 0 ? (
                <div className="d-flex flex-wrap gap-2">
                  {selectedAgents?.map((agent) => (
                    <div
                      key={agent.id}
                      className="p-2 rounded bg-light border border-primary d-flex align-items-center"
                      style={{ minWidth: "200px" }}
                    >
                      <FaRobot color="#6f42c1" size={20} className="me-2" />
                      <div className="flex-grow-1">
                        <span className="fw-medium d-block">{agent.name}</span>
                        {agent.description && (
                          <small className="text-muted">
                            {agent.description}
                          </small>
                        )}
                      </div>
                      <Button
                        variant="link"
                        size="sm"
                        className="text-danger p-0"
                        onClick={() => handleAgentRemove(agent.id)}
                      >
                        <FaTimes />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <Alert variant="info" className="mb-0">
                  <i className="mdi mdi-information-outline me-2"></i>
                  No agents bound. Click "Add" to select.
                </Alert>
              )}
            </div>

            <div className="mb-2">
              <h5 className="text-primary mb-2">
                <i className="mdi mdi-tools me-2"></i>Tools
              </h5>

              <Row>
                <Col md={6}>
                  <div className="mb-3">
                    <Form.Check
                      type="switch"
                      id="tool-rag"
                      label="RAG Tool (Retrieval Augmented Generation)"
                      checked={tools.includes("RAGTool")}
                      onChange={() => onToolToggle("RAGTool")}
                    />
                    <Form.Text className="text-muted ms-4">
                      Enable knowledge base search and retrieval
                    </Form.Text>
                  </div>

                  <div className="mb-3">
                    <Form.Check
                      type="switch"
                      id="tool-calculator"
                      label="Calculator Tool"
                      checked={tools.includes("CalculatorTool")}
                      onChange={() => onToolToggle("CalculatorTool")}
                    />
                    <Form.Text className="text-muted ms-4">
                      Enable mathematical calculations
                    </Form.Text>
                  </div>
                </Col>

                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-medium">
                      File Upload Settings
                    </Form.Label>
                    <Form.Check
                      type="switch"
                      id="enable-file-upload"
                      label="Allow File Uploads"
                      className="mb-2"
                    />
                    <Form.Text className="text-muted">
                      Enable users to upload files during conversation
                    </Form.Text>
                  </Form.Group>

                  <Form.Group>
                    <Form.Label className="fw-medium">
                      User Input Form
                    </Form.Label>
                    <Form.Check
                      type="switch"
                      id="enable-input-form"
                      label="Enable Structured Input Form"
                      className="mb-2"
                    />
                    <Form.Text className="text-muted">
                      Configure structured input fields for users
                    </Form.Text>
                  </Form.Group>
                </Col>
              </Row>
            </div>
          </div>
        )}
        <div className="d-flex justify-content-end">
          <Button
            variant="primary"
            type="submit"
            disabled={isSaving || !formData.app_id}
            className="px-4"
          >
            {isSaving ? (
              <>
                <Spinner
                  as="span"
                  animation="border"
                  size="sm"
                  role="status"
                  aria-hidden="true"
                  className="me-2"
                />
                Saving...
              </>
            ) : formData.id ? (
              <>Update Configuration</>
            ) : (
              <>Save Configuration</>
            )}
          </Button>
        </div>
      </Form>

      <Modal
        show={showDatasetModal}
        onHide={() => setShowDatasetModal(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Select Knowledge Bases</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {datasets.length > 0 ? (
            <div className="d-flex flex-column gap-2">
              {selectedDatasets.length > 0 && (
                <div className="mb-2">
                  <h6 className="text-primary mb-2">
                    Selected Knowledge Bases
                  </h6>
                  {selectedDatasets.map((dataset) => (
                    <div
                      key={dataset.id}
                      className="p-2 rounded bg-primary bg-opacity-10 border border-primary mb-2 d-flex align-items-center"
                      onClick={() => handleDatasetSelect(dataset)}
                    >
                      <FaFolder color="#6f42c1" size={20} className="me-2" />
                      <div className="flex-grow-1">
                        <span className="fw-medium d-block">
                          {dataset.name}
                        </span>
                        {dataset.description && (
                          <small className="text-muted">
                            {dataset.description}
                          </small>
                        )}
                      </div>
                      <Badge bg="primary" className="rounded-pill">
                        Selected
                      </Badge>
                    </div>
                  ))}
                </div>
              )}

              <div>
                <h6 className="text-muted mb-2">Available Knowledge Bases</h6>
                {datasets
                  .filter(
                    (dataset) =>
                      !selectedDatasets.some((d) => d.id === dataset.id)
                  )
                  .map((dataset) => (
                    <div
                      key={dataset.id}
                      className="p-2 rounded bg-light border cursor-pointer mb-2"
                      onClick={() => handleDatasetSelect(dataset)}
                    >
                      <div className="d-flex align-items-center">
                        <FaFolder color="#6f42c1" size={20} className="me-2" />
                        <div className="flex-grow-1">
                          <span className="fw-medium d-block">
                            {dataset.name}
                          </span>
                          {dataset.description && (
                            <small className="text-muted">
                              {dataset.description}
                            </small>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ) : (
            <Alert variant="warning">
              <i className="mdi mdi-alert-circle-outline me-2"></i>
              No knowledge bases available. Please create one first.
            </Alert>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => setShowDatasetModal(false)}
          >
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={() => {
              onFormChange({
                target: {
                  name: "dataset_id",
                  value: selectedDatasets[0].id,
                },
              });
              setShowDatasetModal(false);
            }}
          >
            Save
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal
        show={showAgentModal}
        onHide={() => setShowAgentModal(false)}
        centered
        size="lg"
      >
        <Modal.Header closeButton>
          <Modal.Title>Select Agents to Bind</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {availableAgents && availableAgents.length > 0 ? (
            <div className="d-flex flex-column gap-2">
              {selectedAgents.length > 0 && (
                <div className="mb-2">
                  <h6 className="text-primary mb-2">Bound Agents</h6>
                  {selectedAgents.map((agent) => (
                    <div
                      key={agent.id}
                      className="p-2 rounded bg-primary bg-opacity-10 border border-primary mb-2 d-flex align-items-center"
                      onClick={() => handleAgentSelect(agent)}
                    >
                      <FaRobot color="#6f42c1" size={20} className="me-2" />
                      <div className="flex-grow-1">
                        <span className="fw-medium d-block">
                          {agent.name || agent.title}
                        </span>
                        {agent.description && (
                          <small className="text-muted">
                            {agent.description}
                          </small>
                        )}
                      </div>
                      <Badge bg="primary" className="rounded-pill">
                        Selected
                      </Badge>
                    </div>
                  ))}
                </div>
              )}

              <div>
                <h6 className="text-muted mb-2">Available Agents</h6>
                {availableAgents
                  .filter(
                    (agent) => !selectedAgents.some((a) => a.id === agent.id)
                  )
                  .map((agent) => (
                    <div
                      key={agent.id}
                      className="p-2 rounded bg-light border cursor-pointer mb-2"
                      onClick={() => handleAgentSelect(agent)}
                    >
                      <div className="d-flex align-items-center">
                        <FaRobot color="#6f42c1" size={20} className="me-2" />
                        <div className="flex-grow-1">
                          <span className="fw-medium d-block">
                            {agent.name || agent.title}
                          </span>
                          {agent.description && (
                            <small className="text-muted">
                              {agent.description}
                            </small>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ) : (
            <Alert variant="warning">
              <i className="mdi mdi-alert-circle-outline me-2"></i>
              No other agents available to bind.
            </Alert>
          )}
        </Modal.Body>
        {/* <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowAgentModal(false)}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={() => {
              onFormChange({
                target: {
                  name: "bound_agent_ids",
                  value: selectedAgents.map(agent => agent.id),
                },
              });
              setShowAgentModal(false);
            }}
          >
            Save
          </Button>
        </Modal.Footer> */}
      </Modal>
    </div>
  );
};

export default DesignTab;
