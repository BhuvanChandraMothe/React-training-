import React, { useState, useEffect, useMemo } from "react";
import {
  Card,
  Row,
  Col,
  Badge,
  Button,
  Form,
  InputGroup,
  Table,
  Pagination,
  Modal,
} from "react-bootstrap";
import { MdOutlineRemoveRedEye } from "react-icons/md";
import { GoEyeClosed } from "react-icons/go";
 
// import { useAuthContext } from "../../../context/useAuthContext";
import Loader from "../../../components/Loader";
import PageTitle from "../../../components/PageTitle";
import {
  createConnection,
  deleteConnection,
  getAllConnections,
  testConnection,
  updateConnection,
} from "../../../api/dbapi";
import "./logs.css";
import AddTableGroup from "./components/AddTableGroup";
import { useToaster } from "../../../Toaster/Toaster";
import { useAuthContext } from "../../../context/useAuthContext";
const SUPPORTED_DB_TYPES_FOR_SELECT = [
  "PostgreSQL",
  "MSSQL",
  "Oracle",
  "SQL Server",
  "Snowflake",
  "Redshift",
];
const LogsPage = () => {
  const { showToast } = useToaster();
  const [testStatus, setTestStatus] = useState(null);
  const [openModel, setModelOpen] = useState(false);
  const [openTableGroup, setOpenTableGroupData] = useState(false);
  // const { user } = useAuthContext();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedLogId, setExpandedLogId] = useState(null);
  const [filter, setFilter] = useState({
    service: "",
    action: "",
    status: "",
    dateRange: "all",
  });
  const openDatabasePopup = () => {
    setModelOpen(true)
    setTestStatus(false)
    setFormData({ project_code: "",
    connection_name: "",
    connection_description: "",
    sql_flavor: "",
    project_host: "",
    project_port: "",
    project_user: "",
    project_pw_encrypted: "",
    project_db: "",})
  }
  const [formData, setFormData] = useState({
    project_code: "",
    connection_name: "",
    connection_description: "",
    sql_flavor: "",
    project_host: "",
    project_port: "",
    project_user: "",
    project_pw_encrypted: "",
    project_db: "",
  });
 
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setFormErrors((prev) => ({ ...prev, [name]: "" }));
  };
 
  const validateForm = () => {
    const errors = {};
    if (!formData.project_code)
      errors.project_code = "Project Code is required";
    if (!formData.project_host) errors.project_host = "Hostname is required";
    if (!formData.project_user) errors.project_user = "User ID is required";
    if (!formData.project_db) errors.project_db = "Database Name is required";
    if (!formData.connection_name)
      errors.connection_name = "Connection Name is required";
    if (!formData.sql_flavor) errors.sql_flavor = "Database Type is required";
    if (!formData.project_port) errors.project_port = "Port is required";
    if (!formData.project_pw_encrypted) errors.project_pw_encrypted = "Password is required";
    return errors;
  };
 
  const handleSubmit = async (isTest) => {
    if (!isTest) {
      const errors = validateForm();
      setFormErrors(errors);
      if (Object.keys(errors).length > 0) return;
    } else {
      setFormErrors({});
    }
 
    setIsSubmitting(true);
    setTestStatus(null); // Clear previous test status
 
    try {
      setLoading(true);
      if (isTest) {
        const testPayload = {
          sql_flavor: formData.sql_flavor,
          db_hostname: formData.project_host,
          db_port: parseInt(formData.project_port, 10),
          user_id: formData.project_user,
          password: formData.project_pw_encrypted,
          database: formData.project_db,
          action:'test'
        };
        const result = await testConnection(testPayload);
 
        if (result.status) {
          showToast("Connection test successful!", "success");
          setTestStatus({ type: "success", message: result.message });
        } else {
          showToast(result.message || "Connection test failed.", "error");
          setTestStatus({ type: "error", message: result.message });
        }
      } else {
        const savePayload = {
          project_code: formData.project_code,
          connection_name: formData.connection_name,
          connection_description: formData.connection_description || null,
          sql_flavor: formData.sql_flavor,
          project_host: formData.project_host,
          project_port: formData.project_port,
          project_user: formData.project_user,
          password: formData.project_pw_encrypted,
          project_db: formData.project_db || null,
         
        };
console.log("save connection with payload:", savePayload);
 
        if (formData?.connection_id) {
          await updateConnection(formData.connection_id, savePayload);
          showToast("Database Updated successfully!", "success");
        } else {
          savePayload.action='create'
          await createConnection(savePayload);
          showToast("Database Created successfully!", "success");
        }
 
        setModelOpen(false);
        fetchConnections();
 
        setFormData({
          project_code: "",
          connection_name: "",
          connection_description: "",
          sql_flavor: "",
          project_host: "",
          project_port: "",
          project_user: "",
          project_pw_encrypted: "",
          project_db: "",
        });
        setFormData(null)
      }
    } catch (error) {
      const errorMessage = error.message || "Connection test failed.";
 
 
      if (isTest) {
       
        setTestStatus({
          type: "error",
          message: `Failed to connect to the database`,
        });
      }else{
              // showToast(errorMessage, "error");
      }
    } finally {
      setIsSubmitting(false);
      setLoading(false);
    }
  };
 
 
 
  const handleModalClose = () => {
    setModelOpen(false);
    setFormErrors({});
  };
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortConfig, setSortConfig] = useState({
    key: "timestamp",
    direction: "desc",
  });
  useEffect(() => {
    fetchConnections();
  }, []);
  const fetchConnections = async () => {
    try {
      setLoading(true);
      const data = await getAllConnections();
      setLogs(data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
  };
  // Filter and search logs
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      // Apply filters
      if (filter.service && log.service !== filter.service) return false;
      if (filter.action && log.action !== filter.action) return false;
      if (filter.status && log.status !== filter.status) return false;
      return true;
    });
  }, [logs, filter, searchQuery]);
  const [deleteDialogOpen, setDeleteDialogOpen] = React.useState(false); // State for delete confirmation dialog
  const [selectedConnectionId, setSelectedConnectionId] = React.useState(null);
  const onEdit = (data) => {
    setFormData(data);
    setModelOpen(true);
  };
  const addTableGroup = (data) => {
    setFormData(data);
    setOpenTableGroupData(true);
  };
  const handleCloseModal = () => setDeleteDialogOpen(false);
  const onDelete = (data) => {
    setSelectedConnectionId(data?.connection_id); // Set the ID of the connection to delete
    setDeleteDialogOpen(true);
  };
  const handleCloseModals = () => setOpenTableGroupData(false);
  const confirmDelete = async () => {
    try {
      // Call the API function to delete the connection
      await deleteConnection(selectedConnectionId);
      showToast(
        "Database Deleted successfully!",
        "success",
        "Your data was saved."
      );
      fetchConnections();
    } catch (error) {
      console.error("Error deleting connection:", error);
      // Optionally show an error message to the user
    } finally {
      // Close the dialog and reset selected ID
      setDeleteDialogOpen(false);
      setSelectedConnectionId(null);
    }
  };
 
  // Apply sorting
  const sortedLogs = useMemo(() => {
    const sorted = [...filteredLogs];
    if (sortConfig.key) {
      sorted.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    }
    return sorted;
  }, [filteredLogs, sortConfig]);
 
  // Paged logs
  const pagedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedLogs.slice(start, start + pageSize);
  }, [sortedLogs, currentPage, pageSize]);
 
  // Total pages
  const totalPages = Math.ceil(sortedLogs.length / pageSize);
 
  // Handle sorting
  const handleSort = (key) => {
    setSortConfig((prevSortConfig) => ({
      key,
      direction:
        prevSortConfig.key === key && prevSortConfig.direction === "asc"
          ? "desc"
          : "asc",
    }));
  };
  const renderLogDetails = (log) => {
    return (
      <div className="log-details p-3 bg-light border rounded mb-3">
        <h6 className="mb-3">Detailed Information</h6>
        <Row>
          <Col md={6} className="mb-2">
            <p className="mb-1">
              <strong>Event ID:</strong> {log.id}
            </p>
            <p className="mb-1">
              <strong>IP Address:</strong> {log.ip}
            </p>
            <p className="mb-1">
              <strong>Timestamp:</strong> {formatDate(log.timestamp)}
            </p>
          </Col>
          <Col md={6} className="mb-2">
            <p className="mb-1">
              <strong>Actor:</strong> {log.actor}
            </p>
            <p className="mb-1">
              <strong>Service:</strong> {log.service}
            </p>
            <p className="mb-1">
              <strong>Action:</strong> {log.action}
            </p>
          </Col>
        </Row>
        <hr />
        <h6>Event Details</h6>
        <pre className="bg-dark text-light p-3 rounded">
          {JSON.stringify(log.details, null, 2)}
        </pre>
      </div>
    );
  };
  // Render pagination controls
  const renderPagination = () => {
    return (
      <div className="d-flex justify-content-between align-items-center mt-3">
        <div>
          <Form.Select
            className="d-inline-block me-2"
            style={{ width: "auto" }}
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
          >
            <option value={10}>10 rows</option>
            <option value={25}>25 rows</option>
            <option value={50}>50 rows</option>
          </Form.Select>
          <span className="text-muted">
            Showing{" "}
            {Math.min(sortedLogs.length, (currentPage - 1) * pageSize + 1)} to{" "}
            {Math.min(sortedLogs.length, currentPage * pageSize)} of{" "}
            {sortedLogs.length} entries
          </span>
        </div>
 
        <Pagination className="mb-0">
          <Pagination.First
            onClick={() => setCurrentPage(1)}
            disabled={currentPage === 1}
          />
          <Pagination.Prev
            onClick={() => setCurrentPage((curr) => Math.max(curr - 1, 1))}
            disabled={currentPage === 1}
          />
 
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const pageNum =
              currentPage <= 3
                ? i + 1
                : currentPage >= totalPages - 2
                  ? totalPages - 4 + i
                  : currentPage - 2 + i;
 
            if (pageNum <= totalPages && pageNum > 0) {
              return (
                <Pagination.Item
                  key={pageNum}
                  active={pageNum === currentPage}
                  onClick={() => setCurrentPage(pageNum)}
                >
                  {pageNum}
                </Pagination.Item>
              );
            }
            return null;
          })}
 
          <Pagination.Next
            onClick={() =>
              setCurrentPage((curr) => Math.min(curr + 1, totalPages))
            }
            disabled={currentPage === totalPages || totalPages === 0}
          />
          <Pagination.Last
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage === totalPages || totalPages === 0}
          />
        </Pagination>
      </div>
    );
  };
 
 
 
  return (
    <>
      <PageTitle
        breadCrumbItems={[
          { label: "Dashboard", path: "/aif/dashboard" },
          { label: "Database", path: "/aif/logs", active: true },
        ]}
        title={"Database "}
      />
 
      <Row>
        <Col>
          <Card>
            <Card.Body>
              <h4 className="header-title mb-3">Database Connections</h4>
 
              <Row className="mb-3">
                <Col md={9}>
                  <InputGroup>
                    <InputGroup.Text>
                      <i className="mdi mdi-magnify"></i>
                    </InputGroup.Text>
                    <Form.Control
                      placeholder="Search Connections..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </InputGroup>
                </Col>
                <Col md={3}>
                  <div className="d-flex justify-content-end">
                   
                    <Button
                      variant="primary"
                      onClick={
                        openDatabasePopup
                      }
                    >
                      <i className="mdi mdi-plus me-1"></i> Add Database
                    </Button>
                  </div>
                </Col>
              </Row>
 
           
                <>
                  {filteredLogs.length === 0 ? (
                    <div className="text-center py-5">
                      <i
                        className="mdi mdi-file-search text-muted"
                        style={{ fontSize: "3rem" }}
                      ></i>
                      <h5 className="mt-3">No connections found</h5>
                      <p className="text-muted">
                        Try adjusting your search or filter criteria
                      </p>
                    </div>
                  ) : (
                    <>
                      {expandedLogId &&
                        renderLogDetails(
                          logs.find((log) => log.id === expandedLogId)
                        )}
 
                      <div className="table-responsive">
                        <Table striped hover>
                          <thead>
                            <tr>
                              <th
                                className="sortable"
                                onClick={() => handleSort("name")}
                                style={{ cursor: "pointer" }}
                              >
                                Connection Name
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort("type")}
                                style={{ cursor: "pointer" }}
                              >
                                Connection Type
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort("project")}
                                style={{ cursor: "pointer" }}
                              >
                                Project Code
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort("connection")}
                                style={{ cursor: "pointer" }}
                              >
                                Connection Details{" "}
                               
                              </th>
                             
                              <th
                                className="sortable"
                                onClick={() => handleSort("userId")}
                                style={{ cursor: "pointer" }}
                              >
                                User ID
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort("port")}
                                style={{ cursor: "pointer" }}
                              >
                                Port
                              </th>
                              <th
                                className="sortable"
                                onClick={() => handleSort("actions")}
                                style={{ cursor: "pointer" }}
                              >
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {pagedLogs.map((log) => (
                              <tr key={log.id}>
                                <td>{log.connection_name}</td>
                                <td>{log.sql_flavor}</td>
                                <td>{log.project_code}</td>
                                <td>{log.project_db}</td>
                                <td>{log.project_user}</td>
                                <td>{log?.project_port}</td>
                                <td className=" border-b border-gray-300 text-sm text-gray-500 bg-white font-normal cursor-pointer whitespace-nowrap ">
                                  <div className="d-flex align-item-center ">
                                    <i
                                      className="mdi mdi-pencil mdi-24px ml-3 mr-2"
                                      title="Edit"
                                      onClick={() => onEdit(log)}
                                    ></i>{" "}
                                   <Button
                                    variant="primary" style={{marginLeft:'10px'}}
                                    onClick={() => addTableGroup(log)}
                                  >
                                    Add Table Group
                                  </Button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </Table>
                      </div>
 
                      {renderPagination()}
                    </>
                  )}
                </>
             
            </Card.Body>
          </Card>
        </Col>
      </Row>
      <Modal
        show={openModel}
        onHide={handleModalClose}
        centered
        dialogClassName="custom-modal"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {formData?.connection_id ? "Update Database" : "Create Database"}
          </Modal.Title>
        </Modal.Header>
 
        <Modal.Body>
          <Form>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Project Code</Form.Label>
                  <Form.Control
                    name="project_code"
                    type="text"
                    value={formData?.project_code}
                    onChange={handleInputChange}
                    placeholder="Enter Project Code"
                    isInvalid={!!formErrors.project_code}
                  />
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.project_code}
                  </Form.Control.Feedback>
                </Form.Group>
 
                <Form.Group className="mb-3">
                  <Form.Label>Hostname</Form.Label>
                  <Form.Control
                    name="project_host"
                    type="text"
                    value={formData?.project_host}
                    onChange={handleInputChange}
                    placeholder="Enter Hostname"
                    isInvalid={!!formErrors.project_host}
                  />
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.project_host}
                  </Form.Control.Feedback>
                </Form.Group>
 
                <Form.Group className="mb-3">
                  <Form.Label>User ID</Form.Label>
                  <Form.Control
                    name="project_user"
                    type="text"
                    value={formData?.project_user}
                    onChange={handleInputChange}
                    placeholder="Enter User ID"
                    isInvalid={!!formErrors.project_user}
                  />
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.project_user}
                  </Form.Control.Feedback>
                </Form.Group>
 
                <Form.Group className="mb-3">
                  <Form.Label>Database Name</Form.Label>
                  <Form.Control
                    name="project_db"
                    type="text"
                    value={formData?.project_db}
                    onChange={handleInputChange}
                    placeholder="Enter Database Name"
                    isInvalid={!!formErrors.project_db}
                  />
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.project_db}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
 
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Connection Name</Form.Label>
                  <Form.Control
                    name="connection_name"
                    type="text"
                    value={formData?.connection_name}
                    onChange={handleInputChange}
                    placeholder="Enter Connection Name"
                    isInvalid={!!formErrors.connection_name}
                  />
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.connection_name}
                  </Form.Control.Feedback>
                </Form.Group>
 
                <Form.Group className="mb-3">
                  <Form.Label>Database Type</Form.Label>
                  <Form.Select
                    name="sql_flavor"
                    value={formData?.sql_flavor}
                    onChange={handleInputChange}
                    isInvalid={!!formErrors.sql_flavor}
                  >
                    <option value="" >
                      Select Database Type
                    </option>
                    {SUPPORTED_DB_TYPES_FOR_SELECT.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </Form.Select>
 
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.sql_flavor}
                  </Form.Control.Feedback>
                </Form.Group>
 
                <Form.Group className="mb-3">
                  <Form.Label>Port</Form.Label>
                  <Form.Control
                    name="project_port"
                    type="text"
                    value={formData?.project_port}
                    onChange={handleInputChange}
                    placeholder="Enter Port"
                    isInvalid={!!formErrors.project_port}
                  />
                  <Form.Control.Feedback type="invalid" className="text-danger">
                    {formErrors.project_port}
                  </Form.Control.Feedback>
                </Form.Group>
 
                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <InputGroup>
                    <Form.Control
                      name="project_pw_encrypted"
                      type={showPassword ? "text" : "password"}
                      value={formData?.project_pw_encrypted}
                      onChange={handleInputChange}
                      placeholder="Enter Password"
                      isInvalid={!!formErrors.project_pw_encrypted}
                    />
                    <Button
                      variant="outline-secondary"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <MdOutlineRemoveRedEye /> : <GoEyeClosed />}
 
                    </Button>
                    <Form.Control.Feedback
                      type="invalid"
                      className="text-danger"
                    >
                      {formErrors.project_pw_encrypted}
                    </Form.Control.Feedback>
                  </InputGroup>
                </Form.Group>
              </Col>
 
              <Col md={12}>
                <Form.Group className="mb-3">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    name="connection_description"
                    as="textarea"
                    rows={3}
                    value={formData?.connection_description}
                    onChange={handleInputChange}
                    placeholder="Enter Description"
                  />
                </Form.Group>
              </Col>
            </Row>
          </Form>
        </Modal.Body>
  {testStatus && (
            <p className={`text-${testStatus.type === "success" ? "success" : "danger"} mt-2 text-center`}>
              {testStatus.message}
            </p>
          )}
        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={() => handleSubmit(true)}
            disabled={isSubmitting}
          >
            {isSubmitting
              ? "Testing..."
              : formData?.connection_id
                ? "Test Connection"
                : "Test Connection"}
          </Button>
          <Button
            variant="primary"
            onClick={() => handleSubmit(false)}
            disabled={isSubmitting}
          >
            {isSubmitting
              ? "Creating..."
              : formData?.connection_id
                ? "Update Connection"
                : "Save Connection"}
          </Button>
         
 
        </Modal.Footer>
      </Modal>
      <AddTableGroup
        open={openTableGroup}
        onClose={handleCloseModals}
        connectionId={formData?.connection_id}
      />
      {/* Confirmation Modal */}
      <Modal show={deleteDialogOpen} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Delete Connection</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p style={{ fontSize: "16px" }}>
            Are you sure you want to delete this database connection?
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Cancel
          </Button>
          <Button variant="primary" onClick={confirmDelete}>
            Yes, Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};
 
export default LogsPage;