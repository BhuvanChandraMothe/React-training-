import React,{useEffect,useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  Row,
  Col,
  Card,
  Badge,
  Spinner,
  Container,
  Button,
  Dropdown,
  Modal,
  Form,
  Overlay,
  Popover,
} from "react-bootstrap";
import TrendGraph from './LineTrend';
import TestRunsTable from './TestRun Table';
import PieCharts from './PieChart';
import DataSourcesPanel from './DataSources';
import { getDashboardOverview, getdataQualityOverview, getStatusView } from '../../../../api/dbapi';

function DashboardView({duration}) {
   
         
    const formatNumber = (num) => {
      if (num === null || num === undefined) return 'N/A';
      if (num >= 1000000) {
          return (num / 1000000).toFixed(1) + 'M';
      }
      if (num >= 1000) {
          return (num / 1000).toFixed(1) + 'K';
      }
      return num.toString();
  };
   const [totalScoreTrend] = useState([85, 88, 90, 87, 92, 95, 93, 91, 89, 86]);
      const [cdeScoreTrend] = useState([70, 75, 72, 78, 80, 82, 79, 76, 73, 70]);
      const [profilingScoreTrend] = useState([90, 92, 91, 93, 95, 94, 96, 97, 98, 99]);
  
    const [errorDashboard, setErrorDashboard] = useState(null);
   const [dashboardData, setDashboardData] = useState(null);
   const [statusView,setStausView]=useState(null)
    useEffect(() => {
          fetchDashboardData();
          // fetchStatusData()
      }, [duration]);
      const fetchDashboardData = async () => {
              try {
                  const data = await getdataQualityOverview(duration ? duration : 'Last 30 Days');
                  setDashboardData(data);
                  setErrorDashboard(null);
                  if (data.recentRuns && data.recentRuns.length > 0) {
                      // onSelectRun(data.recentRuns[0].profiling_id); // Automatically select the first run
                  }
              } catch (err) {
                  setErrorDashboard(err);
                  console.error('Error fetching dashboard overview:', err);
              } finally {
                  // setLoadingDashboard(false);
              }
          };
         
         
  return (
    <div className="">
     
      <div className="row g-3 mt-2">
        <div className="col-md-2">
              <div className=" card p-3">
          <div title="Data Quality Score card">
            <h5>Data Quality Score</h5>
            
            <p className="h3">
  {(dashboardData?.data_quality_score)}%
</p>

            <div className="progress mt-2">
  <div
    className="progress-bar bg-success"
    style={{ width: `${(dashboardData?.data_quality_score ?? 0) * 100}%` }}
  ></div>
</div>

          </div>
          </div>
        </div>
        <div className="col-md-6">
            <div className='row g-2'>
              <div className='col-md-4 mr-3'>
              <div className='card p-3'>
                 <div title="Data Quality Score card">
            <h5>Total Records Tested</h5>
            <p className="h3">{dashboardData?.records_tested}</p>
          
          </div>
              </div>
             </div>
                <div className='col-md-4 mr-3'>
              <div className='card p-3'>
                 <div title="Data Quality Score card">
            <h5> Tests Succeed</h5>
            <p className="h3">{dashboardData?.test_status?.success_count}</p>
          
          </div>
              </div>
             </div>
             <div className='col-md-4 mr-3'>
              <div className='card p-3'>
                 <div title="Data Quality Score card">
            <h5> Test Failures</h5>
            <p className="h3">{dashboardData?.test_status?.failure_count}</p>
          
          </div>
              </div>
             </div>
            </div>
            
          <div className='row p-2'>
             
              <TrendGraph duration={duration}  />
              <TestRunsTable />
            </div>
        </div>
        <div className="col-md-4">
          <div className="">
            
         <PieCharts passed={dashboardData?.test_status?.passed_percentage} failed={dashboardData?.test_status?.failed_percentage} Warning={dashboardData?.test_status?.skipped_percentage} />
          </div>
          <div>
            <DataSourcesPanel />
          </div>
        </div>
      </div>
    </div>
  );
}

export default DashboardView;
