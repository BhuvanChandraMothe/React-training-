import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  Row,
  Col,
  Card,
  Badge,
  Spinner,
  Container,
  Button,
  Dropdown,
  Modal,
  Form,
  Overlay,
  Popover,
} from "react-bootstrap";
import TrendGraph from './LineTrend';
import TestRunsTable from './TestRun Table';
import PieCharts from './PieChart';
import DataSourcesPanel from './DataSources';

function DashboardView() {
  return (
    <div className="">
      <div className="row g-3">
        <div className="col-md-2">
              <div className=" card p-3">
          <div title="Data Quality Score card">
            <h5>Data Quality Score</h5>
            <p className="h3">92%</p>
            <div className="progress mt-2">
              <div className="progress-bar bg-success" style={{ width: '92%' }}></div>
            </div>
          </div>
          </div>
           <div className=" card p-2 mt-2">
          <div title="Data Quality Score card">
            <h5>Recent Test Runs</h5>
            <h4>Order Data Anomalies</h4>
          <div className='d-flex justify-content-between'>
            <Badge bg="success" className="">
                            Passed
                            </Badge>
                              <Badge bg="success" className="">
                            Passed
                            </Badge>
          </div>
           <div className='d-flex justify-content-between mt-2'>
            <p>Null Checks</p>
                            <p>Failed</p>
          </div>
          <div className='d-flex justify-content-between'>
            <Badge bg="danger" className="">
                            Failed
                            </Badge>
                              <Badge bg="secondary" className="">
                            Skipped
                            </Badge>
          </div>
           <div className=' mt-2'>
            <p className='mb-1'>Customer Records</p>
            <p>Transaction Amount</p>
          </div>
          
          </div>
          </div>
        </div>
        <div className="col-md-6">
            <div className='row g-3'>
             <div className='col-md-6 mr-3'>
              <div className='card p-2'>
                 <div title="Data Quality Score card">
            <h5>Total Test Failures</h5>
            <p className="h3">14</p>
          
          </div>
              </div>
             </div>
           <div className='col-md-6 mr-3'>
              <div className='card p-2'>
                 <div title="Data Quality Score card">
            <h5>Records Tested</h5>
            <p className="h3">128M</p>
          
          </div>
              </div>
             </div>
            </div>
            <div className='row p-2'>
              <TrendGraph />
              <TestRunsSummary />
              <TestRunsTable />
            </div>
        </div>
        <div className="col-md-4">
          <div className="">
            
         <PieCharts passed={76} failed={12} skipped={12} />
          </div>
          <div>
            <DataSourcesPanel />
          </div>
        </div>
      </div>
    </div>
  );
}

export default DashboardView;
