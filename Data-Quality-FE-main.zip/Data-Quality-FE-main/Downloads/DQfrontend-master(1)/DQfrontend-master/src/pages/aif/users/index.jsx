import React from "react";

const Index = (props) => {
  return <div>Users</div>;
};

export default Index;
