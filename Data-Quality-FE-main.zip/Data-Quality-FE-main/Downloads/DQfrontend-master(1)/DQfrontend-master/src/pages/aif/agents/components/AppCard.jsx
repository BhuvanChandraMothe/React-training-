import React, { useEffect, useState } from "react";
import { Card, Badge, Dropdown, Button, Modal } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
// import { useAuthContext } from "../../../../context/useAuthContext";
import { del, get, setAccessToken } from "../../../../api/io";

const AppCard = ({
  title,
  type,
  description,
  status,
  id,
  isTemplate = false,
  onDelete,
  searchQuery = "",
}) => {
  const navigate = useNavigate();
  // const { user } = useAuthContext();
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Set the access token when user changes
  useEffect(() => {
    // if (user?.access_token) {
    //   setAccessToken(user.access_token);
    // }
  }, []);

  // Function to highlight text that matches search query
  const highlightText = (text, query) => {
    if (!query || query.trim() === "") return text;

    const regex = new RegExp(`(${query.trim()})`, "gi");
    const parts = text.split(regex);

    return parts.map((part, i) =>
      regex.test(part) ? (
        <span key={i} className="bg-warning-subtle">
          {part}
        </span>
      ) : (
        part
      )
    );
  };

  // useEffect(() => {
  //   // Make GET request to fetch data using io service
  //   io({
  //     method: "GET",
  //     url: "apps/",
  //   })
  //     .then((data) => {
  //       console.log(data);
  //     })
  //     .catch((err) => {
  //       console.error(err.message);
  //     });
  // }, []);

  // Check if app has configuration and navigate to the appropriate page
  const checkConfigAndNavigate = async (e) => {
    try {
      const data = await get(`app-model-configs/app/${id}`);
      const isAgent = window.location.pathname?.includes("agents");
      if (data && data.length === 0) {
        // App has no configuration, navigate to AppConfig
        isAgent ? navigate(`/agents/${id}`) : navigate(`/chatbots/${id}`);
      } else {
        // App has configuration, navigate to chatbots
        isAgent ? navigate(`/agents/${id}`) : navigate(`/chatbots/${id}`);
      }
    } catch (error) {
      console.error("Error checking app configuration:", error);
      // Default to chatbots page on error
      navigate(`/agents/${id}`);
    }
  };

  const handleCardClick = (e) => {
    checkConfigAndNavigate(e);
  };

  const stopPropagation = (e) => {
    e.stopPropagation();
  };

  const handleDeleteClick = (e) => {
    stopPropagation(e);
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    try {
      // Use the del function from io.js
      await del(`apps/${id}/`);

      toast.success(`${title} has been deleted successfully`);
      if (onDelete) {
        onDelete(id);
      }
    } catch (error) {
      console.error("Error deleting app:", error);

      // Handle different error cases
      if (error.response) {
        console.error("Error response:", error.response.data);
        console.error("Error status:", error.response.status);

        const errorMessage =
          error.response.data?.message ||
          `Failed to delete the app (Status: ${error.response.status})`;
        toast.error(`Error: ${errorMessage}`);
      } else if (error.request) {
        // Request was made but no response
        console.error("Error request:", error.request);
        toast.error("No response received from server. Check your connection.");
      } else {
        // Error setting up the request
        toast.error(
          `Error: ${
            error.message || "An error occurred while deleting the app"
          }`
        );
      }
    } finally {
      setIsDeleting(false);
      setShowDeleteModal(false);
    }
  };

  const getStatusVariant = (status) => {
    switch (status) {
      case "active":
        return "success";
      case "beta":
        return "warning";
      case "new":
        return "info";
      default:
        return "secondary";
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case "chatbot":
        return "mdi mdi-robot";
      case "ai-agent":
        return "mdi mdi-brain";
      case "workflow":
        return "mdi mdi-flow";
      default:
        return "mdi mdi-application";
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case "chatbot":
        return "#4e73df";
      case "ai-agent":
        return "#1cc88a";
      case "workflow":
        return "#f6c23e";
      default:
        return "#6c757d";
    }
  };

  if (isTemplate) {
    return (
      <Card className="h-100 shadow-sm hover-shadow template-card">
        <Card.Body className="d-flex flex-column p-3">
          <div className="d-flex justify-content-between align-items-start mb-2">
            <div>
              <div className="d-flex align-items-center">
                <div
                  className="rounded-circle d-flex align-items-center justify-content-center me-2"
                  style={{
                    width: "32px",
                    height: "32px",
                    backgroundColor: `${getTypeColor(type)}15`,
                    color: getTypeColor(type),
                  }}
                >
                  <i className={`${getTypeIcon(type)} font-18`}></i>
                </div>
                <h5 className="mb-0">{highlightText(title, searchQuery)}</h5>
              </div>
              <Badge bg="info" className="mt-1 app-badge">
                <i className="mdi mdi-file-document-multiple-outline me-1"></i>{" "}
                TEMPLATE
              </Badge>
            </div>
            <div onClick={stopPropagation}>
              <Dropdown align="end">
                <Dropdown.Toggle
                  as="a"
                  bsPrefix="card-drop"
                  className="cursor-pointer"
                >
                  <i className="mdi mdi-dots-vertical font-16 text-secondary"></i>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item onClick={stopPropagation}>
                    <i className="mdi mdi-information-outline font-16 me-1"></i>
                    View Details
                  </Dropdown.Item>
                  <Dropdown.Item onClick={stopPropagation}>
                    <i className="mdi mdi-eye-outline font-16 me-1"></i>
                    Preview
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </div>
          <p className="text-muted small mb-2">
            {highlightText(description, searchQuery)}
          </p>
          <div className="mt-auto">
            <Button
              variant="primary"
              size="sm"
              className="w-100 waves-effect waves-light"
              style={{
                background: `linear-gradient(135deg, ${getTypeColor(
                  type
                )} 0%, ${getTypeColor(type)}80 100%)`,
                border: "none",
              }}
            >
              <i className="mdi mdi-plus-circle-outline me-1"></i>
              Create New Instance
            </Button>
          </div>
        </Card.Body>
      </Card>
    );
  }

  return (
    <>
      <Card
        className="h-100 shadow-sm hover-shadow app-card"
        style={{ cursor: "pointer" }}
        onClick={handleCardClick}
      >
        <Card.Body className="d-flex flex-column p-3">
          <div className="d-flex justify-content-between align-items-start mb-2">
            <div>
              <div className="d-flex align-items-center">
                <div
                  className="rounded-circle d-flex align-items-center justify-content-center me-2"
                  style={{
                    width: "32px",
                    height: "32px",
                    backgroundColor: `${getTypeColor(type)}15`,
                    color: getTypeColor(type),
                  }}
                >
                  <i className={`${getTypeIcon(type)} font-18`}></i>
                </div>
                <h5 className="mb-0">{highlightText(title, searchQuery)}</h5>
              </div>
              <Badge bg={getStatusVariant(status)} className="mt-1 app-badge">
                {status.toUpperCase()}
              </Badge>
            </div>
            <div onClick={stopPropagation}>
              <Dropdown align="end">
                <Dropdown.Toggle
                  as="a"
                  bsPrefix="card-drop"
                  className="cursor-pointer"
                >
                  <i className="mdi mdi-dots-vertical text-secondary"></i>
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  <Dropdown.Item
                    onClick={(e) => {
                      stopPropagation(e);
                      checkConfigAndNavigate(e);
                    }}
                  >
                    <i className="mdi mdi-launch me-1"></i>
                    Open App
                  </Dropdown.Item>
                  {/* <Dropdown.Item onClick={stopPropagation}>
                    <i className="mdi mdi-information-outline me-1"></i>
                    View Details
                  </Dropdown.Item> */}
                  <Dropdown.Item
                    onClick={(e) => {
                      stopPropagation(e);
                      navigate(`/aif/agents/create/${id}`);
                    }}
                  >
                    <i className="mdi mdi-cog-outline me-1"></i>
                    Settings
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item
                    className="text-danger"
                    onClick={handleDeleteClick}
                  >
                    <i className="mdi mdi-trash-can-outline me-1"></i>
                    Remove
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </div>
          <p className="text-muted small mb-2">
            {highlightText(description, searchQuery)}
          </p>
          <div className="mt-auto">
            <Badge
              bg="light"
              className="text-dark app-badge"
              style={{
                backgroundColor: `${getTypeColor(type)}15`,
                color: getTypeColor(type),
              }}
            >
              <i className={getTypeIcon(type)}></i>{" "}
              {type?.replace("-", " ").toUpperCase()}
            </Badge>
          </div>
        </Card.Body>
      </Card>

      {/* Delete Confirmation Modal */}
      <Modal
        show={showDeleteModal}
        onHide={() => setShowDeleteModal(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete <strong>{title}</strong>? This action
          cannot be undone.
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => setShowDeleteModal(false)}
            disabled={isDeleting}
          >
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={handleConfirmDelete}
            disabled={isDeleting}
          >
            {isDeleting ? "Deleting..." : "Delete"}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AppCard;
