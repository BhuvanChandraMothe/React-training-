// components/ColumnStatsDistribution.tsx
import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
} from 'chart.js';
import { Row, Col, Button, Alert, Card,Form } from "react-bootstrap";
import { columnDist } from '../../../../api/dbapi';

ChartJS.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

const ColumnStatsDistribution = () => {
  const[columnstats,setData]=useState('null_percentage')
    const changeStatusGroup=(e)=>{
      setData(e)
      columnDistribution(e)
    }
  const [chartData, setChartData] = useState(null);
  const [errorDashboard, setErrorDashboard] = useState(null);

  useEffect(() => {
    columnDistribution(columnstats);
  }, []);

  const columnDistribution = async (data) => {
    try {
      const response = await columnDist(data); // if it needs params, pass them here
      const {
        chart_title,
        distribution_data,
        x_axis_label,
        y_axis_label
      } = response;

      const labels = distribution_data.map(item => item.range);
      const values = distribution_data.map(item => item.column_count);

      setChartData({
        labels,
        datasets: [
          {
            label: y_axis_label,
            data: values,
            backgroundColor: 'rgba(107, 114, 128, 0.7)',
          }
        ]
      });
    } catch (err) {
      setErrorDashboard(err);
      console.error('Error fetching dashboard overview:', err);
    }
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 10
        },
        grid: {
          drawBorder: false
        }
      },
      x: {
        grid: {
          drawBorder: false
        }
      }
    },
    plugins: {
      legend: {
        position: 'top'
      },
      tooltip: {
        intersect: false
      }
    }
  };

  return (
    <div className="bg-white p-3 rounded shadow-md h-64">
      <h4 className="text-lg font-semibold mb-2">Column Stats Distribution</h4>
      <select className="form-select my-1 ml-2 my-lg-0" onChange={e => changeStatusGroup(e.target.value)}>
                        <option defaultValue="">Select</option>
                        <option value="null_percentage">Null Percentage</option>
                        <option value="distinct_percentage">Distinct Percentage</option>
                        <option value="avg_length">Average Length</option>
                      </select>
      <div className="h-full">
        {chartData ? (
          <Bar data={chartData} options={options} />
        ) : (
          <p>Loading chart...</p>
        )}
      </div>
    </div>
  );
};

export default ColumnStatsDistribution;
