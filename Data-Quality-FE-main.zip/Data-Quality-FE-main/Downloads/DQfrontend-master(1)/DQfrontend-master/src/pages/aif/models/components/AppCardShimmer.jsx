import { Card } from "react-bootstrap";

const AppCardShimmer = () => (
  <Card className="h-100 border app-card">
    <Card.Body className="p-3">
      <div className="d-flex flex-column h-100">
        <div className="mb-2 d-flex align-items-center">
          <div
            className="app-icon rounded-circle d-flex align-items-center justify-content-center me-2 bg-secondary bg-opacity-25"
            style={{ width: 36, height: 36 }}
          ></div>
          <div className="d-flex flex-column justify-content-center flex-grow-1">
            <div className="placeholder-glow mb-1">
              <span
                className="placeholder col-8"
                style={{ height: 18, display: "block" }}
              ></span>
            </div>
            <div className="placeholder-glow">
              <span
                className="placeholder col-4"
                style={{ height: 12, display: "block" }}
              ></span>
            </div>
          </div>
        </div>
        <div className="placeholder-glow flex-grow-1">
          <span
            className="placeholder col-12 mb-1"
            style={{ height: 12, display: "block" }}
          ></span>
          <span
            className="placeholder col-10 mb-1"
            style={{ height: 12, display: "block" }}
          ></span>
          <span
            className="placeholder col-6"
            style={{ height: 12, display: "block" }}
          ></span>
        </div>
      </div>
    </Card.Body>
  </Card>
);

export default AppCardShimmer;
