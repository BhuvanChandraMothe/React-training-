import React from 'react';
import { Nav } from 'react-bootstrap';

const Sidebar = ({ activeTab, setActiveTab }) => {
  return (
    <div className="h-100 d-flex flex-column">
      <h5 className="p-3 mb-0">Agent Orchestration</h5>
      <div className="flex-grow-1" style={{ overflowY: 'auto' }}>
        <Nav className="flex-column nav-pills p-3 pt-0">
          <Nav.Link
            className={`mb-2 ${activeTab === "design" ? "active" : ""}`}
            onClick={() => setActiveTab("design")}
          >
            <i className="mdi mdi-palette me-1"></i>
            Design
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeTab === "api" ? "active" : ""}`}
            onClick={() => setActiveTab("api")}
          >
            <i className="mdi mdi-api me-1"></i>
            API Access
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeTab === "logs" ? "active" : ""}`}
            onClick={() => setActiveTab("logs")}
          >
            <i className="mdi mdi-text me-1"></i>
            Logs
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeTab === "monitoring" ? "active" : ""}`}
            onClick={() => setActiveTab("monitoring")}
          >
            <i className="mdi mdi-chart-line me-1"></i>
            Monitoring
          </Nav.Link>
          {/* <Nav.Link
            className={`mb-2 ${activeTab === "settings" ? "active" : ""}`}
            onClick={() => setActiveTab("settings")}
          >
            <i className="mdi mdi-cog me-1"></i>
            Settings
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeTab === "deploy" ? "active" : ""}`}
            onClick={() => setActiveTab("deploy")}
          >
            <i className="mdi mdi-rocket me-1"></i>
            Deploy
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeTab === "export" ? "active" : ""}`}
            onClick={() => setActiveTab("export")}
          >
            <i className="mdi mdi-export me-1"></i>
            Export
          </Nav.Link> */}
        </Nav>
      </div>
    </div>
  );
};

export default Sidebar; 