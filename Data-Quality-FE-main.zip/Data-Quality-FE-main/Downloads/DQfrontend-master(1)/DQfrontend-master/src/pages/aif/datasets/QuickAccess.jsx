import { Link } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";

// dummy data

const QuickAccess = ({ quickAccessFiles, onItemClick }) => {
  return (
    <>
      <h5 className="mb-3">Quick Access</h5>
      <Row>
        {(quickAccessFiles || []).map((f, i) => {
          if (!f.name) return null;
          return (
            <Col key={i} sm={6} xl={3}>
              <Card
                className="mb-3"
                style={{ cursor: "pointer" }}
                onClick={() => onItemClick(f)}
              >
                <Card.Body className="quick-access-item">
                  <div className="d-flex align-items-center">
                    <i className={`${f.icon} text-primary me-2`}></i>
                    <div>
                      <h6 className="mb-1">{f.name}</h6>
                      <p className="text-muted mb-0 font-13">{f.size}</p>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          );
        })}
      </Row>

      <style>{`
        .quick-access-item {
          // transition: all 0.2s ease;
          border-radius: 10px;
          // border: 0.5px solid rgb(17, 27, 135);
          padding: 10px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .quick-access-item:hover {
          // border: 1px solid rgb(17, 27, 135);
          transition: all 0.3s ease;
          transform: translateX(5px);
        }
        .card:hover .quick-access-item {
          // border-radius: 20px;
          // transform: translateX(5px);
        }
        .card:hover {
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          border-radius: 10px;
        }
      `}</style>
    </>
  );
};

export default QuickAccess;
