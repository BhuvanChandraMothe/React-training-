import React, { useState, useEffect } from "react";
import { Row, Col, Card, Spinner } from "react-bootstrap";
import { useParams } from "react-router-dom";
// import { useAuthContext } from "../../../context/useAuthContext";
import "./styles.css";

import Sidebar from "./components/Sidebar";
import ChatPreview from "./components/ChatPreview";
import DesignTab from "./components/DesignTab";
import SettingsTab from "./components/SettingsTab";

const ChatbotConfig = () => {
  const { id } = useParams();
  // const { user } = useAuthContext();
  const [activeTab, setActiveTab] = useState("design");
  const [appData, setAppData] = useState(null);
  const [modelConfig, setModelConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [datasets, setDatasets] = useState([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (id) {
      fetchAllData();
    }
  }, [id]);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      // Fetch app data
      const appResponse = await fetch(`/api/apps/${id}`, {
        // headers: {
        //   Accept: "application/json",
        //   Authorization: `Bearer ${user?.access_token}`,
        // },
      });
      
      if (!appResponse.ok) {
        throw new Error(`HTTP error! status: ${appResponse.status}`);
      }
      
      const appDataResult = await appResponse.json();
      setAppData(appDataResult);
      
      // Fetch model config
      // const configResponse = await fetch(`/api/app-model-configs/app/${id}`, {
      //   headers: {
      //     Accept: "application/json",
      //     Authorization: `Bearer ${user?.access_token}`,
      //   },
      // });
      
      if (!configResponse.ok) {
        throw new Error(`HTTP error! status: ${configResponse.status}`);
      }
      
      const configData = await configResponse.json();
      setModelConfig(configData);
      
      if (configData.length > 0) {
        setSelectedDatasetId(configData[0].dataset_id);
      }
      
      // Fetch available datasets
      const datasetsResponse = await fetch("/api/datasets/", {
        // headers: {
        //   Accept: "application/json",
        //   Authorization: `Bearer ${user?.access_token}`,
        // },
      });
      
      if (!datasetsResponse.ok) {
        throw new Error(`HTTP error! status: ${datasetsResponse.status}`);
      }
      
      const datasetsData = await datasetsResponse.json();
      setDatasets(datasetsData);
    } catch (err) {
      console.error("Error fetching data:", err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (appData && modelConfig?.length > 0) {
      const currentConfig = modelConfig[0];
      setConfig({
        name: appData.name || "",
        description: appData.description || "",
        icon: appData.icon || "mdi-robot",
        mode: appData.mode || "chat",
        is_public: appData.is_public || false,
        status: appData.status || "normal",
        selectedKnowledgeBase: currentConfig.dataset_id || "",
        settings: {
          welcomeText: currentConfig.opening_statement || "Hi! How can I help you today?",
          enableSpeechToText: false,
          showDocumentSource: true,
          moderateOutput: true,
          temperature: currentConfig.configs?.temperature || 0.7,
          maxTokens: currentConfig.configs?.max_tokens || 500,
          topP: currentConfig.configs?.top_p || 0.9,
          frequencyPenalty: currentConfig.configs?.frequency_penalty || 0.0,
          presencePenalty: currentConfig.configs?.presence_penalty || 0.0,
          model: currentConfig.model || "gpt-4",
        },
        prompt: {
          systemPrompt: currentConfig.pre_prompt || "",
          promptType: currentConfig.prompt_type || "simple",
          formatInstructions: "",
          variables: [],
          contextWindow: 2000,
          examples: [],
        },
        metadata: {
          description: appData.description || "",
          category: "",
          language: "en",
          tags: [],
        },
        suggestedQuestions: currentConfig.suggested_questions || {},
        suggestedQuestionsAfterAnswer: currentConfig.suggested_questions_after_answer || {},
        userInputForm: currentConfig.user_input_form || {},
        fileUpload: currentConfig.file_upload || {},
      });
    }
  }, [appData, modelConfig]);

  // Configuration state
  const [config, setConfig] = useState({
    name: "",
    description: "",
    icon: "mdi-robot",
    mode: "chat",
    is_public: false,
    status: "normal",
    selectedKnowledgeBase: "",
    settings: {
      welcomeText: "Hi! How can I help you today?",
      enableSpeechToText: false,
      showDocumentSource: true,
      moderateOutput: true,
      temperature: 0.7,
      maxTokens: 500,
      topP: 0.9,
      frequencyPenalty: 0.0,
      presencePenalty: 0.0,
      model: "gpt-4",
    },
    prompt: {
      systemPrompt: "",
      promptType: "simple",
      formatInstructions: "",
      variables: [],
      contextWindow: 2000,
      examples: [],
    },
    metadata: {
      description: "",
      category: "",
      language: "en",
      tags: [],
    },
    suggestedQuestions: {},
    suggestedQuestionsAfterAnswer: {},
    userInputForm: {},
    fileUpload: {},
  });

  const handleConfigChange = (field, subfield, value) => {
    setConfig((prev) => {
      if (subfield === null) {
        return { ...prev, [field]: value };
      } else {
        return {
          ...prev,
          [field]: {
            ...prev[field],
            [subfield]: value,
          },
        };
      }
    });
  };

  const handleSettingChange = (field) => (e) => {
    const value =
      e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setConfig((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        [field]: value,
      },
    }));
  };

  const saveConfiguration = async () => {
    setSaving(true);
    try {
      // First update the app data
      const appResponse = await fetch(`/api/apps/${id}`, {
        method: 'PATCH',
        // headers: {
        //   'Content-Type': 'application/json',
        //   'Authorization': `Bearer ${user?.access_token}`,
        // },
        body: JSON.stringify({
          name: config.name,
          description: config.description,
          icon: config.icon,
          mode: config.mode,
          is_public: config.is_public,
          status: config.status
        })
      });

      if (!appResponse.ok) {
        throw new Error(`HTTP error! status: ${appResponse.status}`);
      }

      // Then update the model config
      const modelConfigData = {
        app_id: id,
        model: config.settings.model,
        dataset_id: config.selectedKnowledgeBase,
        opening_statement: config.settings.welcomeText,
        pre_prompt: config.prompt.systemPrompt,
        prompt_type: config.prompt.promptType,
        suggested_questions: config.suggestedQuestions,
        suggested_questions_after_answer: config.suggestedQuestionsAfterAnswer,
        user_input_form: config.userInputForm,
        file_upload: config.fileUpload,
        configs: {
          temperature: config.settings.temperature,
          max_tokens: config.settings.maxTokens,
          top_p: config.settings.topP,
          frequency_penalty: config.settings.frequencyPenalty,
          presence_penalty: config.settings.presencePenalty
        }
      };

      // If there's existing model config, update it
      if (modelConfig && modelConfig.length > 0) {
        const configId = modelConfig[0].id;
        const configResponse = await fetch(`/api/app-model-configs/${configId}`, {
          method: 'PATCH',
          // headers: {
          //   'Content-Type': 'application/json',
          //   'Authorization': `Bearer ${user?.access_token}`,
          // },
          body: JSON.stringify(modelConfigData)
        });

        if (!configResponse.ok) {
          throw new Error(`HTTP error! status: ${configResponse.status}`);
        }
      } else {
        // Otherwise create a new config
        const configResponse = await fetch('/api/app-model-configs/', {
          method: 'POST',
          // headers: {
          //   'Content-Type': 'application/json',
          //   'Authorization': `Bearer ${user?.access_token}`,
          // },
          body: JSON.stringify(modelConfigData)
        });

        if (!configResponse.ok) {
          throw new Error(`HTTP error! status: ${configResponse.status}`);
        }
      }

      // Refresh the data
      fetchAllData();
    } catch (error) {
      console.error('Error saving configuration:', error);
    } finally {
      setSaving(false);
    }
  };

  const renderConfigContent = () => {
    switch (activeTab) {
      case "design":
        return (
          <DesignTab
            config={config}
            handleConfigChange={handleConfigChange}
            datasets={datasets}
            selectedDatasetId={selectedDatasetId}
            setSelectedDatasetId={setSelectedDatasetId}
            onSave={saveConfiguration}
            saving={saving}
          />
        );
      case "settings":
        return (
          <SettingsTab
            config={config}
            handleSettingChange={handleSettingChange}
          />
        );
      default:
        return <div>Select a tab</div>;
    }
  };

  if (loading) {
    return <div className="p-4"><Spinner animation="border" /></div>;
  }

  return (
    <div className="mt-3 mb-3">
      {/* <div className="mb-2">
        <div className="d-flex gap-3">
          <span className="badge bg-light text-dark">
            <i className="mdi mdi-clock-outline me-1"></i>
            Created {new Date(appData?.created_at).toLocaleDateString()}
          </span>
          <span className="badge bg-light text-dark">
            <i className="mdi mdi-database-outline me-1"></i>
            Dataset ID: {modelConfig?.[0]?.dataset_id || "Not set"}
          </span>
          <span className="badge bg-light text-dark">
            <i className="mdi mdi-brain me-1"></i>
            {modelConfig?.[0]?.model || "gpt-4"}
          </span>
        </div>
      </div> */}
      <Row className="g-0 h-100">
        <Col md={9} className="pe-2">
          <Card className="h-100">
            <Card.Body className="p-0">
              <Row className="g-0 h-100">
                {/* Section Sidebar */}
                <Col md={3} className="border-end">
                  <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
                </Col>

                {/* Main Content Area */}
                <Col md={9}>
                  <div className="h-100 d-flex flex-column">
                    <div
                      className="p-3 flex-grow-1"
                      style={{
                        overflowY: "auto",
                        overflowX: "hidden",
                      }}
                    >
                      {renderConfigContent()}
                    </div>
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>

        {/* Right Section - Debug/Test */}
        {/* <Col md={3}>
          <ChatPreview
            appData={appData}
            user={user}
            modelConfig={modelConfig}
            selectedDatasetId={selectedDatasetId}
          />
        </Col> */}
      </Row>
    </div>
  );
};

export default ChatbotConfig;
