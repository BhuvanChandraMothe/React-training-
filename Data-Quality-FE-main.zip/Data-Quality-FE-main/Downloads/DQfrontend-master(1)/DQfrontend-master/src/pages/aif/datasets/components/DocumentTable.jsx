import React from 'react';
import { Table, Badge } from 'react-bootstrap';
import { format } from 'date-fns';

const DocumentTable = ({ documents }) => {
  const getStatusBadgeVariant = (status) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'success';
      case 'draft':
        return 'warning';
      case 'pending':
        return 'info';
      default:
        return 'secondary';
    }
  };

  const formatDate = (dateString) => {
    return format(new Date(dateString), 'MMM dd, yyyy HH:mm');
  };

  return (
    <div className="table-responsive">
      <Table className="table-centered table-nowrap mb-0">
        <thead>
          <tr>
            <th>Document Name</th>
            <th>Status</th>
            <th>Summary</th>
            <th>Created By</th>
            <th>Updated By</th>
            <th>Created On</th>
            <th>Updated On</th>
          </tr>
        </thead>
        <tbody>
          {documents.map((doc, index) => (
            <tr key={index}>
              <td>{doc.docName}</td>
              <td>
                <Badge bg={getStatusBadgeVariant(doc.status)}>
                  {doc.status}
                </Badge>
              </td>
              <td>{doc.summary}</td>
              <td>{doc.createdBy}</td>
              <td>{doc.updatedBy}</td>
              <td>{formatDate(doc.createdOn)}</td>
              <td>{formatDate(doc.updatedOn)}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default DocumentTable; 