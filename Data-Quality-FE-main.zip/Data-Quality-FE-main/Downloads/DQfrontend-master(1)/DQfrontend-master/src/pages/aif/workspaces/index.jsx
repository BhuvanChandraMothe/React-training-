import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Card,
  Button,
  InputGroup,
  Form,
  Dropdown,
  Badge,
  OverlayTrigger,
  Tooltip,
  Nav,
  NavItem,
  NavLink,
  Modal,
} from "react-bootstrap";
import { useNavigate, useLocation } from "react-router-dom";
import PageTitle from "../../../components/PageTitle";
import { get, post, setAccessToken, del, patch } from "../../../api/io";
// import { useAuthContext } from "../../../context/useAuthContext";
import { toast } from "react-toastify";
import "./workspaces.css";
import { useWorkspaceContext } from "../../../context/useWorkspaceContext";

// Resource type configuration
const resourceTypes = {
  agents: {
    title: "Agents",
    icon: "mdi-brain",
    bgColor: "#e3f2fd",
    color: "#1976d2",
    stats: {
      total: "Total Agents",
      active: "Active",
      idle: "Idle"
    }
  },
  workflows: {
    title: "Workflows",
    icon: "mdi-animation",
    bgColor: "#fff3e0",
    color: "#f57c00",
    stats: {
      total: "Total Workflows",
      active: "Running",
      idle: "Paused"
    }
  },
  chatbots: {
    title: "Chatbots",
    icon: "mdi-robot",
    bgColor: "#f3e5f5",
    color: "#8e24aa",
    stats: {
      total: "Total Bots",
      active: "Online",
      idle: "Offline"
    }
  },
  knowledgeBases: {
    title: "Knowledge Bases",
    icon: "mdi-database",
    bgColor: "#e8f5e9",
    color: "#388e3c",
    stats: {
      total: "Total Bases",
      active: "Indexed",
      idle: "Processing"
    }
  }
};

// Reusable Resource Card Component
const ResourceCard = ({ type, data }) => {
  const config = resourceTypes[type];
  const stats = data || { total: 0, active: 0, idle: 0 };

  return (
    <Card className="h-100 border-0 shadow-sm resource-card">
      <Card.Body className="p-2">
        <div className="d-flex align-items-center mb-2">
          <div
            className="rounded-circle d-flex align-items-center justify-content-center me-2 resource-icon"
            style={{
              backgroundColor: config.bgColor,
              color: config.color
            }}
          >
            <i className={`mdi ${config.icon} font-14`}></i>
          </div>
          <h6 className="mb-0" style={{ fontSize: "0.85rem" }}>{config.title}</h6>
        </div>
        <div className="d-flex justify-content-between align-items-center">
          <div>
            <h5 className="mb-0" style={{ fontSize: "1rem" }}>{stats.total}</h5>
            <small className="text-muted" style={{ fontSize: "0.7rem" }}>{config.stats.total}</small>
          </div>
          <div className="text-end">
            <div className="text-success status-item">
              <i className="mdi mdi-check-circle me-1"></i>
              {stats.active} {config.stats.active}
            </div>
            <div className="text-warning status-item">
              <i className="mdi mdi-clock-outline me-1"></i>
              {stats.idle} {config.stats.idle}
            </div>
          </div>
        </div>
      </Card.Body>
    </Card>
  );
};

// Reusable Workspace Card Component
const WorkspaceCard = ({ workspace, isCurrent, onSwitch, onEdit, onDelete }) => {
  const navigate = useNavigate();
  const typeConfig = {
    production: { color: "#4e73df", icon: "mdi-shield-check" },
    development: { color: "#1cc88a", icon: "mdi-code-braces" },
    testing: { color: "#f6c23e", icon: "mdi-test-tube" },
    specialized: { color: "#e74a3b", icon: "mdi-chart-box" }
  };

  const statusColors = {
    active: "success",
    maintenance: "warning",
    inactive: "danger"
  };

  const config = typeConfig[workspace.type] || { color: "#6c757d", icon: "mdi-cube" };

  return (
    <Card className={`mb-4 shadow-sm border-0 ${isCurrent ? "border-primary" : ""}`} style={{ borderRadius: "16px" }}>
      <Card.Body className="p-4">
        <div className="d-flex justify-content-between align-items-start mb-3">
          <div className="d-flex align-items-center">
            <div className="me-3">
              <div
                className="rounded-circle d-flex align-items-center justify-content-center"
                style={{
                  width: "48px",
                  height: "48px",
                  backgroundColor: `${config.color}15`,
                  color: config.color
                }}
              >
                <i className={`mdi ${config.icon} font-24`}></i>
              </div>
            </div>
            <div>
              <h5 className="mb-1">{workspace.name}</h5>
              <div className="d-flex align-items-center gap-2">
                <Badge
                  bg={statusColors[workspace.status] || "secondary"}
                  className="rounded-pill px-3 py-1"
                  style={{ fontSize: "0.75rem" }}
                >
                  {workspace.status}
                </Badge>
                <small className="text-muted">Created: {workspace.createdAt}</small>
              </div>
            </div>
          </div>
          <Dropdown align="end">
            <Dropdown.Toggle variant="link" className="card-drop arrow-none cursor-pointer p-0 shadow-none">
              <i className="mdi mdi-dots-vertical font-18"></i>
            </Dropdown.Toggle>
            <Dropdown.Menu className="rounded-3 shadow-sm border-0">
              <Dropdown.Item onClick={() => onEdit(workspace)}>
                <i className="mdi mdi-pencil me-1"></i> Edit
              </Dropdown.Item>
              <Dropdown.Item>
                <i className="mdi mdi-content-copy me-1"></i> Duplicate
              </Dropdown.Item>
              <Dropdown.Item className="text-danger" onClick={() => onDelete(workspace)}>
                <i className="mdi mdi-delete me-1"></i> Delete
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>

        <p className="text-muted mb-4">{workspace.description}</p>

        <div className="d-flex gap-4 mt-3">
          {Object.entries(resourceTypes).map(([type, config]) => (
            <OverlayTrigger key={type} placement="top" overlay={<Tooltip>{config.title}</Tooltip>}>
              <div className="d-flex align-items-center">
                <div
                  className="rounded-circle d-flex align-items-center justify-content-center me-2"
                  style={{
                    width: "32px",
                    height: "32px",
                    backgroundColor: config.bgColor,
                    color: config.color
                  }}
                >
                  <i className={`mdi ${config.icon}`}></i>
                </div>
                <span className="fw-medium">{workspace.resources?.[type] || 0}</span>
              </div>
            </OverlayTrigger>
          ))}
        </div>

        <Button
          variant={isCurrent ? "primary" : "outline-primary"}
          className="mt-4 w-100 rounded-pill"
          onClick={() => isCurrent ? navigate("/") : onSwitch(workspace)}
          style={{
            borderWidth: "2px",
            padding: "0.5rem 1rem",
            fontWeight: "500"
          }}
        >
          {isCurrent ? "Current Workspace / Go to Dashboard" : "Switch to Workspace"}
        </Button>
      </Card.Body>
    </Card>
  );
};

const Workspaces = () => {
  const navigate = useNavigate();
  const location = useLocation();
  // const { user } = useAuthContext();
  const { currentWorkspace, workspaces, isLoading: contextLoading, switchWorkspace, refreshWorkspaces } = useWorkspaceContext();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newWorkspace, setNewWorkspace] = useState({
    name: "",
    description: "",
  });
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [workspaceToEdit, setWorkspaceToEdit] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [workspaceToDelete, setWorkspaceToDelete] = useState(null);

  const filteredWorkspaces = workspaces.filter((workspace) => {
    const matchesSearch =
      workspace?.name?.toLowerCase()?.includes(searchQuery.toLowerCase()) ||
      workspace?.description?.toLowerCase()?.includes(searchQuery.toLowerCase());
    const matchesType = filterType === "all" || workspace?.type === filterType;
    return matchesSearch && matchesType;
  });

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleCreateWorkspace = () => {
    setShowCreateModal(true);
  };

  const handleEditWorkspace = (workspace) => {
    setWorkspaceToEdit(workspace);
    setNewWorkspace({
      name: workspace.name,
      description: workspace.description
    });
    setIsEditing(true);
    setShowCreateModal(true);
  };

  const handleDeleteWorkspace = async (workspace) => {
    setWorkspaceToDelete(workspace);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!workspaceToDelete) return;

    try {
      await del(`/workspaces/${workspaceToDelete.id}`);
      toast.success("Workspace deleted successfully");
      setShowDeleteConfirm(false);
      setWorkspaceToDelete(null);
      refreshWorkspaces(); // Refresh the workspaces list
    } catch (error) {
      console.error("Error deleting workspace:", error);
      toast.error(error.response?.data?.message || "Failed to delete workspace");
    }
  };

  const handleModalSubmit = async () => {
    if (!newWorkspace.name.trim()) {
      toast.error("Workspace name is required");
      return;
    }

    setIsCreating(true);
    try {
      if (isEditing) {
        await patch(`/workspaces/${workspaceToEdit.id}`, {
          name: newWorkspace.name,
          description: newWorkspace.description
        });
        toast.success("Workspace updated successfully");
      } else {
        await post("/workspaces/", {
          name: newWorkspace.name,
          description: newWorkspace.description
        });
        toast.success("Workspace created successfully");
      }
      
      setShowCreateModal(false);
      setNewWorkspace({ name: "", description: "" });
      setWorkspaceToEdit(null);
      setIsEditing(false);
      refreshWorkspaces(); // Refresh the workspaces list
    } catch (error) {
      console.error("Error saving workspace:", error);
      toast.error(error.response?.data?.message || `Failed to ${isEditing ? 'update' : 'create'} workspace`);
    } finally {
      setIsCreating(false);
    }
  };

  const handleModalClose = () => {
    setShowCreateModal(false);
    setNewWorkspace({ name: "", description: "" });
    setWorkspaceToEdit(null);
    setIsEditing(false);
  };

  const WorkspaceCardSkeleton = () => {
    return (
      <Card
        className="mb-4 shadow-sm h-100 border-0"
        style={{ borderRadius: "16px" }}
      >
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-start mb-3">
            <div className="d-flex align-items-center">
              <div
                className="skeleton me-3 rounded-circle"
                style={{ width: "48px", height: "48px" }}
              ></div>
              <div>
                <div
                  className="skeleton mb-1 rounded-pill"
                  style={{ width: "150px", height: "24px" }}
                ></div>
                <div
                  className="skeleton rounded-pill"
                  style={{ width: "120px", height: "16px" }}
                ></div>
              </div>
            </div>
          </div>

          <div
            className="skeleton my-3 rounded-pill"
            style={{ width: "100%", height: "40px" }}
          ></div>

          <div className="d-flex gap-4 mt-3">
            <div
              className="skeleton rounded-circle"
              style={{ width: "32px", height: "32px" }}
            ></div>
            <div
              className="skeleton rounded-circle"
              style={{ width: "32px", height: "32px" }}
            ></div>
            <div
              className="skeleton rounded-circle"
              style={{ width: "32px", height: "32px" }}
            ></div>
            <div
              className="skeleton rounded-circle"
              style={{ width: "32px", height: "32px" }}
            ></div>
          </div>

          <div
            className="skeleton mt-4 rounded-pill"
            style={{ width: "100%", height: "40px" }}
          ></div>
        </Card.Body>
      </Card>
    );
  };

  return (
    <>
      <PageTitle
        breadCrumbItems={[
          { label: "Workspaces", path: "/workspaces", active: true },
        ]}
        title={"Workspaces"}
      />

      {/* Create/Edit Workspace Modal */}
      <Modal show={showCreateModal} onHide={handleModalClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>{isEditing ? "Edit Workspace" : "Create New Workspace"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Workspace Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter workspace name"
                value={newWorkspace.name}
                onChange={(e) => setNewWorkspace({ ...newWorkspace, name: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter workspace description"
                value={newWorkspace.description}
                onChange={(e) => setNewWorkspace({ ...newWorkspace, description: e.target.value })}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleModalSubmit} disabled={isCreating}>
            {isCreating ? (isEditing ? "Updating..." : "Creating...") : (isEditing ? "Update Workspace" : "Create Workspace")}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal show={showDeleteConfirm} onHide={() => setShowDeleteConfirm(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Delete Workspace</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete the workspace "{workspaceToDelete?.name}"? This action cannot be undone.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteConfirm(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={confirmDelete}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Search and Filters */}
      <Row className="mb-4">
        <Col>
          <div className="d-flex justify-content-between flex-wrap">
            <div className="mb-3 mb-xl-0" style={{ maxWidth: "400px", width: "100%" }}>
              <InputGroup className="search-group">
                <InputGroup.Text className="bg-white border-0">
                  <i className="mdi mdi-magnify text-muted"></i>
                </InputGroup.Text>
                <Form.Control
                  placeholder="Search workspaces..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  className="border-0"
                  style={{
                    padding: "0.5rem 1rem",
                    height: "40px",
                    fontSize: "0.9rem",
                    backgroundColor: "#f8f9fa"
                  }}
                />
              </InputGroup>
            </div>

            <div className="d-flex gap-2">
              <Dropdown>
                <Dropdown.Toggle variant="light" className="border-0 shadow-sm" style={{
                  height: "40px",
                  padding: "0 1rem",
                  backgroundColor: "#f8f9fa"
                }}>
                  <i className="mdi mdi-filter-variant me-1"></i>
                  {filterType === "all" ? "All Types" : filterType.charAt(0).toUpperCase() + filterType.slice(1)}
                </Dropdown.Toggle>
                <Dropdown.Menu className="rounded-3 shadow-sm border-0">
                  <Dropdown.Item onClick={() => setFilterType("all")}>All Types</Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("production")}>Production</Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("development")}>Development</Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("testing")}>Testing</Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("specialized")}>Specialized</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>

              <Button
                variant="primary"
                onClick={handleCreateWorkspace}
                className="shadow-sm"
                style={{
                  padding: "0 1.5rem",
                  height: "40px"
                }}
              >
                <i className="mdi mdi-plus me-1"></i>
                New Workspace
              </Button>
            </div>
          </div>
        </Col>
      </Row>

      {/* Workspace Cards */}
      <Row>
        {contextLoading ? (
          // Skeleton loaders while loading
          <>
            {[1, 2, 3, 4].map((i) => (
              <Col key={i} lg={4} md={6}>
                <WorkspaceCardSkeleton />
              </Col>
            ))}
          </>
        ) : (
          <>
            {filteredWorkspaces.map((workspace) => (
              <Col key={workspace.id} lg={4} md={6}>
                <WorkspaceCard
                  workspace={workspace}
                  isCurrent={currentWorkspace?.id === workspace.id}
                  onSwitch={switchWorkspace}
                  onEdit={handleEditWorkspace}
                  onDelete={handleDeleteWorkspace}
                />
              </Col>
            ))}
          </>
        )}
      </Row>
    </>
  );
};

export default Workspaces;
