const TestRunsTable = () => {
  const testRuns = [
    {
      name: 'Order Data Anomalies',
      status: 'Passed',
      recordsTested: '56K',
      duration: '1h 24m',
    },
    {
      name: 'Null Checks',
      status: 'Failed',
      recordsTested: '12.4M',
      duration: '45m',
    },
    {
      name: 'Duplication Check',
      status: 'Failed',
      recordsTested: '520K',
      duration: '18m',
    },
    {
      name: 'Customer Records',
      status: 'Skipped',
      recordsTested: '4.1M',
      duration: '—',
    },
    {
      name: 'Transaction Amount',
      status: 'Passed',
      recordsTested: '2.5M',
      duration: '1h 10m',
    },
  ];

  const getStatusBadge = (status) => {
    const statusColor = {
      Passed: 'success',
      Failed: 'danger',
      Skipped: 'secondary',
    }[status] || 'light';

    return <span className={`badge bg-${statusColor}`}>{status}</span>;
  };

  return (
    <div className="table-responsive card">
      <table className="table table-white table-striped table-sm">
        <thead>
          <tr>
            <th>Test Name</th>
            <th>Status</th>
            <th>Records Tested</th>
            <th>Duration</th>
          </tr>
        </thead>
        <tbody>
          {testRuns.map((run, index) => (
            <tr key={index}>
              <td>{run.name}</td>
              <td>{getStatusBadge(run.status)}</td>
              <td>{run.recordsTested}</td>
              <td>{run.duration}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default TestRunsTable
