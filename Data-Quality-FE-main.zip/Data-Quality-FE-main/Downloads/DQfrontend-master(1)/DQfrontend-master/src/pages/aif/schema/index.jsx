import React, { useState, useEffect, useMemo } from "react";
import { Card, Row, Col, Badge, Button, Form, InputGroup, Table, Pagination, Modal} from "react-bootstrap";
// import { useAuthContext } from "../../../context/useAuthContext";
import Loader from "../../../components/Loader";
import PageTitle from "../../../components/PageTitle";
import { getAllConnections } from "../../../api/dbapi";
const SchemaPage = () => {
  const [openModel,setModelOpen] =useState(false)
  // const { user } = useAuthContext();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedLogId, setExpandedLogId] = useState(null);
  const [filter, setFilter] = useState({
    service: "",
    action: "",
    status: "",
    dateRange: "all"
  });
 

  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
 const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setFormErrors((prev) => ({ ...prev, [name]: '' }));
  };

 
  const [searchQuery, setSearchQuery] = useState("");
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortConfig, setSortConfig] = useState({ key: 'timestamp', direction: 'desc' });

  // Fetch logs data
  useEffect(() => {
    fetchConnections()
   
  }, []);
 const fetchConnections = async () => {
    try {
      setLoading(true);
      const data = await getAllConnections();
       setLogs(data);
       setLoading(false);
    } catch (error) {
       setLoading(false);
      console.error("Error fetching connections:", error);
    }
  };
  // Filter and search logs
  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      // Apply filters
      if (filter.service && log.service !== filter.service) return false;
      if (filter.action && log.action !== filter.action) return false;
      if (filter.status && log.status !== filter.status) return false;
      
      
      
      return true;
    });
  }, [logs, filter, searchQuery]);


  // Apply sorting
  const sortedLogs = useMemo(() => {
    const sorted = [...filteredLogs];
    if (sortConfig.key) {
      sorted.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sorted;
  }, [filteredLogs, sortConfig]);

  // Paged logs
  const pagedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedLogs.slice(start, start + pageSize);
  }, [sortedLogs, currentPage, pageSize]);
  
  // Total pages
  const totalPages = Math.ceil(sortedLogs.length / pageSize);

  // Handle sorting
  const handleSort = (key) => {
    setSortConfig(prevSortConfig => ({
      key,
      direction: prevSortConfig.key === key && prevSortConfig.direction === 'asc' ? 'desc' : 'asc'
    }));
  };


  const renderLogDetails = (log) => {
    return (
      <div className="log-details p-3 bg-light border rounded mb-3">
        <h6 className="mb-3">Detailed Information</h6>
        <Row>
          <Col md={6} className="mb-2">
            <p className="mb-1"><strong>Event ID:</strong> {log.id}</p>
            <p className="mb-1"><strong>IP Address:</strong> {log.ip}</p>
            <p className="mb-1"><strong>Timestamp:</strong> {formatDate(log.timestamp)}</p>
          </Col>
          <Col md={6} className="mb-2">
            <p className="mb-1"><strong>Actor:</strong> {log.actor}</p>
            <p className="mb-1"><strong>Service:</strong> {log.service}</p>
            <p className="mb-1"><strong>Action:</strong> {log.action}</p>
          </Col>
        </Row>
        <hr />
        <h6>Event Details</h6>
        <pre className="bg-dark text-light p-3 rounded">
          {JSON.stringify(log.details, null, 2)}
        </pre>
      </div>
    );
  };

  // Render pagination controls
  const renderPagination = () => {
    return (
      <div className="d-flex justify-content-between align-items-center mt-3">
        <div>
          <Form.Select 
            className="d-inline-block me-2" 
            style={{ width: 'auto' }}
            value={pageSize}
            onChange={e => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
          >
            <option value={10}>10 rows</option>
            <option value={25}>25 rows</option>
            <option value={50}>50 rows</option>
          </Form.Select>
          <span className="text-muted">
            Showing {Math.min(sortedLogs.length, (currentPage - 1) * pageSize + 1)} to {Math.min(sortedLogs.length, currentPage * pageSize)} of {sortedLogs.length} entries
          </span>
        </div>
        
        <Pagination className="mb-0">
          <Pagination.First 
            onClick={() => setCurrentPage(1)} 
            disabled={currentPage === 1}
          />
          <Pagination.Prev 
            onClick={() => setCurrentPage(curr => Math.max(curr - 1, 1))} 
            disabled={currentPage === 1}
          />
          
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const pageNum = currentPage <= 3
              ? i + 1
              : currentPage >= totalPages - 2
                ? totalPages - 4 + i
                : currentPage - 2 + i;
                
            if (pageNum <= totalPages && pageNum > 0) {
              return (
                <Pagination.Item 
                  key={pageNum} 
                  active={pageNum === currentPage}
                  onClick={() => setCurrentPage(pageNum)}
                >
                  {pageNum}
                </Pagination.Item>
              );
            }
            return null;
          })}
          
          <Pagination.Next 
            onClick={() => setCurrentPage(curr => Math.min(curr + 1, totalPages))} 
            disabled={currentPage === totalPages || totalPages === 0}
          />
          <Pagination.Last 
            onClick={() => setCurrentPage(totalPages)} 
            disabled={currentPage === totalPages || totalPages === 0}
          />
        </Pagination>
      </div>
    );
  };

  // Sort indicator
  const getSortIndicator = (key) => {
    if (sortConfig.key !== key) return null;
    return sortConfig.direction === 'asc' ? '↑' : '↓';
  };

  return (
    <>
      <PageTitle
        breadCrumbItems={[
          { label: "Dashboard", path: "/aif/dashboard" },
          { label: "Schema Profiling", path: "/aif/logs", active: true },
        ]}
        title={"Schema Profiling"}
      />

      <Row>
        <Col>
          <Card>
            <Card.Body>
              {/* <h4 className="header-title mb-3">Schema Profiling</h4> */}
              
              <Row className="mb-3 mt-2">
                <Col md={9}>
                  <InputGroup>
                    <InputGroup.Text>
                      <i className="mdi mdi-magnify"></i>
                    </InputGroup.Text>
                    <Form.Control
                      placeholder="Search Schemas..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </InputGroup>
                </Col>
                <Col md={3}>
                  <div className="d-flex justify-content-end">
                    {/* <Button 
                      variant="light" 
                      className="me-2" 
                      onClick={handleResetFilters}
                    >
                      <i className="mdi mdi-filter-remove"></i> Reset
                    </Button> */}
                    <Button 
                      variant="primary"
                      onClick={() => {
                       setModelOpen(true),
                        setFormErrors({});
                      }}
                    >
                     <i className="mdi mdi-plus me-1"></i>  Add Schema
                    </Button>
                  </div>
                </Col>
              </Row>

              {loading ? (
                <div className="d-flex justify-content-center my-5">
                  <Loader />
                </div>
              ) : (
                <>
                  {filteredLogs.length === 0 ? (
                    <div className="text-center py-5">
                      <i className="mdi mdi-file-search text-muted" style={{ fontSize: '3rem' }}></i>
                      <h5 className="mt-3">No connections found</h5>
                      <p className="text-muted">
                        Try adjusting your search or filter criteria
                      </p>
                      {/* <Button variant="light" onClick={handleResetFilters}>
                        Reset Filters
                      </Button> */}
                    </div>
                  ) : (
                    <>
                      {expandedLogId && (
                        renderLogDetails(logs.find(log => log.id === expandedLogId))
                      )}
                    
                      <div className="table-responsive">
                        <Table striped hover>
                          <thead>
                            <tr>
                              <th 
                                className="sortable" 
                                onClick={() => handleSort('name')}
                                style={{ cursor: 'pointer' }}
                              >
                               Table Name {getSortIndicator('name')}
                              </th>
                              <th 
                                className="sortable" 
                                onClick={() => handleSort('type')}
                                style={{ cursor: 'pointer' }}
                              >
                               Columns {getSortIndicator('type')}
                              </th>
                            
                              
                            </tr>
                          </thead>
                          <tbody>
                            {pagedLogs.map(log => (
                              <tr key={log.id}>
                                <td>{log.connection_name}</td>
                                <td>{log.sql_flavor}</td>
                                    
                              </tr>
                            ))}
                          </tbody>
                        </Table>
                      </div>
                      
                      {renderPagination()}
                    </>
                  )}
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
 

    </>
  );
};

export default SchemaPage;
