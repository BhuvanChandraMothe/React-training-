import { useEffect, useState } from "react";
import { getDataSources } from "../../../../api/dbapi";

const DataSourcesPanel = () => {
   const [sources,setDataSources]=useState(null)
     useEffect(() => {
            fetchDataSources();
        }, []);
const fetchDataSources = async () => {
              try {
                  const data = await getDataSources();
                  setDataSources(data);
                
              } catch (err) {
                  // setErrorDashboard(err);
                  console.error('Error fetching dashboard overview:', err);
              } finally {
                  // setLoadingDashboard(false);
              }
          };
  return (
    <div className="bg-white card text-black rounded shadow-sm">
      <h6 className=" p-2 pb-0 m-2 mb-0">Data Sources</h6>
   <div className="table-responsive card p-2">
      <table className="table table-white table-striped table-sm">
        <thead className="text-muted small">
          <tr>
            <th>Name</th>
            <th>Test Data Quality Score</th>
          </tr>
        </thead>
        <tbody>
          {sources?.map((src, i) => (
            <tr key={src?.connection_id}>
              <td>{src.connection_name}</td>
              <td>{src.data_quality_score}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
};
export default DataSourcesPanel