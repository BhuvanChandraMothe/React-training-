import React, { useEffect, useState } from "react";
import { Row, Col, Button, Alert } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
// import { useAuthContext } from "../../../context/useAuthContext";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AppCard from "./components/AppCard";
import { get } from "../../../api/io";
import { useWorkspaceContext } from "../../../context/useWorkspaceContext";

const Agents = () => {
  // const { user } = useAuthContext();
  const { currentWorkspace } = useWorkspaceContext();
  const navigate = useNavigate();

  const [agents, setAgents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  // Filter agents based on search query
  const filterAgents = (agents) => {
    if (!searchQuery) return agents;
    return agents.filter(
      (agent) =>
        agent.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        agent.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  // Inject CSS animation to head
  useEffect(() => {
    if (!document.getElementById("skeleton-animation-style")) {
      const style = document.createElement("style");
      style.id = "skeleton-animation-style";
      style.innerHTML = `
        @keyframes pulse {
          0% { opacity: 0.5; }
          50% { opacity: 0.9; }
          100% { opacity: 0.5; }
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  const fetchAgents = () => {
    setIsLoading(true);
    get(
      `/apps/?mode=${
        window.location.pathname === "/chatbots" ? "chat" : "agent"
      }&workspace_id=${currentWorkspace?.id}`
    )
      .then((data) => {
        // Transform the API response to match AppCard expected format
        const transformedAgents = Array.isArray(data)
          ? data.map((agent) => ({
              title: agent.name,
              type: "ai-agent",
              description: agent.description,
              status: agent.status === "normal" ? "active" : agent.status,
              path: `/agents/${agent.id}`,
              id: agent.id,
            }))
          : [];
        setAgents(transformedAgents);
        setIsLoading(false);
      })
      .catch((err) => {
        console.error("Error:", err.message);
        setIsLoading(false);
      });
  };

  useEffect(() => {
    fetchAgents();
  }, []);

  const handleAgentDelete = (agentId) => {
    // Filter out the deleted agent from the agents array
    setAgents(agents.filter((agent) => agent.id !== agentId));
  };

  // Skeleton placeholders for loading state
  const AppCardSkeleton = () => {
    return (
      <div
        className="card h-100 app-card"
        style={{
          opacity: 1,
          border: "1px solid #e2e6ea",
          boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
        }}
      >
        <div className="card-body p-3">
          <div className="d-flex align-items-center mb-2">
            <div
              className="app-icon me-2 p-2 rounded-circle"
              style={{
                width: 40,
                height: 40,
                backgroundColor: "#e9ecef",
                animation: "pulse 1.3s infinite ease-in-out",
              }}
            ></div>
            <div className="flex-grow-1">
              <div
                style={{
                  height: 18,
                  width: "70%",
                  borderRadius: 4,
                  backgroundColor: "#dee2e6",
                  animation: "pulse 1.7s infinite ease-in-out",
                }}
                className="mb-1"
              ></div>
              <div className="d-flex align-items-center">
                <div
                  style={{
                    height: 16,
                    width: 60,
                    borderRadius: 4,
                    backgroundColor: "#e2e6ea",
                    animation: "pulse 1.5s infinite ease-in-out",
                  }}
                  className="me-2"
                ></div>
                <div
                  style={{
                    height: 14,
                    width: 80,
                    borderRadius: 4,
                    backgroundColor: "#e2e6ea",
                    animation: "pulse 1.8s infinite ease-in-out",
                  }}
                ></div>
              </div>
            </div>
            <div className="dropdown">
              <div
                style={{
                  height: 24,
                  width: 24,
                  borderRadius: 4,
                  backgroundColor: "#e9ecef",
                  animation: "pulse 1.4s infinite ease-in-out",
                }}
              ></div>
            </div>
          </div>
          <div className="mt-3">
            <div
              style={{
                height: 16,
                width: "90%",
                borderRadius: 4,
                backgroundColor: "#dee2e6",
                animation: "pulse 1.9s infinite ease-in-out",
              }}
              className="mb-2"
            ></div>
            <div
              style={{
                height: 16,
                width: "80%",
                borderRadius: 4,
                backgroundColor: "#dee2e6",
                animation: "pulse 1.6s infinite ease-in-out",
              }}
              className="mb-2"
            ></div>
            <div
              style={{
                height: 36,
                width: "100%",
                borderRadius: 4,
                backgroundColor: "#e9ecef",
                animation: "pulse 1.5s infinite ease-in-out",
              }}
              className="mt-3"
            ></div>
          </div>
        </div>
      </div>
    );
  };

  const SkeletonAgentSection = () => {
    return (
      <div className="mb-4 mt-3">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <div>
            <h4 className="text-primary m-0 section-header">AI Agents</h4>
            <p className="text-muted small mb-0 mt-1">
              Manage and access your AI-powered agents
            </p>
          </div>
          <Button
            variant="soft-primary"
            size="sm"
            className="rounded-pill px-3 d-flex align-items-center"
          >
            <span>View All</span>
            <i className="mdi mdi-arrow-right ms-1"></i>
          </Button>
        </div>
        <Row className="g-3">
          <Col key="new" sm={6} lg={4} xl={3}>
            <div
              className="card folder-card h-100 create-kb-card"
              onClick={() => navigate("/agents/create")}
              style={{
                cursor: "pointer",
                transition: "transform 0.2s, box-shadow 0.2s",
                border: "2px dashed #e9ecef",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow =
                  "0 .3rem 1rem rgba(0,0,0,.08)";
                e.currentTarget.style.borderColor = "#556ee6";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.boxShadow = "";
                e.currentTarget.style.borderColor = "#e9ecef";
              }}
            >
              <div className="card-body d-flex flex-column align-items-center justify-content-center p-3">
                <div className="create-icon mb-2">
                  <i className="mdi mdi-plus-circle font-32 text-primary"></i>
                </div>
                <h5 className="card-title mb-1">Create New</h5>
                <p className="text-muted text-center mb-0">
                  Create a new agent
                </p>
              </div>
            </div>
          </Col>
          {[...Array(3)].map((_, idx) => (
            <Col key={`skeleton-${idx}`} sm={6} lg={4} xl={3}>
              <AppCardSkeleton />
            </Col>
          ))}
        </Row>
      </div>
    );
  };

  return (
    <div className="agents-container">
      <ToastContainer position="top-right" autoClose={3000} />

      {/* No Results Message */}
      {searchQuery && filterAgents(agents).length === 0 && !isLoading && (
        <div className="animate-fade-in mt-2 mb-3">
          <Alert variant="info" className="text-center mb-0 py-2">
            <i className="mdi mdi-information-outline me-2"></i>
            No agents found matching "{searchQuery}"
            <Button
              variant="link"
              className="p-0 ms-2"
              onClick={() => setSearchQuery("")}
            >
              Clear search
            </Button>
          </Alert>
        </div>
      )}

      {/* Agents Section */}
      <div className="animate-fade-in animate-delay-3">
        {isLoading ? (
          <SkeletonAgentSection />
        ) : (
          <div className="mb-4 mt-3">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <div>
                <h4 className="text-primary m-0 section-header">
                  {window.location.pathname === "/chatbots"
                    ? "Chatbots"
                    : "AI Agents"}
                </h4>
                <p className="text-muted small mb-0 mt-1">
                  Manage and access your AI-powered agents
                </p>
              </div>
            </div>
            <Row className="g-3">
              <Col key="new" sm={6} lg={4} xl={3}>
                <div
                  className="card folder-card h-100 create-kb-card"
                  onClick={() => navigate("/aif/agents/create")}
                  style={{
                    cursor: "pointer",
                    transition: "transform 0.2s, box-shadow 0.2s",
                    border: "2px dashed #e9ecef",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-2px)";
                    e.currentTarget.style.boxShadow =
                      "0 .3rem 1rem rgba(0,0,0,.08)";
                    e.currentTarget.style.borderColor = "#556ee6";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "none";
                    e.currentTarget.style.boxShadow = "";
                    e.currentTarget.style.borderColor = "#e9ecef";
                  }}
                >
                  <div className="card-body d-flex flex-column align-items-center justify-content-center p-3">
                    <div className="create-icon mb-2">
                      <i className="mdi mdi-plus-circle font-32 text-primary"></i>
                    </div>
                    <h5 className="card-title mb-1">Create New</h5>
                    <p className="text-muted text-center mb-0">
                      Create a new agent
                    </p>
                  </div>
                </div>
              </Col>
              {filterAgents(agents).map((agent) => (
                <Col key={agent.id} sm={6} lg={4} xl={3}>
                  <AppCard
                    {...agent}
                    onDelete={() => handleAgentDelete(agent.id)}
                  />
                </Col>
              ))}
            </Row>
          </div>
        )}
      </div>
    </div>
  );
};

export default Agents;
