// // components/ProfileRunTrendChart.tsx
// import React from 'react';
// import {
//   Line
// } from 'react-chartjs-2';
// import {
//   Chart as ChartJS,
//   LineElement,
//   PointElement,
//   CategoryScale,
//   LinearScale,
//   Tooltip,
//   Legend,
//   Filler
// } from 'chart.js';

// ChartJS.register(
//   LineElement,
//   PointElement,
//   CategoryScale,
//   LinearScale,
//   Tooltip,
//   Legend,
//   Filler
// );

// const ProfileRunTrendChart = () => {
//   const data = {
//     labels: ['12', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '21'],
//     datasets: [
//       {
//         label: 'Profile Runs',
//         data: [12, 18, 22, 19, 24, 23, 32, 28, 20, 25, 30, 27, 33],
//         fill: true,
//         backgroundColor: 'rgba(99, 102, 241, 0.2)',
//         borderColor: '#6366f1',
//         pointBackgroundColor: '#6366f1',
//         tension: 0.3
//       }
//     ]
//   };

//   const options = {
//     responsive: true,
//     maintainAspectRatio: false,
//     scales: {
//       y: {
//         min: 10,
//         max: 40,
//         ticks: {
//           stepSize: 5
//         },
//         grid: {
//           drawBorder: false
//         }
//       },
//       x: {
//         grid: {
//           drawBorder: false
//         }
//       }
//     },
//     plugins: {
//       legend: {
//         display: false
//       },
//       tooltip: {
//         intersect: false
//       }
//     }
//   };

//   return (
//     <div className="bg-white p-3 rounded shadow-md h-64">
//       <h4 className="text-lg font-semibold mb-3">Profile Run Trend</h4>
//       <div className="h-full">
//         <Line data={data} options={options} />
//       </div>
//     </div>
//   );
// };

// export default ProfileRunTrendChart;
import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import {  profileRunTrend } from '../../../../api/dbapi'; // Adjust to your API import

ChartJS.register(
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  Filler
);

const ProfileRunTrendChart = () => {
  const [chartData, setChartData] = useState(null);

  useEffect(() => {
    fetchProfileRunData();
  }, []);

  const fetchProfileRunData = async () => {
    try {
      const response = await profileRunTrend();
      const sortedData = response?.trend_data.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      const labels = sortedData.map(item => item.date);
      const totalRuns = sortedData.map(item => item.total_runs);
      const successfulRuns = sortedData.map(item => item.successful_runs);
      const avgDQScores = sortedData.map(item => item.avg_dq_score);

      setChartData({
        labels,
        datasets: [
          {
            label: 'Total Runs',
            data: totalRuns,
            yAxisID: 'y1',
            borderColor: '#6366f1',
            backgroundColor: 'rgba(99, 102, 241, 0.2)',
            pointBackgroundColor: '#6366f1',
            tension: 0.3,
            fill: true
          },
          {
            label: 'Successful Runs',
            data: successfulRuns,
            yAxisID: 'y1',
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(251, 191, 36, 0.2)',
            pointBackgroundColor: '#f59e0b',
            tension: 0.3,
            fill: true
          },
          {
            label: 'Avg DQ Score',
            data: avgDQScores,
            yAxisID: 'y2',
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.2)',
            pointBackgroundColor: '#10b981',
            tension: 0.3,
            fill: false
          }
        ]
      });
    } catch (error) {
      console.error('Error fetching profile run data:', error);
    }
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y1: {
        type: 'linear',
        position: 'left',
        title: {
          display: true,
          text: 'Runs'
        },
        grid: {
          drawBorder: false
        },
        beginAtZero: true
      },
      y2: {
        type: 'linear',
        position: 'right',
        title: {
          display: true,
          text: 'Avg DQ Score'
        },
        grid: {
          drawOnChartArea: false
        },
        min: 0,
        max: 1,
        ticks: {
          stepSize: 0.1
        }
      },
      x: {
        title: {
          display: true,
          text: 'Date'
        },
        grid: {
          drawBorder: false
        }
      }
    },
    plugins: {
      legend: {
        position: 'top'
      },
      tooltip: {
        intersect: false
      }
    }
  };

  return (
    <div className="bg-white p-3 rounded shadow-md h-[500px]">
      <h4 className="text-lg font-semibold mb-3">Profile Run Trend</h4>
      <div className="h-full">
        {chartData ? (
          <Line data={chartData} options={options} />
        ) : (
          <p>Loading chart...</p>
        )}
      </div>
    </div>
  );
};

export default ProfileRunTrendChart;
