// import { Line } from 'react-chartjs-2';
// import {
//   Chart as ChartJS,
//   LineElement,
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   Legend,
//   Tooltip,
// } from 'chart.js';
// import { useEffect, useState } from 'react';
// import { getLineTrends } from '../../../../api/dbapi';

// ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Legend, Tooltip);

// const TrendGraph = (duration,metrics) => {
//   const data = {
//     labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
//     datasets: [
//       {
//         label: 'Data Quality Trend Score (%)',
//         data: [88, 90, 85, 92, 91, 93, 94],
//         fill: false,
//         borderColor: 'rgba(75,192,192,1)',
//         tension: 0.3,
//         pointBackgroundColor: '#fff'
//       }
//     ]
//   };

//   const options = {
//     responsive: true,
//     scales: {
//       y: {
//         min: 0,
//         max: 100,
//         ticks: {
//           stepSize: 10
//         }
//       }
//     },
//     plugins: {
//       legend: {
//         labels: {
//           color: 'balck'
//         }
//       }
//     }
//   };
//  const [sources,setDataSources]=useState(null)
//      useEffect(() => {
//             fetchDataSources();
//         }, []);
// const fetchDataSources = async () => {
//               try {
//                   const data = await getLineTrends(duration,metrics);
//                   setDataSources(data);
                
//               } catch (err) {
//                   // setErrorDashboard(err);
//                   console.error('Error fetching dashboard overview:', err);
//               } finally {
//                   // setLoadingDashboard(false);
//               }
//           };
//   return (
//     <div className="bg-white card p-3 pb-0 rounded">
//       <Line data={data} options={options} />
//     </div>
//   );
// };
// export default TrendGraph
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Legend,
  Tooltip,
} from 'chart.js';
import { useEffect, useState } from 'react';
import { getLineTrends } from '../../../../api/dbapi';

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Legend, Tooltip);

const TrendGraph = ({ duration }) => {
   const [metrics,setMetrics]=useState('dq_score')
  const [graphData, setGraphData] = useState(null);
 const changeStatusGroup=(e)=>{
            setMetrics(e)
          }
  useEffect(() => {
    fetchDataSources();
  }, [duration, metrics]);

  const fetchDataSources = async () => {
    try {
      const data = await getLineTrends(duration, metrics);
      setGraphData(data);
    } catch (err) {
      console.error('Error fetching trend data:', err);
    }
  };

  // Convert API response into chart.js format
  const formatChartData = () => {
    if (!graphData || !graphData.trend_data) return null;

    const labels = graphData.trend_data.map(item => `Day ${item.day}`);
    const values = graphData.trend_data.map(item => item.value);

    return {
      labels,
      datasets: [
        {
          label: graphData.metric_label || 'Trend',
          data: values,
          fill: false,
          borderColor: 'rgba(75,192,192,1)',
          tension: 0.3,
          pointBackgroundColor: '#fff',
        },
      ],
    };
  };

  const options = {
    responsive: true,
    scales: {
      y: {
        min: 0,
        max: 100,
        ticks: {
          stepSize: 10,
        },
      },
    },
    plugins: {
      legend: {
        labels: {
          color: 'black',
        },
      },
    },
  };

  const chartData = formatChartData();

  return (
    <>
    
     <select className="form-select my-1 my-lg-0" onChange={e => changeStatusGroup(e.target.value)}>
                        <option defaultValue="">Select Score/Count </option>
                        <option value="dq_score">Data Quality Score</option>
                        <option value="test_failures_count">Test Failures Count</option>
                      </select>
                      
    <div className="bg-white card p-3 pb-0 rounded mt-2">
       <h6 className="pb-0 mb-2">Test Trends</h6>
      {chartData ? (
        <Line data={chartData} options={options} />
      ) : (
        <p className="text-center">Loading trend data...</p>
      )}
    </div>
    </>
  );
};

export default TrendGraph;
