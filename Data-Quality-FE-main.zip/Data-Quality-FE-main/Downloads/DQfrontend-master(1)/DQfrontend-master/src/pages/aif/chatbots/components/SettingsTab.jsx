import React from 'react';
import { Form } from 'react-bootstrap';

const SettingsTab = ({ config, handleSettingChange }) => {
  return (
    <Form>
      <Form.Group className="mb-3">
        <Form.Label>Welcome Text</Form.Label>
        <Form.Control
          type="text"
          value={config.settings.welcomeText}
          onChange={(e) => handleSettingChange("welcomeText", e)}
        />
      </Form.Group>

      <Form.Check
        type="switch"
        id="speech-to-text"
        label="Enable Speech to Text"
        checked={config.settings.enableSpeechToText}
        onChange={(e) => handleSettingChange("enableSpeechToText", e)}
        className="mb-2"
      />

      <Form.Check
        type="switch"
        id="show-source"
        label="Show Document Source"
        checked={config.settings.showDocumentSource}
        onChange={(e) => handleSettingChange("showDocumentSource", e)}
        className="mb-2"
      />

      <Form.Check
        type="switch"
        id="moderate-output"
        label="Moderate Output"
        checked={config.settings.moderateOutput}
        onChange={(e) => handleSettingChange("moderateOutput", e)}
        className="mb-2"
      />
    </Form>
  );
};

export default SettingsTab; 