import React from "react";

const Index = (props) => {
  return <div>Tools</div>;
};

export default Index;
