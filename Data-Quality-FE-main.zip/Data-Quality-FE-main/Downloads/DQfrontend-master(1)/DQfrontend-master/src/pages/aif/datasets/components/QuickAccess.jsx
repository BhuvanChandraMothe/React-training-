import React from 'react';
import { Card, Row, Col } from 'react-bootstrap';

const QuickAccess = ({ quickAccessFiles }) => {
  return (
    <Row>
      {quickAccessFiles.map((file, index) => (
        <Col key={index} sm={6} md={4} lg={3} className="mb-4">
          <Card className="h-100">
            <Card.Body>
              <div className="d-flex align-items-center mb-3">
                <div className="flex-shrink-0">
                  <i className={`bi ${file.icon} fs-2 text-primary`}></i>
                </div>
                <div className="flex-grow-1 ms-3">
                  <h5 className="mb-0">{file.category}</h5>
                </div>
              </div>
              <div className="text-muted">
                <p className="mb-1">{file.count} files</p>
                <p className="mb-0">{file.size}</p>
              </div>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default QuickAccess; 