import React, { useState } from "react";
import {
    Modal,
    Form,
    Row,
    Col,
    Button,
} from "react-bootstrap";
import { createTableGroup } from "../../../../api/dbapi";

const initialFormValues = {
    table_group_name: '',
    table_group_schema: '',
    explicit_table_list: '',
    profiling_include_mask: '%',
    profiling_exclude_mask: 'tmp%',
    profile_id_column_mask: '%id',
    profile_sk_column_mask: '%_sk',
    profile_use_sampling: 'N',
    profile_sample_percent: '30',
    profile_sample_min_count: 100000,
    min_profiling_age_days: 0,
    profile_flag_cdes: true,
    use_profile_sampling: false,
    profile_do_pair_rules: 'N',
    profile_pair_rule_pct: 95,
    description: '',
    data_source: '',
    source_system: '',
    source_process: '',
    data_location: '',
    business_domain: '',
    stakeholder_group: '',
    transform_level: '',
    data_product: '',
    scorecard: false,
};

function AddTableGroup({ open, onClose, connectionId }) {
    const [formValues, setFormValues] = useState(initialFormValues);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState(null);
    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormValues(prev => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError(null);

        try {
            // Sanitize payload before submission
            const payload = {
                ...formValues,
                connection_id: connectionId,

                // Convert boolean-like fields
                profile_use_sampling:
                    formValues.profile_use_sampling === 'Y' || formValues.profile_use_sampling === true ? 'Y' : 'N',

                profile_do_pair_rules:
                    formValues.profile_do_pair_rules === true || formValues.profile_do_pair_rules === 'Y' ? 'Y' : 'N',

                profile_sample_percent: formValues.profile_sample_percent || '30',
                profile_sample_min_count:
                    formValues.profile_sample_min_count !== '' && formValues.profile_sample_min_count !== null
                        ? parseInt(formValues.profile_sample_min_count, 10)
                        : 100000,

                min_profiling_age_days:
                    formValues.min_profiling_age_days !== '' && formValues.min_profiling_age_days !== null
                        ? parseInt(formValues.min_profiling_age_days, 10)
                        : 0,

                profile_pair_rule_pct:
                    formValues.profile_pair_rule_pct !== '' && formValues.profile_pair_rule_pct !== null
                        ? parseInt(formValues.profile_pair_rule_pct, 10)
                        : 95,

                profile_flag_cdes: !!formValues.profile_flag_cdes,
                scorecard: !!formValues.scorecard,

                // Optional strings — use empty string or fallback defaults instead of null
                table_group_schema: formValues.table_group_schema || '',
                explicit_table_list: formValues.explicit_table_list || '',
                profiling_include_mask: formValues.profiling_include_mask || '%',
                profiling_exclude_mask: formValues.profiling_exclude_mask || 'tmp%',
                profile_id_column_mask: formValues.profile_id_column_mask || '%id',
                profile_sk_column_mask: formValues.profile_sk_column_mask || '%_sk',
                description: formValues.description || '',
                data_source: formValues.data_source || '',
                source_system: formValues.source_system || '',
                source_process: formValues.source_process || '',
                data_location: formValues.data_location || '',
                business_domain: formValues.business_domain || '',
                stakeholder_group: formValues.stakeholder_group || '',
                transform_level: formValues.transform_level || '',
                data_product: formValues.data_product || '',
            };

            console.log('Submitting cleaned payload:', payload);

            // Make API request
            await createTableGroup(connectionId, payload);
            setFormValues(initialFormValues);
            // Close modal and notify parent
            onClose();
        } catch (err) {
            console.error('Error creating table group:', err);
            setError(err.response?.data?.detail || err.message || 'Failed to create table group.');
        } finally {
            setIsSubmitting(false);
        }
    };
    if (!open) return null;

    return (
        <Modal show={open} onHide={onClose} centered size="lg" scrollable>
            <Modal.Header closeButton>
                <Modal.Title>Add Table Group</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                <Form onSubmit={handleSubmit}>

                    {/* Basic Info */}
                    <h5 className="mb-3">Basic Information</h5>
                    <Row>
                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="table_group_name">
                                <Form.Label>Table Group Name</Form.Label>
                                <Form.Control
                                    name="table_group_name"
                                    type="text"
                                    placeholder="Enter Table Group Name"
                                    value={formValues.table_group_name}
                                    onChange={handleChange}
                                    required
                                />
                            </Form.Group>
                        </Col>

                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="table_group_schema">
                                <Form.Label>DB Schema</Form.Label>
                                <Form.Control
                                    name="table_group_schema"
                                    type="text"
                                    placeholder="Enter DB Schema"
                                    value={formValues.table_group_schema}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col >
                            <Form.Group className="mb-4" controlId="explicit_table_list">
                                <Form.Label>Table Name</Form.Label>
                                <Form.Control
                                    name="explicit_table_list"
                                    type="text"
                                    placeholder="Enter Table Name"
                                    value={formValues.explicit_table_list}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>
                    </Row>

                    {/* Table List */}


                    {/* Profiling Masks */}
                    {/* Profiling Masks - 2x2 grid */}
                    <h5 className="mb-3">Profiling Masks</h5>
                    <Row>
                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="profiling_include_mask">
                                <Form.Label>Include Mask</Form.Label>
                                <Form.Control
                                    name="profiling_include_mask"
                                    type="text"
                                    placeholder="e.g., %"
                                    value={formValues.profiling_include_mask}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>

                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="profiling_exclude_mask">
                                <Form.Label>Exclude Mask</Form.Label>
                                <Form.Control
                                    name="profiling_exclude_mask"
                                    type="text"
                                    placeholder="e.g., tmp%"
                                    value={formValues.profiling_exclude_mask}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row>
                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="profile_id_column_mask">
                                <Form.Label>ID Column Mask</Form.Label>
                                <Form.Control
                                    name="profile_id_column_mask"
                                    type="text"
                                    placeholder="e.g., %id"
                                    value={formValues.profile_id_column_mask}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>

                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="profile_sk_column_mask">
                                <Form.Label>SK Column Mask</Form.Label>
                                <Form.Control
                                    name="profile_sk_column_mask"
                                    type="text"
                                    placeholder="e.g., %_sk"
                                    value={formValues.profile_sk_column_mask}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>
                    </Row>


                    {/* Sampling */}
                    <h5 className="mb-3">Sampling</h5>
                    <Row>
                        <Col md={4}>
                            <Form.Group className="mb-3" controlId="profile_use_sampling">
                                <Form.Label>Use Sampling?</Form.Label>
                                <Form.Select
                                    name="profile_use_sampling"
                                    value={formValues.profile_use_sampling}
                                    onChange={handleChange}
                                >
                                    <option value="Y">Yes</option>
                                    <option value="N">No</option>
                                </Form.Select>
                            </Form.Group>
                        </Col>

                        <Col md={4}>
                            <Form.Group className="mb-3" controlId="profile_sample_percent">
                                <Form.Label>Sample Percent (%)</Form.Label>
                                <Form.Control
                                    name="profile_sample_percent"
                                    type="number"
                                    value={formValues.profile_sample_percent}
                                    onChange={handleChange}
                                    disabled={formValues.profile_use_sampling === "N"}
                                    min={1}
                                    max={100}
                                />
                            </Form.Group>
                        </Col>

                        <Col md={4}>
                            <Form.Group className="mb-3" controlId="profile_sample_min_count">
                                <Form.Label>Sample Min Count</Form.Label>
                                <Form.Control
                                    name="profile_sample_min_count"
                                    type="number"
                                    value={formValues.profile_sample_min_count}
                                    onChange={handleChange}
                                    disabled={formValues.profile_use_sampling === "N"}
                                    min={0}
                                />
                            </Form.Group>
                        </Col>
                    </Row>

                    {/* Other Profiling Settings */}
                    <Row className="mb-3 align-items-center">
                        <Col md={6}>
                            <Form.Group controlId="min_profiling_age_days">
                                <Form.Label>Min Profiling Age (Days)</Form.Label>
                                <Form.Control
                                    name="min_profiling_age_days"
                                    type="number"
                                    value={formValues.min_profiling_age_days}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>

                        <Col md={6}>
                            <Form.Group controlId="profile_pair_rule_pct">
                                <Form.Label>Pair Rule %</Form.Label>
                                <Form.Control
                                    name="profile_pair_rule_pct"
                                    type="number"
                                    value={formValues.profile_pair_rule_pct}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>
                    </Row>

                    <Row className="mb-3">
                        <Col md={4}>
                            <Form.Check
                                type="checkbox"
                                label="Profile Flag CDEs"
                                name="profile_flag_cdes"
                                checked={formValues.profile_flag_cdes}
                                onChange={handleChange}
                            />
                        </Col>
                        <Col md={4}>
                            <Form.Check
                                type="checkbox"
                                label="Use Profile Sampling"
                                name="use_profile_sampling"
                                checked={formValues.use_profile_sampling}
                                onChange={handleChange}
                            />
                        </Col>
                        <Col md={4}>
                            <Form.Check
                                type="checkbox"
                                label="Profile Do Pair Rules"
                                name="profile_do_pair_rules"
                                checked={formValues.profile_do_pair_rules}
                                onChange={handleChange}
                            />
                        </Col>
                    </Row>



                    {/* Description and Metadata */}
                    <h5 className="mb-3">Description & Metadata</h5>


                    <Row>
                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="data_source">
                                <Form.Label>Data Source</Form.Label>
                                <Form.Control
                                    name="data_source"
                                    type="text"
                                    value={formValues.data_source}
                                    onChange={handleChange}
                                    placeholder="Data Sources"
                                />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="source_system">
                                <Form.Label>Source System</Form.Label>
                                <Form.Control
                                    name="source_system"
                                    type="text"
                                    value={formValues.source_system}
                                    onChange={handleChange}
                                    placeholder="Source System"
                                />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="source_process">
                                <Form.Label>Source Process</Form.Label>
                                <Form.Control
                                    name="source_process"
                                    type="text"
                                    value={formValues.source_process}
                                    onChange={handleChange}
                                    placeholder="Source Process"
                                />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="data_location">
                                <Form.Label>Data Location</Form.Label>
                                <Form.Control
                                    name="data_location"
                                    type="text"
                                    value={formValues.data_location}
                                    onChange={handleChange}
                                    placeholder="Data Location"
                                />
                            </Form.Group>
                        </Col>

                        <Col md={6}>
                            <Form.Group className="mb-3" controlId="business_domain">
                                <Form.Label>Business Domain</Form.Label>
                                <Form.Control
                                    name="business_domain"
                                    type="text"
                                    value={formValues.business_domain}
                                    onChange={handleChange}
                                    placeholder="Business Domain"
                                />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="stakeholder_group">
                                <Form.Label>Stakeholder Group</Form.Label>
                                <Form.Control
                                    name="stakeholder_group"
                                    type="text"
                                    value={formValues.stakeholder_group}
                                    onChange={handleChange}
                                    placeholder="Stakeholder Group"
                                />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="transform_level">
                                <Form.Label>Transform Level</Form.Label>
                                <Form.Control
                                    name="transform_level"
                                    type="text"
                                    value={formValues.transform_level}
                                    onChange={handleChange}
                                    placeholder="Transform Level"
                                />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="data_product">
                                <Form.Label>Data Product</Form.Label>
                                <Form.Control
                                    name="data_product"
                                    type="text"
                                    value={formValues.data_product}
                                    onChange={handleChange}
                                    placeholder="Data Product"
                                />
                            </Form.Group>
                        </Col>
                    </Row>
                    <Form.Group className="mb-3" controlId="description">
                        <Form.Label>Description</Form.Label>
                        <Form.Control
                            name="description"  // ✅ Correct key to match your state
                            as="textarea"
                            rows={3}
                            value={formValues.description}
                            onChange={handleChange}
                            placeholder="Enter Description"
                        />
                    </Form.Group>


                    {/* Scorecard */}
                    <Form.Group className="mb-3">
                        <Form.Check
                            type="checkbox"
                            label="Enable Scorecard for Table Group"
                            name="scorecard"
                            checked={formValues.scorecard}
                            onChange={handleChange}
                        />
                    </Form.Group>


                    {/* Buttons */}
                    {/* Buttons */}
                    <div className="d-flex justify-content-end mt-4">
                        <Button variant="secondary" onClick={onClose} className="me-2">
                            Cancel
                        </Button>
                        <Button type="submit" variant="primary" disabled={isSubmitting}>
                            {isSubmitting ? 'Submitting...' : 'Submit'}
                        </Button>
                    </div>

                    {/* Error message */}
                    {error && (
                        <div className="alert alert-danger mt-3" role="alert">
                            {error}
                        </div>
                    )}

                    {/* Spinner */}
                    {isSubmitting && (
                        <div className="d-flex justify-content-center my-3">
                            <div className="spinner-border" role="status" aria-hidden="true"></div>
                            <span className="ms-2">Saving...</span>
                        </div>
                    )}

                </Form>
            </Modal.Body>
        </Modal>
    );
}

export default AddTableGroup;
