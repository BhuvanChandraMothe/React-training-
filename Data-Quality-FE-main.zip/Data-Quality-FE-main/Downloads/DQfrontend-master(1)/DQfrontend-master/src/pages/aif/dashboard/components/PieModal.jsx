import React, { useEffect, useState } from 'react';
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { getTestResultsDetailed, getTestTpeSummary, } from '../../../../api/dbapi';

ChartJS.register(ArcElement, Tooltip, Legend);

const PieModal = ({ status, onClose }) => {
  const [typeData, setTypeData] = useState({});
  const [hoveredType, setHoveredType] = useState('');
  const [hoveredDetails, setHoveredDetails] = useState([]);

  useEffect(() => {
    (async () => {
      const data = await getTestTpeSummary(status);
      setTypeData(data || {});
    })();
  }, [status]);

  const handleHover = async (_, elements) => {
    if (!elements.length) {
      setHoveredType('');
      setHoveredDetails([]);
      return;
    }

    const index = elements[0].index;
    const type = Object.keys(typeData)[index];

    if (type && type !== hoveredType) {
      setHoveredType(type);
      const details = await getTestResultsDetailed(status, type);
      setHoveredDetails(details || []);
    }
  };

  const chartData = {
    labels: Object.keys(typeData),
    datasets: [
      {
        data: Object.values(typeData),
        backgroundColor: ['#007bff', '#28a745', '#fd7e14', '#6f42c1'],
        borderColor: '#fff',
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-lg p-6 w-[800px] h-[500px] relative shadow-xl">
        <Modal.Header closeButton>
          <Modal.Title>
            {formData?.connection_id ? "Update Database" : "Create Database"}
          </Modal.Title>
        </Modal.Header>
        <button onClick={onClose} className="absolute top-2 right-2 text-gray-700 text-lg">✕</button>
        <h2 className="text-xl font-bold mb-4">Details for: {status}</h2>

        <div className="flex gap-6 h-full">
          <div className="w-1/2">
            <Pie
              data={chartData}
              options={{
                responsive: true,
                plugins: { legend: { position: 'bottom' } },
                onHover: handleHover,
              }}
            />
          </div>

          {hoveredType && (
            <div className="w-1/2 overflow-y-auto border p-4 bg-gray-50 rounded-md text-sm">
              <h3 className="text-md font-semibold text-center mb-3">
                {hoveredType} Test Details
              </h3>
              {hoveredDetails.length > 0 ? (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-200">
                      <th className="py-1 px-2 border">Test ID</th>
                      <th className="py-1 px-2 border">Name</th>
                      <th className="py-1 px-2 border">Result</th>
                    </tr>
                  </thead>
                  <tbody>
                    {hoveredDetails.map((item, i) => (
                      <tr key={i} className="hover:bg-gray-100">
                        <td className="py-1 px-2 border">{item.caseId}</td>
                        <td className="py-1 px-2 border">{item.name}</td>
                        <td className="py-1 px-2 border">{item.result}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="text-center">No details found</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PieModal;
