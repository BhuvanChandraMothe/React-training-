import React, { useState, useEffect } from "react";
import {
  Form,
  Button,
  Container,
  Card,
  Row,
  Col,
  Badge,
  Alert,
  Spinner,
} from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import { get, post, patch } from "../../../api/io";

const CreateApp = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // For edit mode
  const [isEditMode, setIsEditMode] = useState(!!id);
  const [loading, setLoading] = useState(!!id);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [createdAppId, setCreatedAppId] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    mode: "",
    is_public: false,
    status: "normal",
    icon: "",
    workspace_id: sessionStorage.getItem("currentWorkspace"),
  });

  const type = window.location.pathname?.includes("agents")
    ? "agent"
    : window.location.pathname?.includes("chatbots")
    ? "chat"
    : "all";
  // console.log(window.location.pathname?.includes("agents"));

  // Mode-specific configuration details
  const modeDetails = {
    chat: {
      title: "Chat Application",
      icon: "mdi-robot",
      color: "#4361ee",
      description: "Interactive conversational interface powered by AI",
      features: [
        "Natural language processing",
        "Memory & context retention",
        "Custom knowledge base",
      ],
      namePlaceholder: "E.g., Customer Support Assistant",
      descPlaceholder:
        "A conversational AI assistant that helps customers troubleshoot common issues...",
    },
    agent: {
      title: "Agent Application",
      icon: "mdi-brain",
      color: "#6c5ce7",
      description: "Autonomous task execution with defined objectives",
      features: ["Task automation", "Decision making", "System integration"],
      namePlaceholder: "E.g., Data Processing Agent",
      descPlaceholder:
        "An automated agent that processes incoming data files and generates reports...",
    },
  };

  useEffect(() => {
    if (type === "chat") {
      setFormData({
        ...formData,
        mode: "chat",
      });
    } else if (type === "agent") {
      setFormData({
        ...formData,
        mode: "agent",
      });
    }
  }, [type]);
  // Fetch app data if in edit mode
  useEffect(() => {
    if (isEditMode) {
      fetchAppData();
    }
  }, [isEditMode]);

  const fetchAppData = async () => {
    try {
      const data = await get(`/apps/${id}`);
      setFormData({
        name: data.name || "",
        description: data.description || "",
        mode: data.mode || "",
        is_public: data.is_public || false,
        status: data.status || "normal",
        icon: data.icon || modeDetails[data.mode]?.icon || "",
      });
      setLoading(false);
    } catch (error) {
      setError("Failed to load app data. Please try again.");
      setLoading(false);
    }
  };

  // Update placeholders based on selected mode
  useEffect(() => {
    if (formData.mode && formData.name === "" && formData.description === "") {
      const inputName = document.querySelector('input[name="name"]');
      const inputDesc = document.querySelector('textarea[name="description"]');

      if (inputName)
        inputName.placeholder = modeDetails[formData.mode].namePlaceholder;
      if (inputDesc)
        inputDesc.placeholder = modeDetails[formData.mode].descPlaceholder;
    }
  }, [formData.mode]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const isAgent = window.location.pathname.includes("agents");
    try {
      if (isEditMode) {
        await patch(`/apps/${id}`, formData);
        navigate(`/${isAgent ? 'agents': 'chatbots'}/${id}`);
      } else {
        const data = await post("/apps/", formData);
        setCreatedAppId(data.id);
        navigate(`/${isAgent ? 'agents': 'chatbots'}/${data.id}`);
      }
    } catch (error) {
      console.error("Error saving app:", error);
      setError("Failed to save app. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const selectMode = (mode) => {
    setFormData((prev) => ({
      ...prev,
      mode,
      icon: modeDetails[mode].icon,
    }));
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  const selectedMode = formData.mode ? modeDetails[formData.mode] : null;

  return (
    <Container
      fluid
      className="d-flex flex-column vh-100 p-0"
      style={{ background: "linear-gradient(to right, #f8faff, #f2f6ff)" }}
    >
      <div className="py-4 px-4 d-flex align-items-center justify-content-center">
        <Row className="g-0 w-100" style={{ maxWidth: "1200px" }}>
          <Col xs={12}>
            <Card
              className="border-0 shadow-lg"
              style={{ minHeight: "500px", maxHeight: "calc(100vh - 120px)" }}
            >
              <Card.Body className="p-0">
                <Row className="g-0 h-100">
                  {/* Left side - Application Type Selection */}
                  <Col
                    md={4}
                    className="border-end h-100"
                    style={{ background: "rgba(67, 97, 238, 0.03)" }}
                  >
                    <div className="p-4 h-100 d-flex flex-column">
                      {type === "all" ? (
                        <div>
                          <div className="d-flex align-items-center mb-3">
                            <div
                              className="rounded-circle bg-primary text-white p-2 me-2 d-flex align-items-center justify-content-center"
                              style={{ width: "28px", height: "28px" }}
                            >
                              <span className="small fw-bold">1</span>
                            </div>
                            <h5 className="mb-0 fw-bold">
                              {isEditMode
                                ? "Edit Application"
                                : "Select Application Type"}
                            </h5>
                          </div>
                          <p className="text-muted small mb-4 ps-4">
                            {isEditMode
                              ? "Update your application settings"
                              : "Choose the application mode that best fits your needs"}
                          </p>
                        </div>
                      ) : (
                        ""
                      )}

                      {/* {!isEditMode && ( */}
                      <div className="d-flex flex-column">
                        {(type === "chat" || type === "all") && (
                          <Card
                            className={`border-0 ${
                              formData.mode === "chat" ? "shadow" : "shadow-sm"
                            }`}
                            style={{
                              cursor: "pointer",
                              borderLeft:
                                formData.mode === "chat"
                                  ? "4px solid #4361ee"
                                  : "none",
                              backgroundColor:
                                formData.mode === "chat"
                                  ? "#fff"
                                  : "rgba(255,255,255,0.6)",
                            }}
                            onClick={() => selectMode("chat")}
                          >
                            <Card.Body className="p-3">
                              <div className="d-flex align-items-center">
                                <div
                                  className="rounded-circle bg-primary bg-opacity-10 p-2 me-3 d-flex align-items-center justify-content-center"
                                  style={{ width: "48px", height: "48px" }}
                                >
                                  <i
                                    className="mdi mdi-robot"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#4361ee",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6 className="mb-1 fw-bold">
                                    Chat Application
                                  </h6>
                                  <p className="mb-0 small text-muted">
                                    Conversational AI interface
                                  </p>
                                  <div className="mt-2">
                                    {modeDetails["chat"].features.map(
                                      (feature, index) => (
                                        <Badge
                                          key={index}
                                          bg="light"
                                          text="primary"
                                          className="me-1 mt-1"
                                        >
                                          {feature}
                                        </Badge>
                                      )
                                    )}
                                  </div>
                                </div>
                                {formData.mode === "chat" && (
                                  <div className="ms-auto">
                                    <i
                                      className="mdi mdi-check-circle text-primary"
                                      style={{ fontSize: "1.2rem" }}
                                    ></i>
                                  </div>
                                )}
                              </div>
                            </Card.Body>
                          </Card>
                        )}
                        {(type === "agent" || type === "all") && (
                          <Card
                            disabled={true}
                            className={`border-0 ${
                              formData.mode === "agent" ? "shadow" : "shadow-sm"
                            }`}
                            style={{
                              cursor: "pointer",
                              borderLeft:
                                formData.mode === "agent"
                                  ? "4px solid #4361ee"
                                  : "none",
                              backgroundColor:
                                formData.mode === "agent"
                                  ? "#fff"
                                  : "rgba(255,255,255,0.6)",
                            }}
                            onClick={() => selectMode("agent")}
                          >
                            <Card.Body className="p-3">
                              <div className="d-flex align-items-center">
                                <div
                                  className="rounded-circle bg-primary bg-opacity-10 p-2 me-3 d-flex align-items-center justify-content-center"
                                  style={{ width: "48px", height: "48px" }}
                                >
                                  <i
                                    className="mdi mdi-brain"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#4361ee",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6 className="mb-1 fw-bold">
                                    Agent Application
                                  </h6>
                                  <p className="mb-0 small text-muted">
                                    Autonomous task execution
                                  </p>
                                  <div className="mt-2">
                                    {modeDetails["agent"].features.map(
                                      (feature, index) => (
                                        <Badge
                                          key={index}
                                          bg="light"
                                          text="purple"
                                          className="me-1 mt-1"
                                          style={{ color: "#6c5ce7" }}
                                        >
                                          {feature}
                                        </Badge>
                                      )
                                    )}
                                  </div>
                                </div>
                                {formData.mode === "agent" && (
                                  <div className="ms-auto">
                                    <i
                                      className="mdi mdi-check-circle text-primary"
                                      style={{ fontSize: "1.2rem" }}
                                    ></i>
                                  </div>
                                )}
                              </div>
                            </Card.Body>
                          </Card>
                        )}
                      </div>
                      {/* )} */}

                      {type === "all" && !selectedMode && !isEditMode && (
                        <div className="mt-auto pt-3">
                          <div
                            className="alert alert-info bg-info bg-opacity-10 border-0 d-flex align-items-center"
                            role="alert"
                          >
                            <i
                              className="mdi mdi-lightbulb-outline me-2 text-info"
                              style={{ fontSize: "1.2rem" }}
                            ></i>
                            <div className="small">
                              Select an application type to configure settings
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </Col>

                  {/* Right side - Form Fields */}
                  <Col md={8} className="h-100">
                    <div className="p-4 h-100 d-flex flex-column">
                      <div className="d-flex justify-content-between align-items-center mb-3">
                        <div className="d-flex align-items-center">
                          <div
                            className="rounded-circle bg-primary text-white p-2 me-2 d-flex align-items-center justify-content-center"
                            style={{ width: "28px", height: "28px" }}
                          >
                            <span className="small fw-bold">2</span>
                          </div>
                          <h5 className="mb-0 fw-bold">
                            {isEditMode ? "Edit" : "Create"}{" "}
                            {selectedMode ? selectedMode.title : "Application"}
                          </h5>
                          {selectedMode && (
                            <Badge
                              bg="light"
                              text={
                                formData.mode === "chat" ? "primary" : "purple"
                              }
                              className="ms-2 py-1 px-2"
                              style={{
                                color: modeDetails[formData.mode].color,
                              }}
                            >
                              {formData.mode.toUpperCase()}
                            </Badge>
                          )}
                        </div>
                        <Button
                          variant="link"
                          className="text-decoration-none p-0 text-muted"
                          onClick={() => navigate("/")}
                        >
                          <i
                            className="mdi mdi-close"
                            style={{ fontSize: "1.4rem" }}
                          ></i>
                        </Button>
                      </div>

                      {error && (
                        <Alert variant="danger" className="mb-3">
                          {error}
                        </Alert>
                      )}

                      <p className="text-muted small mb-4 ps-4">
                        {selectedMode
                          ? `Configure your ${formData.mode} application settings`
                          : isEditMode
                          ? "Update your application settings"
                          : "Select an application type first"}
                      </p>

                      <Form
                        onSubmit={handleSubmit}
                        className="h-100 d-flex flex-column"
                      >
                        <div
                          className="flex-grow-1 custom-scrollbar"
                          style={{ overflowY: "auto" }}
                        >
                          <Form.Group className="mb-4">
                            <Form.Label className="fw-semibold">
                              Application Name
                            </Form.Label>
                            <Form.Control
                              type="text"
                              name="name"
                              value={formData.name}
                              onChange={handleChange}
                              placeholder={
                                selectedMode
                                  ? selectedMode.namePlaceholder
                                  : "Enter a descriptive name"
                              }
                              className="py-2 shadow-sm"
                              disabled={!formData.mode && !isEditMode}
                              required
                            />
                            <Form.Text className="text-muted">
                              Choose a name that clearly describes your
                              application's purpose
                            </Form.Text>
                          </Form.Group>

                          <Form.Group className="mb-4">
                            <Form.Label className="fw-semibold">
                              Description
                            </Form.Label>
                            <Form.Control
                              as="textarea"
                              name="description"
                              value={formData.description}
                              onChange={handleChange}
                              placeholder={
                                selectedMode
                                  ? selectedMode.descPlaceholder
                                  : "Describe what your application does"
                              }
                              className="py-2 shadow-sm"
                              rows={3}
                              disabled={!formData.mode && !isEditMode}
                              required
                            />
                            <Form.Text className="text-muted">
                              Be specific about the application's capabilities
                              and use cases
                            </Form.Text>
                          </Form.Group>

                          {isEditMode && (
                            <Form.Group className="mb-4">
                              <Form.Check
                                type="switch"
                                id="is-public"
                                label="Make this app public"
                                checked={formData.is_public}
                                onChange={handleChange}
                                name="is_public"
                              />
                              <Form.Text className="text-muted">
                                Public apps can be accessed by anyone with the
                                link
                              </Form.Text>
                            </Form.Group>
                          )}
                        </div>

                        <div className="pt-3 mt-auto border-top">
                          <div className="d-flex justify-content-end align-items-center">
                            <div
                              className={`me-auto ${
                                !formData.mode && !isEditMode
                                  ? "text-muted"
                                  : "text-success"
                              }`}
                            >
                              <i
                                className={`mdi ${
                                  !formData.mode && !isEditMode
                                    ? "mdi-circle-outline"
                                    : "mdi-check-circle"
                                } me-1`}
                              ></i>
                              <span className="small">
                                {formData.mode || isEditMode
                                  ? `${
                                      formData.mode.charAt(0).toUpperCase() +
                                      formData.mode.slice(1)
                                    } application selected`
                                  : "Application type required"}
                              </span>
                            </div>
                            <Button
                              variant="primary"
                              type="submit"
                              disabled={
                                (!formData.mode && !isEditMode) ||
                                !formData.name ||
                                !formData.description ||
                                saving
                              }
                              className="px-4"
                              style={
                                selectedMode
                                  ? {
                                      backgroundColor:
                                        modeDetails[formData.mode].color,
                                      borderColor:
                                        modeDetails[formData.mode].color,
                                    }
                                  : {}
                              }
                            >
                              {saving ? (
                                <>
                                  <Spinner
                                    as="span"
                                    animation="border"
                                    size="sm"
                                    role="status"
                                    aria-hidden="true"
                                    className="me-2"
                                  />
                                  Saving...
                                </>
                              ) : isEditMode ? (
                                "Update Application"
                              ) : (
                                "Create Application"
                              )}
                              <i className="mdi mdi-arrow-right ms-2"></i>
                            </Button>
                          </div>
                        </div>
                      </Form>
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </div>
    </Container>
  );
};

export default CreateApp;
