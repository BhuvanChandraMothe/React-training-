import React, { useState, useEffect } from "react";
import { 
  Row, 
  Col, 
  Card, 
  Button, 
  InputGroup, 
  Form, 
  Dropdown,
  Badge,
  OverlayTrigger,
  Tooltip,
  Nav,
  NavItem,
  NavLink
} from "react-bootstrap";
import { useNavigate, useLocation } from "react-router-dom";
import PageTitle from "../../../components/PageTitle";
import { get } from "../../../api/io";

const Workspaces = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [workspaces, setWorkspaces] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [currentWorkspace, setCurrentWorkspace] = useState(null);

  // Add getTypeColor function
  const getTypeColor = (type) => {
    switch (type) {
      case "production":
        return "#4e73df"; // Blue
      case "development":
        return "#1cc88a"; // Green
      case "testing":
        return "#f6c23e"; // Yellow
      case "specialized":
        return "#e74a3b"; // Red
      default:
        return "#6c757d"; // Gray
    }
  };

  const typeIcons = {
    production: "mdi-shield-check",
    development: "mdi-code-braces",
    testing: "mdi-test-tube",
    specialized: "mdi-chart-box"
  };

  const statusColors = {
    active: "success",
    maintenance: "warning",
    inactive: "danger"
  };

  useEffect(() => {
    // Mock data for workspaces - replace with actual API call
    const mockWorkspaces = [
      {
        id: "ws-1",
        name: "Production",
        description: "Main production workspace for deployed applications",
        type: "production",
        status: "active",
        createdAt: "2023-10-15",
        resources: { agents: 5, workflows: 3, datasets: 7, chatbots: 2 }
      },
      {
        id: "ws-2",
        name: "Development",
        description: "Sandbox environment for testing new features",
        type: "development",
        status: "active",
        createdAt: "2023-10-10",
        resources: { agents: 8, workflows: 6, datasets: 12, chatbots: 3 }
      },
      {
        id: "ws-3",
        name: "Testing",
        description: "Quality assurance environment",
        type: "testing",
        status: "active",
        createdAt: "2023-09-25",
        resources: { agents: 3, workflows: 4, datasets: 5, chatbots: 1 }
      },
      {
        id: "ws-4",
        name: "Analytics",
        description: "Data processing and analytics workspace",
        type: "specialized",
        status: "maintenance",
        createdAt: "2023-08-05",
        resources: { agents: 4, workflows: 2, datasets: 9, chatbots: 2 }
      }
    ];

    // Simulate API call
    setTimeout(() => {
      setWorkspaces(mockWorkspaces);
      // Set the first workspace as current by default
      setCurrentWorkspace(mockWorkspaces[0]);
      setIsLoading(false);
    }, 1000);

    // Uncomment when real API is available
    // fetchWorkspaces();
  }, []);

  const fetchWorkspaces = () => {
    setIsLoading(true);
    get("/workspaces/")
      .then((data) => {
        setWorkspaces(Array.isArray(data) ? data : []);
        setIsLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching workspaces:", err.message);
        setIsLoading(false);
      });
  };

  const filteredWorkspaces = workspaces.filter(workspace => {
    const matchesSearch = workspace.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         workspace.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === "all" || workspace.type === filterType;
    return matchesSearch && matchesType;
  });

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleCreateWorkspace = () => {
    navigate("/workspaces/create");
  };

  const handleWorkspaceClick = (workspaceId) => {
    navigate(`/workspaces/${workspaceId}`);
  };

  const handleWorkspaceSwitch = (workspace) => {
    setCurrentWorkspace(workspace);
    // You can add additional logic here for workspace switching
    // For example, updating the URL or fetching workspace-specific data
  };

  const WorkspaceCard = ({ workspace }) => {
    return (
      <Card className="mb-4 shadow-sm h-100 border-0" style={{ borderRadius: "16px" }}>
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-start mb-3">
            <div className="d-flex align-items-center">
              <div className="me-3">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center"
                  style={{
                    width: "48px",
                    height: "48px",
                    backgroundColor: `${getTypeColor(workspace.type)}15`,
                    color: getTypeColor(workspace.type),
                  }}
                >
                  <i className={`mdi ${typeIcons[workspace.type] || 'mdi-cube'} font-24`}></i>
                </div>
              </div>
              <div>
                <h5 className="mb-1">{workspace.name}</h5>
                <div className="d-flex align-items-center gap-2">
                  <Badge 
                    bg={statusColors[workspace.status] || 'secondary'} 
                    className="rounded-pill px-3 py-1"
                    style={{ fontSize: "0.75rem" }}
                  >
                    {workspace.status}
                  </Badge>
                  <small className="text-muted">Created: {workspace.createdAt}</small>
                </div>
              </div>
            </div>
            <Dropdown align="end">
              <Dropdown.Toggle variant="link" className="card-drop arrow-none cursor-pointer p-0 shadow-none">
                <i className="mdi mdi-dots-vertical font-18"></i>
              </Dropdown.Toggle>
              <Dropdown.Menu className="rounded-3 shadow-sm border-0">
                <Dropdown.Item onClick={() => handleWorkspaceClick(workspace.id)}>
                  <i className="mdi mdi-pencil me-1"></i> Edit
                </Dropdown.Item>
                <Dropdown.Item>
                  <i className="mdi mdi-content-copy me-1"></i> Duplicate
                </Dropdown.Item>
                <Dropdown.Item className="text-danger">
                  <i className="mdi mdi-delete me-1"></i> Delete
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
          
          <p className="text-muted mb-4">{workspace.description}</p>
          
          <div className="d-flex gap-4 mt-3">
            <OverlayTrigger placement="top" overlay={<Tooltip>Agents</Tooltip>}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-2"
                  style={{
                    width: "32px",
                    height: "32px",
                    backgroundColor: "#e3f2fd",
                    color: "#1976d2",
                  }}
                >
                  <i className="mdi mdi-brain"></i>
                </div>
                <span className="fw-medium">{workspace.resources.agents}</span>
              </div>
            </OverlayTrigger>
            
            <OverlayTrigger placement="top" overlay={<Tooltip>Workflows</Tooltip>}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-2"
                  style={{
                    width: "32px",
                    height: "32px",
                    backgroundColor: "#fff3e0",
                    color: "#f57c00",
                  }}
                >
                  <i className="mdi mdi-animation"></i>
                </div>
                <span className="fw-medium">{workspace.resources.workflows}</span>
              </div>
            </OverlayTrigger>
            
            <OverlayTrigger placement="top" overlay={<Tooltip>Knowledge Bases</Tooltip>}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-2"
                  style={{
                    width: "32px",
                    height: "32px",
                    backgroundColor: "#e8f5e9",
                    color: "#388e3c",
                  }}
                >
                  <i className="mdi mdi-database"></i>
                </div>
                <span className="fw-medium">{workspace.resources.datasets}</span>
              </div>
            </OverlayTrigger>

            <OverlayTrigger placement="top" overlay={<Tooltip>Chatbots</Tooltip>}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-2"
                  style={{
                    width: "32px",
                    height: "32px",
                    backgroundColor: "#f3e5f5",
                    color: "#8e24aa",
                  }}
                >
                  <i className="mdi mdi-robot"></i>
                </div>
                <span className="fw-medium">{workspace.resources.chatbots}</span>
              </div>
            </OverlayTrigger>
          </div>
          
          <Button 
            variant="outline-primary" 
            className="mt-4 w-100 rounded-pill"
            onClick={() => handleWorkspaceSwitch(workspace)}
            style={{
              borderWidth: "2px",
              padding: "0.5rem 1rem",
              fontWeight: "500"
            }}
          >
            {currentWorkspace?.id === workspace.id ? "Current Workspace" : "Switch to Workspace"}
          </Button>
        </Card.Body>
      </Card>
    );
  };

  const CreateWorkspaceCard = () => {
    return (
      <Card 
        className="mb-4 shadow-sm h-100 d-flex justify-content-center align-items-center cursor-pointer border-0"
        onClick={handleCreateWorkspace}
        style={{ 
          minHeight: "250px", 
          border: "2px dashed #dee2e6",
          backgroundColor: "#f8f9fa",
          borderRadius: "16px"
        }}
      >
        <Card.Body className="text-center p-4">
          <div 
            className="rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3"
            style={{
              width: "64px",
              height: "64px",
              backgroundColor: "#e3f2fd",
              color: "#1976d2",
            }}
          >
            <i className="mdi mdi-plus font-32"></i>
          </div>
          <h5 className="mb-2">Create New Workspace</h5>
          <p className="text-muted mb-0">Set up a new environment for your work</p>
        </Card.Body>
      </Card>
    );
  };

  const WorkspaceCardSkeleton = () => {
    return (
      <Card className="mb-4 shadow-sm h-100 border-0" style={{ borderRadius: "16px" }}>
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-start mb-3">
            <div className="d-flex align-items-center">
              <div 
                className="skeleton me-3 rounded-circle" 
                style={{ width: "48px", height: "48px" }}
              ></div>
              <div>
                <div 
                  className="skeleton mb-1 rounded-pill" 
                  style={{ width: "150px", height: "24px" }}
                ></div>
                <div 
                  className="skeleton rounded-pill" 
                  style={{ width: "120px", height: "16px" }}
                ></div>
              </div>
            </div>
          </div>
          
          <div 
            className="skeleton my-3 rounded-pill" 
            style={{ width: "100%", height: "40px" }}
          ></div>
          
          <div className="d-flex gap-4 mt-3">
            <div 
              className="skeleton rounded-circle" 
              style={{ width: "32px", height: "32px" }}
            ></div>
            <div 
              className="skeleton rounded-circle" 
              style={{ width: "32px", height: "32px" }}
            ></div>
            <div 
              className="skeleton rounded-circle" 
              style={{ width: "32px", height: "32px" }}
            ></div>
            <div 
              className="skeleton rounded-circle" 
              style={{ width: "32px", height: "32px" }}
            ></div>
          </div>
          
          <div 
            className="skeleton mt-4 rounded-pill" 
            style={{ width: "100%", height: "40px" }}
          ></div>
        </Card.Body>
      </Card>
    );
  };

  return (
    <>
      <PageTitle
        breadCrumbItems={[
          { label: "Workspaces", path: "/workspaces", active: true }
        ]}
        title={"Workspaces"}
      />

      {/* Current Workspace Bar */}
      {currentWorkspace && (
        <Card className="mb-4 shadow-sm border-0" style={{ borderRadius: "16px" }}>
          <Card.Body className="p-3">
            <div className="d-flex justify-content-between align-items-center">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-3"
                  style={{
                    width: "40px",
                    height: "40px",
                    backgroundColor: `${getTypeColor(currentWorkspace.type)}15`,
                    color: getTypeColor(currentWorkspace.type),
                  }}
                >
                  <i className={`mdi ${typeIcons[currentWorkspace.type] || 'mdi-cube'} font-20`}></i>
                </div>
                <div>
                  <h5 className="mb-0">{currentWorkspace.name}</h5>
                  <small className="text-muted">Current Workspace</small>
                </div>
              </div>
              <div className="d-flex align-items-center gap-2">
                <Badge 
                  bg={statusColors[currentWorkspace.status] || 'secondary'} 
                  className="rounded-pill px-3 py-1"
                  style={{ fontSize: "0.75rem" }}
                >
                  {currentWorkspace.status}
                </Badge>
                <Dropdown>
                  <Dropdown.Toggle variant="link" className="text-muted p-0">
                    <i className="mdi mdi-dots-vertical font-18"></i>
                  </Dropdown.Toggle>
                  <Dropdown.Menu className="rounded-3 shadow-sm border-0">
                    <Dropdown.Item onClick={() => handleWorkspaceClick(currentWorkspace.id)}>
                      <i className="mdi mdi-pencil me-1"></i> Edit Workspace
                    </Dropdown.Item>
                    <Dropdown.Item>
                      <i className="mdi mdi-cog me-1"></i> Workspace Settings
                    </Dropdown.Item>
                    <Dropdown.Divider />
                    <Dropdown.Item>
                      <i className="mdi mdi-swap-horizontal me-1"></i> Switch Workspace
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
            </div>
          </Card.Body>
        </Card>
      )}

      {/* Header with search and filters */}
      <Row className="mb-4">
        <Col>
          <div className="d-flex justify-content-between flex-wrap">
            <div className="mb-3 mb-xl-0" style={{ maxWidth: "400px", width: "100%" }}>
              <InputGroup className="rounded-pill shadow-sm">
                <InputGroup.Text className="bg-white border-0">
                  <i className="mdi mdi-magnify text-muted"></i>
                </InputGroup.Text>
                <Form.Control
                  placeholder="Search workspaces..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  className="border-0"
                />
              </InputGroup>
            </div>
            
            <div className="d-flex gap-2">
              <Dropdown>
                <Dropdown.Toggle variant="light" className="border-0 rounded-pill shadow-sm">
                  <i className="mdi mdi-filter-variant me-1"></i>
                  {filterType === "all" ? "All Types" : 
                    filterType.charAt(0).toUpperCase() + filterType.slice(1)}
                </Dropdown.Toggle>
                <Dropdown.Menu className="rounded-3 shadow-sm border-0">
                  <Dropdown.Item onClick={() => setFilterType("all")}>
                    All Types
                  </Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("production")}>
                    Production
                  </Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("development")}>
                    Development
                  </Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("testing")}>
                    Testing
                  </Dropdown.Item>
                  <Dropdown.Item onClick={() => setFilterType("specialized")}>
                    Specialized
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              
              <Button 
                variant="primary" 
                onClick={handleCreateWorkspace}
                className="rounded-pill shadow-sm"
                style={{ padding: "0.5rem 1.5rem" }}
              >
                <i className="mdi mdi-plus me-1"></i>
                New Workspace
              </Button>
            </div>
          </div>
        </Col>
      </Row>

      {/* Statistics cards */}
      <Row className="mb-4">
        <Col lg={3} md={6}>
          <Card className="widget-rounded-circle shadow-sm border-0" style={{ borderRadius: "16px" }}>
            <Card.Body className="p-4">
              <Row>
                <Col>
                  <h4 className="text-primary mt-0">{isLoading ? "-" : workspaces.length}</h4>
                  <p className="text-muted mb-0">Total Workspaces</p>
                </Col>
                <Col xs="auto">
                  <div className="avatar-lg rounded-circle bg-primary d-flex align-items-center justify-content-center" style={{ width: "48px", height: "48px" }}>
                    <i className="mdi mdi-view-dashboard-outline font-24 avatar-title text-white"></i>
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={3} md={6}>
          <Card className="widget-rounded-circle shadow-sm border-0" style={{ borderRadius: "16px" }}>
            <Card.Body className="p-4">
              <Row>
                <Col>
                  <h4 className="text-success mt-0">{isLoading ? "-" : workspaces.filter(w => w.status === "active").length}</h4>
                  <p className="text-muted mb-0">Active Workspaces</p>
                </Col>
                <Col xs="auto">
                  <div className="avatar-lg rounded-circle bg-success d-flex align-items-center justify-content-center" style={{ width: "48px", height: "48px" }}>
                    <i className="mdi mdi-check-circle-outline font-24 avatar-title text-white"></i>
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={3} md={6}>
          <Card className="widget-rounded-circle shadow-sm border-0" style={{ borderRadius: "16px" }}>
            <Card.Body className="p-4">
              <Row>
                <Col>
                  <h4 className="text-info mt-0">{isLoading ? "-" : workspaces.reduce((acc, w) => acc + w.resources.agents, 0)}</h4>
                  <p className="text-muted mb-0">Total Agents</p>
                </Col>
                <Col xs="auto">
                  <div className="avatar-lg rounded-circle bg-info d-flex align-items-center justify-content-center" style={{ width: "48px", height: "48px" }}>
                    <i className="mdi mdi-robot font-24 avatar-title text-white"></i>
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>

        <Col lg={3} md={6}>
          <Card className="widget-rounded-circle shadow-sm border-0" style={{ borderRadius: "16px" }}>
            <Card.Body className="p-4">
              <Row>
                <Col>
                  <h4 className="text-warning mt-0">{isLoading ? "-" : workspaces.reduce((acc, w) => acc + w.resources.workflows, 0)}</h4>
                  <p className="text-muted mb-0">Total Workflows</p>
                </Col>
                <Col xs="auto">
                  <div className="avatar-lg rounded-circle bg-warning d-flex align-items-center justify-content-center" style={{ width: "48px", height: "48px" }}>
                    <i className="mdi mdi-animation font-24 avatar-title text-white"></i>
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Workspace cards */}
      <Row>
        {isLoading ? (
          // Skeleton loaders while loading
          <>
            {[1, 2, 3, 4].map((i) => (
              <Col key={i} lg={4} md={6}>
                <WorkspaceCardSkeleton />
              </Col>
            ))}
          </>
        ) : (
          <>
            {filteredWorkspaces.map((workspace) => (
              <Col key={workspace.id} lg={4} md={6}>
                <Card 
                  className={`mb-4 shadow-sm h-100 border-0 ${currentWorkspace?.id === workspace.id ? 'border-primary' : ''}`}
                  style={{ 
                    borderRadius: "16px",
                    border: currentWorkspace?.id === workspace.id ? '2px solid #4e73df' : 'none'
                  }}
                >
                  <Card.Body className="p-4">
                    <div className="d-flex justify-content-between align-items-start mb-3">
                      <div className="d-flex align-items-center">
                        <div className="me-3">
                          <div 
                            className="rounded-circle d-flex align-items-center justify-content-center"
                            style={{
                              width: "48px",
                              height: "48px",
                              backgroundColor: `${getTypeColor(workspace.type)}15`,
                              color: getTypeColor(workspace.type),
                            }}
                          >
                            <i className={`mdi ${typeIcons[workspace.type] || 'mdi-cube'} font-24`}></i>
                          </div>
                        </div>
                        <div>
                          <h5 className="mb-1">{workspace.name}</h5>
                          <div className="d-flex align-items-center gap-2">
                            <Badge 
                              bg={statusColors[workspace.status] || 'secondary'} 
                              className="rounded-pill px-3 py-1"
                              style={{ fontSize: "0.75rem" }}
                            >
                              {workspace.status}
                            </Badge>
                            <small className="text-muted">Created: {workspace.createdAt}</small>
                          </div>
                        </div>
                      </div>
                      <Dropdown align="end">
                        <Dropdown.Toggle variant="link" className="card-drop arrow-none cursor-pointer p-0 shadow-none">
                          <i className="mdi mdi-dots-vertical font-18"></i>
                        </Dropdown.Toggle>
                        <Dropdown.Menu className="rounded-3 shadow-sm border-0">
                          <Dropdown.Item onClick={() => handleWorkspaceClick(workspace.id)}>
                            <i className="mdi mdi-pencil me-1"></i> Edit
                          </Dropdown.Item>
                          <Dropdown.Item>
                            <i className="mdi mdi-content-copy me-1"></i> Duplicate
                          </Dropdown.Item>
                          <Dropdown.Item className="text-danger">
                            <i className="mdi mdi-delete me-1"></i> Delete
                          </Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                    
                    <p className="text-muted mb-4">{workspace.description}</p>
                    
                    <div className="d-flex gap-4 mt-3">
                      <OverlayTrigger placement="top" overlay={<Tooltip>Agents</Tooltip>}>
                        <div className="d-flex align-items-center">
                          <div 
                            className="rounded-circle d-flex align-items-center justify-content-center me-2"
                            style={{
                              width: "32px",
                              height: "32px",
                              backgroundColor: "#e3f2fd",
                              color: "#1976d2",
                            }}
                          >
                            <i className="mdi mdi-brain"></i>
                          </div>
                          <span className="fw-medium">{workspace.resources.agents}</span>
                        </div>
                      </OverlayTrigger>
                      
                      <OverlayTrigger placement="top" overlay={<Tooltip>Workflows</Tooltip>}>
                        <div className="d-flex align-items-center">
                          <div 
                            className="rounded-circle d-flex align-items-center justify-content-center me-2"
                            style={{
                              width: "32px",
                              height: "32px",
                              backgroundColor: "#fff3e0",
                              color: "#f57c00",
                            }}
                          >
                            <i className="mdi mdi-animation"></i>
                          </div>
                          <span className="fw-medium">{workspace.resources.workflows}</span>
                        </div>
                      </OverlayTrigger>
                      
                      <OverlayTrigger placement="top" overlay={<Tooltip>Knowledge Bases</Tooltip>}>
                        <div className="d-flex align-items-center">
                          <div 
                            className="rounded-circle d-flex align-items-center justify-content-center me-2"
                            style={{
                              width: "32px",
                              height: "32px",
                              backgroundColor: "#e8f5e9",
                              color: "#388e3c",
                            }}
                          >
                            <i className="mdi mdi-database"></i>
                          </div>
                          <span className="fw-medium">{workspace.resources.datasets}</span>
                        </div>
                      </OverlayTrigger>

                      <OverlayTrigger placement="top" overlay={<Tooltip>Chatbots</Tooltip>}>
                        <div className="d-flex align-items-center">
                          <div 
                            className="rounded-circle d-flex align-items-center justify-content-center me-2"
                            style={{
                              width: "32px",
                              height: "32px",
                              backgroundColor: "#f3e5f5",
                              color: "#8e24aa",
                            }}
                          >
                            <i className="mdi mdi-robot"></i>
                          </div>
                          <span className="fw-medium">{workspace.resources.chatbots}</span>
                        </div>
                      </OverlayTrigger>
                    </div>
                    
                    <Button 
                      variant={currentWorkspace?.id === workspace.id ? "primary" : "outline-primary"}
                      className="mt-4 w-100 rounded-pill"
                      onClick={() => handleWorkspaceSwitch(workspace)}
                      style={{
                        borderWidth: "2px",
                        padding: "0.5rem 1rem",
                        fontWeight: "500"
                      }}
                    >
                      {currentWorkspace?.id === workspace.id ? "Current Workspace" : "Switch to Workspace"}
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
            ))}
            
            <Col lg={4} md={6}>
              <CreateWorkspaceCard />
            </Col>
          </>
        )}
      </Row>

      {/* CSS for skeleton animation */}
      <style jsx>{`
        .skeleton {
          animation: pulse 1.5s infinite;
          background-color: #e3e6f0;
          border-radius: 2px;
        }
        @keyframes pulse {
          0% { opacity: 0.6; }
          50% { opacity: 0.8; }
          100% { opacity: 0.6; }
        }
        .card {
          transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        }
        .card:hover {
          transform: translateY(-2px);
          box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
        }
        .cursor-pointer {
          cursor: pointer;
        }
      `}</style>
    </>
  );
};

export default Workspaces;
