import React, { useState } from "react";
import {
  Card,
  Form,
  Button,
  InputGroup,
  ListGroup,
  Modal,
} from "react-bootstrap";

const DebugPanel = () => {
  const [messages, setMessages] = useState([
    { id: 1, text: "Agent initialized", type: "system", timestamp: "10:22:45" },
    {
      id: 2,
      text: "Welcome! I'm your assistant. How can I help you today?",
      type: "agent",
      timestamp: "10:22:46",
    },
  ]);
  const [userInput, setUserInput] = useState("");
  const [showEmbedModal, setShowEmbedModal] = useState(false);
  const [publishStatus, setPublishStatus] = useState(null);
  const [embedCode, setEmbedCode] = useState(
    '<!-- Agent Embed Code -->\n<div id="aif-agent-container"></div>\n<script src="https://cdn.example.com/aif-agent.js" data-agent-id="agent_12345"></script>'
  );

  const handleSendMessage = () => {
    if (!userInput.trim()) return;

    // Add user message
    const newUserMessage = {
      id: messages.length + 1,
      text: userInput,
      type: "user",
      timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
    };

    setMessages([...messages, newUserMessage]);

    // Simulate agent response
    setTimeout(() => {
      const agentResponse = {
        id: messages.length + 2,
        text: "This is a simulated response to demonstrate the debug panel functionality. In a real implementation, this would be the actual response from the agent.",
        type: "agent",
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
      };

      setMessages((prev) => [...prev, agentResponse]);
    }, 1000);

    setUserInput("");
  };

  const handlePublish = () => {
    // Simulate publishing
    setPublishStatus("publishing");
    setTimeout(() => {
      setPublishStatus("published");
      setTimeout(() => setPublishStatus(null), 3000);
    }, 1500);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(embedCode);
    // Would show a toast notification in a real app
  };

  return (
    <>
      <Card style={{ height: "calc(100vh - 120px)" }}>
        <Card.Header className="d-flex justify-content-between align-items-center">
          <div style={{ display: "flex", gap: "5px" }}>
            <Button
              size="sm"
              variant="outline-primary"
              className="me-2"
              onClick={() => setShowEmbedModal(true)}
            >
              <i className="mdi mdi-code-tags me-1"></i> Embed
            </Button>
            <Button
              size="sm"
              variant={publishStatus === "published" ? "success" : "primary"}
              onClick={handlePublish}
              disabled={publishStatus === "publishing"}
            >
              {publishStatus === "publishing" ? (
                <>
                  <i className="mdi mdi-loading mdi-spin me-1"></i>{" "}
                  Publishing...
                </>
              ) : publishStatus === "published" ? (
                <>
                  <i className="mdi mdi-check me-1"></i> Published
                </>
              ) : (
                <>
                  <i className="mdi mdi-cloud-upload me-1"></i> Publish
                </>
              )}
            </Button>
          </div>
        </Card.Header>
        <Card.Body
          className="p-0 d-flex flex-column"
          style={{ height: "calc(100vh - 130px)" }}
        >
          {/* Conversation Log */}
          <div
            className="p-2 flex-grow-1 overflow-auto"
            style={{ backgroundColor: "#f8f9fa" }}
          >
            <h5 className="mb-2">Chat Preview</h5>

            <ListGroup variant="flush">
              {messages.map((message) => (
                <ListGroup.Item
                  key={message.id}
                  className={`border mb-2 rounded ${
                    message.type === "user"
                      ? "bg-light"
                      : message.type === "agent"
                      ? "bg-white"
                      : "bg-light text-muted"
                  }`}
                >
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <small className="fw-bold">
                      {message.type === "user"
                        ? "User"
                        : message.type === "agent"
                        ? "Agent"
                        : "System"}
                    </small>
                    <small className="text-muted">{message.timestamp}</small>
                  </div>
                  <div>{message.text}</div>
                </ListGroup.Item>
              ))}
            </ListGroup>
          </div>

          {/* Input Area */}
          <div className="p-2 border-top">
            <InputGroup>
              <Form.Control
                placeholder="Type a message to test..."
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              />
              <Button variant="primary" onClick={handleSendMessage}>
                <i className="mdi mdi-send"></i>
              </Button>
            </InputGroup>
          </div>
        </Card.Body>
      </Card>

      {/* Embed Modal */}
      <Modal show={showEmbedModal} onHide={() => setShowEmbedModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Embed Agent</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group className="mb-3">
            <Form.Label>Appearance</Form.Label>
            <Form.Select className="mb-2">
              <option>Chat Widget (Bottom Right)</option>
              <option>Inline Chat</option>
              <option>Full Page</option>
            </Form.Select>

            <Form.Select className="mb-3">
              <option>Light Theme</option>
              <option>Dark Theme</option>
              <option>Auto (Follow System)</option>
            </Form.Select>
          </Form.Group>

          <Form.Group>
            <Form.Label>Embed Code</Form.Label>
            <Form.Control
              as="textarea"
              rows={5}
              value={embedCode}
              onChange={(e) => setEmbedCode(e.target.value)}
              className="font-monospace"
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEmbedModal(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={handleCopyCode}>
            <i className="mdi mdi-content-copy me-1"></i> Copy Code
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default DebugPanel;
