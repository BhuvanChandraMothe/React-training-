import React, { useState, useEffect, useRef } from "react";
import { Container, Row, Col, Form, Button, Card } from "react-bootstrap";
import { useParams, useNavigate } from "react-router-dom";
// import { useAuthContext } from "../../../context/useAuthContext";
import "./styles.css";

const Chat = () => {
  const { id } = useParams();
  // const { user } = useAuthContext();
  const [appInfo, setAppInfo] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const [conversationCounter, setConversationCounter] = useState(1);
  const [datasetId, setDatasetId] = useState(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    // Load app info and create initial conversation
    if (id && user?.access_token) {
      const loadAppConfig = async () => {
        try {
          setIsLoading(true);

          // Fetch app data and configuration
          const appResponse = await fetch(`/api/apps/${id}`, {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${user?.access_token}`,
            },
          });

          if (!appResponse.ok) {
            throw new Error(`HTTP error! status: ${appResponse.status}`);
          }

          const appData = await appResponse.json();
          setAppInfo(appData);

          // Fetch app configuration to get the dataset ID
          const configResponse = await fetch(
            `/api/app-model-configs/app/${id}`,
            {
              headers: {
                Accept: "application/json",
                Authorization: `Bearer ${user?.access_token}`,
              },
            }
          );

          if (!configResponse.ok) {
            throw new Error(`HTTP error! status: ${configResponse.status}`);
          }

          const configData = await configResponse.json();
          // Set the dataset ID from the app configuration
          if (configData.dataset_id) {
            setDatasetId(configData.dataset_id);
          }

          // Create initial conversation
          createNewConversation();
        } catch (err) {
          console.error("Error in initialization:", err.message);
        } finally {
          setIsLoading(false);
        }
      };

      loadAppConfig();
    }
  }, [id, user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const createNewConversation = async () => {
    try {
      setIsLoading(true);

      const conversationName = `Conversation ${conversationCounter}`;

      // Create a new conversation via API
      const payload = {
        app_id: id,
        name: conversationName,
        mode: "chat",
        summary: "New conversation",
        status: "normal",
        end_user_id: user?.user?.id,
        dataset_id: datasetId, // Use the dataset ID from app config
      };

      const response = await fetch("/api/conversations/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${user?.access_token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // Update conversation state
      const newConversation = {
        id: data.id,
        title: conversationName,
        created_at: new Date().toISOString(),
      };

      setCurrentConversation(newConversation);
      setConversations((prev) => [newConversation, ...prev]);
      setConversationCounter((prev) => prev + 1);

      // Initialize with welcome message
      setMessages([
        {
          role: "assistant",
          content: "Hi! How can I help you today?",
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (error) {
      console.error("Error creating new conversation:", error);
      // Fallback if API call fails
      setMessages([
        {
          role: "assistant",
          content: "Hi! How can I help you today?",
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadConversation = async (conversation) => {
    try {
      setIsLoading(true);
      setCurrentConversation(conversation);

      // Here you would typically load messages for this conversation
      // For now, we'll just reset to the welcome message
      setMessages([
        {
          role: "assistant",
          content: "Hi! How can I help you today?",
          timestamp: new Date().toISOString(),
        },
      ]);
    } catch (error) {
      console.error("Error loading conversation:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading || !currentConversation) return;

    // Add user message
    const userMessage = {
      role: "user",
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    const assistantMessage = {
      role: "assistant",
      content: "",
      pending: true,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, assistantMessage]);
    setInput("");
    setIsLoading(true);

    try {
      // Get app's model configuration or use default
      const model = "gpt-3.5-turbo"; // Default model

      // Ensure App ID is properly used
      if (!id) {
        console.error("Missing App ID parameter");
        throw new Error("App ID is required");
      }

      const payload = {
        tenant_id: user?.user?.id,
        app_id: id,
        query: input,
        files: datasetId ? [datasetId] : [],
        model: model,
        mode: "chat",
        tools: [],
        conversation_id: currentConversation?.id,
        stream: true,
      };

      // Log payload for debugging
      // console.log("Chat API payload:", payload);

      const response = await fetch("/api/apps/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${user?.access_token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Handle streaming response
      if (response.body && response.body.getReader) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let responseText = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n");

          for (let line of lines) {
            line = line.trim();
            if (line.startsWith("data:")) {
              const clean = line.replace(/^data:\s*/, "");

              if (clean) {
                try {
                  // Try to parse as JSON
                  const jsonData = JSON.parse(clean);
                  if (jsonData.response) {
                    responseText = jsonData.response;
                  } else {
                    // Append with space if needed
                    responseText += clean;
                  }
                } catch (e) {
                  // Not valid JSON, so it's likely a text chunk
                  // Add a space if this seems to be a new word (heuristic)
                  if (
                    responseText.length > 0 &&
                    !responseText.endsWith(" ") &&
                    !responseText.endsWith("\n") &&
                    !clean.startsWith(" ") &&
                    !clean.startsWith("\n") &&
                    !clean.match(/^[,.!?;:)\]}"']/)
                  ) {
                    responseText += " ";
                  }
                  responseText += clean;
                }

                // Update the last message (assistant's response)
                setMessages((prev) => {
                  const updatedMessages = [...prev];
                  const lastMessage =
                    updatedMessages[updatedMessages.length - 1];
                  updatedMessages[updatedMessages.length - 1] = {
                    ...lastMessage,
                    content: responseText,
                    pending: false,
                  };
                  return updatedMessages;
                });
              }
            }
          }
        }
      } else {
        // Fallback for non-streaming response
        const data = await response.json();
        setMessages((prev) => {
          const updatedMessages = [...prev];
          const lastMessage = updatedMessages[updatedMessages.length - 1];
          updatedMessages[updatedMessages.length - 1] = {
            ...lastMessage,
            content: data.response || "No response.",
            pending: false,
          };
          return updatedMessages;
        });
      }
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages((prev) => {
        const updatedMessages = [...prev];
        const lastMessage = updatedMessages[updatedMessages.length - 1];
        updatedMessages[updatedMessages.length - 1] = {
          ...lastMessage,
          content: "Sorry, there was an error processing your request.",
          pending: false,
        };
        return updatedMessages;
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  return (
    <div className="chat-container mt-3 mb-3">
      <div className="chat-layout">
        {/* Sidebar */}
        <div className="chat-sidebar">
          <div className="sidebar-header">
            {appInfo && (
              <div className="app-info d-flex align-items-center">
                <div className="app-icon">
                  <i className={`mdi ${appInfo.icon || "mdi-robot"}`}></i>
                </div>
                <div className="app-details">
                  <h5 className="mb-0">{appInfo?.name || "AI Assistant"}</h5>
                </div>
              </div>
            )}
            <Button
              variant="light"
              className="new-chat-btn"
              onClick={createNewConversation}
              disabled={isLoading}
            >
              <i className="mdi mdi-plus me-2"></i>
              Start New chat
            </Button>

            {conversations.length > 0 && (
              <div className="conversation-list">
                {conversations.map((conv) => (
                  <div
                    key={conv.id}
                    className={`conversation-item ${
                      currentConversation?.id === conv.id ? "active" : ""
                    }`}
                    onClick={() => loadConversation(conv)}
                  >
                    <div className="conversation-title">
                      <i className="mdi mdi-message-text me-2"></i>
                      {conv.title || "New conversation"}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Chat Area */}
        <div className="chat-main">
          <div className="messages-container">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`message ${message.role} ${
                  message.pending ? "pending" : ""
                } ${message.isNotification ? "notification" : ""}`}
              >
                <div className="message-bubble">
                  <div className="message-avatar">
                    <i
                      className={`mdi ${
                        message.role === "user" ? "mdi-account" : "mdi-robot"
                      }`}
                    ></i>
                  </div>
                  <div className="message-content">
                    <div className="message-header">
                      <span className="message-sender text-muted">
                        {message.role === "user"
                          ? "You"
                          : appInfo?.name || "Assistant"}
                      </span>
                    </div>
                    <div className="message-text">
                      {message.pending ? (
                        <div className="typing-indicator">
                          <span></span>
                          <span></span>
                          <span></span>
                        </div>
                      ) : (
                        message.content
                      )}
                      <div className="message-time mt-2">
                        {formatDate(message.timestamp || new Date())}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          <div className="message-input-container">
            <Form onSubmit={sendMessage} className="message-input">
              <Form.Control
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                disabled={isLoading || !currentConversation}
                className="chat-input"
                autoFocus
              />
              <Button
                type="submit"
                disabled={isLoading || !input.trim() || !currentConversation}
                className="send-button"
                variant="primary"
              >
                <i className="mdi mdi-send"></i>
              </Button>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;
