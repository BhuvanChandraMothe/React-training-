import React, { useState } from 'react';
import { Row, Col, Card, Button } from 'react-bootstrap';

const SearchBar = ({ onSearch }) => {
  const [searchValue, setSearchValue] = useState('');

  const handleInputChange = (e) => {
    const value = e.target.value;
    setSearchValue(value);
    onSearch && onSearch(value);
  };

  return (
    <Card className="mb-4 shadow-sm">
      <Card.Body>
        <Row className="align-items-center">
          <Col lg={4} md={6}>
            <div className="search-box">
              <div className="position-relative">
                <input
                  type="text"
                  className="form-control rounded"
                  placeholder="Search apps..."
                  value={searchValue}
                  onChange={handleInputChange}
                />
                <i className="mdi mdi-magnify search-icon"></i>
              </div>
            </div>
          </Col>
          <Col lg={8} md={6}>
            <div className="text-lg-end mt-3 mt-lg-0">
              <Button variant="soft-primary" className="me-2">
                <i className="mdi mdi-filter-variant me-1"></i> Filter
              </Button>
              <Button variant="soft-success" className="me-2">
                <i className="mdi mdi-tune-vertical me-1"></i> Settings
              </Button>
              <Button variant="primary" onClick={() => window.location.href = "/create-app"}>
                <i className="mdi mdi-plus-circle-outline me-1"></i> Create New App
              </Button>
            </div>
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
};

export default SearchBar; 