import { useEffect, useState } from "react";
import { getTestRunsRecents } from "../../../../api/dbapi";

const TestRunsTable = () => {
 
  const [data,setData]=useState([])
 useEffect(() => {
    fetchDataSources();
  }, []);

  const fetchDataSources = async () => {
    try {
      const data = await getTestRunsRecents();
      setData(data);
    } catch (err) {
      console.error('Error fetching trend data:', err);
    }
  };

  const getStatusBadge = (status) => {
    const statusColor = {
      Complete: 'success',
      Error: 'danger',
      Skipped: 'secondary',
    }[status] || 'light';

    return <span className={`badge bg-${statusColor}`}>{status}</span>;
  };

  return (
    <div className="table-responsive card">
       <h6 className="pb-0 mb-2 mt-3">Recent Test Suites</h6>
      <table className="table table-white table-striped table-sm">
        <thead>
          <tr>
            <th>Test Name</th>
            <th>Status</th>
            <th>Records Tested</th>
            <th>Duration</th>
          </tr>
        </thead>
        <tbody>
          {data?.test_runs?.map((run, index) => (
            <tr key={run?.test_run_id}>
              <td>{run.test_suite_name}</td>
              <td>{getStatusBadge(run.status)}</td>
              <td>{run.records_tested}</td>
              <td>{run?.duration_display}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default TestRunsTable
