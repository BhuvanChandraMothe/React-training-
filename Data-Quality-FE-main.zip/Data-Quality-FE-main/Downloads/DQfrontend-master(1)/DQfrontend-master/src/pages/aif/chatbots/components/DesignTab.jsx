import React, { useState } from "react";
import {
  Form,
  Row,
  Col,
  Button,
  Badge,
  InputGroup,
  Accordion,
  OverlayTrigger,
  Tooltip,
  Card,
  Spinner,
} from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const DesignTab = ({
  config,
  handleConfigChange,
  datasets,
  selectedDatasetId,
  setSelectedDatasetId,
  onSave,
  saving,
}) => {
  const { navigate } = useNavigate();
  const [newVariable, setNewVariable] = useState("");
  const [activeAccordion, setActiveAccordion] = useState([
    "basic",
    // "knowledge",
    // "prompt",
    // "chat",
    // "advanced",
  ]);

  // Handle datasets when none are available
  const hasDatasets = datasets && datasets.length > 0;

  const handleAccordionToggle = (key) => {
    setActiveAccordion((prevState) =>
      prevState.includes(key)
        ? prevState.filter((item) => item !== key)
        : [...prevState, key]
    );
  };

  const handleAddVariable = () => {
    if (!newVariable.trim()) return;

    const updatedVariables = [...config.prompt.variables, newVariable.trim()];
    handleConfigChange("prompt", "variables", updatedVariables);
    setNewVariable("");
  };

  const handleRemoveVariable = (index) => {
    const updatedVariables = config.prompt.variables.filter(
      (_, i) => i !== index
    );
    handleConfigChange("prompt", "variables", updatedVariables);
  };

  const handleAddExample = () => {
    const updatedExamples = [
      ...config.prompt.examples,
      { user: "", assistant: "" },
    ];
    handleConfigChange("prompt", "examples", updatedExamples);
  };

  const handleUpdateExample = (index, field, value) => {
    const updatedExamples = [...config.prompt.examples];
    updatedExamples[index][field] = value;
    handleConfigChange("prompt", "examples", updatedExamples);
  };

  const handleRemoveExample = (index) => {
    const updatedExamples = config.prompt.examples.filter(
      (_, i) => i !== index
    );
    handleConfigChange("prompt", "examples", updatedExamples);
  };

  return (
    <div
      className="design-container"
      style={{
        height: "calc(100vh - 200px)",
        overflowY: "auto",
        position: "relative",
      }}
    >
      <div className="section-title d-flex align-items-center mb-4">
        <i className="mdi mdi-robot me-2 text-primary"></i>
        {/* <h4 className="mb-0">Chatbot Configuration</h4> */}
        <div>
          <h4 className="mb-0">{config?.name || "Chatbot Configuration"}</h4>
          <p className="text-muted mb-0">{config?.description}</p>
        </div>
      </div>

      <Form>
        <Accordion className="mb-4" activeKey={activeAccordion} alwaysOpen>
          <Accordion.Item eventKey="basic">
            <Accordion.Header onClick={() => handleAccordionToggle("basic")}>
              <i className="mdi mdi-cog-outline me-2"></i>
              Basic Configuration
            </Accordion.Header>
            <Accordion.Body className="p-0">
              <Card className="border-0 shadow-sm">
                <Card.Body>
                  <Row className="mb-4">
                    <Col md={6} className="pe-md-4">
                      <div className="d-flex align-items-center mb-2">
                        <i
                          className="mdi mdi-tag-text-outline text-primary me-2"
                          style={{ fontSize: "1.2rem" }}
                        ></i>
                        <Form.Label className="mb-0 fw-medium">
                          Chatbot Name
                        </Form.Label>
                        <span className="text-danger ms-1">*</span>
                      </div>
                      <Form.Control
                        type="text"
                        value={config.name}
                        onChange={(e) =>
                          handleConfigChange("name", null, e.target.value)
                        }
                        placeholder="Enter a unique name for your chatbot"
                        className="border-0 bg-light"
                      />
                      <div className="text-muted small mt-1">
                        A memorable name for your chatbot
                      </div>
                    </Col>
                    {/* <Col md={6} className="ps-md-4 mt-3 mt-md-0">
                      <div className="d-flex align-items-center mb-2">
                        <i
                          className="mdi mdi-emoticon-outline text-primary me-2"
                          style={{ fontSize: "1.2rem" }}
                        ></i>
                        <Form.Label className="mb-0 fw-medium">Icon</Form.Label>
                      </div>
                      <div className="d-flex align-items-center">
                        <div
                          className="me-3 px-2 d-flex align-items-center justify-content-center rounded-circle"
                          style={{
                            width: "40px",
                            height: "40px",
                            background: "#f0f4ff",
                          }}
                        >
                          <i
                            className={`mdi ${config.icon}`}
                            style={{ fontSize: "1.5rem" }}
                          ></i>
                        </div>
                        <Form.Select
                          name="icon"
                          value={config.icon}
                          onChange={(e) =>
                            handleConfigChange("icon", null, e.target.value)
                          }
                          className="border-0 bg-light"
                        >
                          <option value="mdi-robot">Robot</option>
                          <option value="mdi-brain">Brain</option>
                        </Form.Select>
                      </div>
                    </Col> */}
                  </Row>

                  <div className="mb-4">
                    <div className="d-flex align-items-center mb-2">
                      <i
                        className="mdi mdi-text-box-outline text-primary me-2"
                        style={{ fontSize: "1.2rem" }}
                      ></i>
                      <Form.Label className="mb-0 fw-medium">
                        Description
                      </Form.Label>
                    </div>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={config.description}
                      onChange={(e) =>
                        handleConfigChange("description", null, e.target.value)
                      }
                      placeholder="Brief description of your chatbot's purpose"
                      className="border-0 bg-light"
                    />
                    <div className="text-muted small mt-1">
                      Describe what your chatbot does and how it helps users
                    </div>
                  </div>

                  {/* <Row>
                    <Col md={6} className="pe-md-4">
                      <div className="d-flex align-items-center mb-2">
                        <i
                          className="mdi mdi-swap-horizontal-bold text-primary me-2"
                          style={{ fontSize: "1.2rem" }}
                        ></i>
                        <Form.Label className="mb-0 fw-medium">Mode</Form.Label>
                      </div>
                      <div className="d-flex mt-2">
                        <div
                          className={`card border-0 me-3 flex-grow-1 cursor-pointer ${
                            config.mode === "chat"
                              ? "shadow-sm bg-primary bg-opacity-10"
                              : "bg-light"
                          }`}
                          onClick={() =>
                            handleConfigChange("mode", null, "chat")
                          }
                          style={{ transition: "all 0.2s ease" }}
                        >
                          <div className="card-body p-3 text-center">
                            <i
                              className="mdi mdi-chat-outline d-block mb-2"
                              style={{ fontSize: "1.5rem" }}
                            ></i>
                            <div className="fw-medium">Chat</div>
                          </div>
                        </div>
                        <div
                          className={`card border-0 flex-grow-1 cursor-pointer ${
                            config.mode === "agent"
                              ? "shadow-sm bg-primary bg-opacity-10"
                              : "bg-light"
                          }`}
                          onClick={() =>
                            handleConfigChange("mode", null, "agent")
                          }
                          style={{ transition: "all 0.2s ease" }}
                        >
                          <div className="card-body p-3 text-center">
                            <i
                              className="mdi mdi-text-box-outline d-block mb-2"
                              style={{ fontSize: "1.5rem" }}
                            ></i>
                            <div className="fw-medium">Agent</div>
                          </div>
                        </div>
                      </div>
                    </Col>
                    <Col md={6} className="ps-md-4 mt-4 mt-md-0">
                      <div className="d-flex align-items-center mb-2">
                        <i
                          className="mdi mdi-shape-outline text-primary me-2"
                          style={{ fontSize: "1.2rem" }}
                        ></i>
                        <Form.Label className="mb-0 fw-medium">
                          Category
                        </Form.Label>
                      </div>
                      <div className="p-2 border rounded bg-white">
                        <Form.Select
                          value={config.metadata.category}
                          onChange={(e) =>
                            handleConfigChange(
                              "metadata",
                              "category",
                              e.target.value
                            )
                          }
                          className="border-0"
                        >
                          <option value="">Select Category</option>
                          <option value="customer-support">
                            Customer Support
                          </option>
                          <option value="sales">Sales</option>
                          <option value="hr">HR</option>
                          <option value="technical">Technical Support</option>
                        </Form.Select>
                      </div>
                      <div className="text-muted small mt-1">
                        Helps with discovery and organization
                      </div>
                    </Col>
                  </Row> */}

                  <div className="mt-4 p-3 rounded bg-light">
                    <Form.Check
                      type="switch"
                      id="is-public"
                      className="d-flex align-items-center gap-2"
                    >
                      <Form.Check.Input
                        checked={config.is_public}
                        onChange={(e) =>
                          handleConfigChange(
                            "is_public",
                            null,
                            e.target.checked
                          )
                        }
                      />
                      <Form.Check.Label className="d-flex align-items-center">
                        <i className="mdi mdi-earth me-2 text-primary"></i>
                        <span>Make this app public</span>
                      </Form.Check.Label>
                    </Form.Check>
                    <div className="text-muted small mt-1 ms-4 ps-2">
                      Public apps can be accessed by anyone with the link
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="knowledge">
            <Accordion.Header
              onClick={() => handleAccordionToggle("knowledge")}
            >
              <i className="mdi mdi-database me-2"></i>
              Knowledge Base Selection
            </Accordion.Header>
            <Accordion.Body className="p-0">
              <Card className="border-0 shadow-sm">
                <Card.Body>
                  {hasDatasets ? (
                    <>
                      <div className="kb-grid">
                        {datasets?.map((dataset) => (
                          <Card
                            key={dataset.id}
                            className={`kb-card cursor-pointer border ${
                              selectedDatasetId === dataset.id
                                ? "border-primary"
                                : "border-light"
                            } ${
                              selectedDatasetId === dataset.id
                                ? "shadow-sm"
                                : ""
                            } h-100`}
                            onClick={() => {
                              handleConfigChange(
                                "selectedKnowledgeBase",
                                null,
                                dataset.id
                              );
                              setSelectedDatasetId(dataset.id);
                            }}
                          >
                            <Card.Body className="p-3">
                              <div className="d-flex align-items-center mb-2">
                                <div
                                  className={`rounded-circle d-flex align-items-center justify-content-center me-2 ${
                                    selectedDatasetId === dataset.id
                                      ? "bg-primary text-white"
                                      : "bg-light"
                                  }`}
                                  style={{ width: "32px", height: "32px" }}
                                >
                                  <i className="mdi mdi-file-document-outline"></i>
                                </div>
                                <h6 className="mb-0 fw-medium">
                                  {dataset.name}
                                </h6>
                              </div>
                              <div className="d-flex align-items-center mt-2 text-muted small">
                                <i className="mdi mdi-file-document-multiple-outline me-1"></i>
                                <span>
                                  {dataset.document_count || 0} documents
                                </span>
                              </div>
                              {config.selectedKnowledgeBase === dataset.id && (
                                <Badge
                                  bg="primary"
                                  className="position-absolute top-0 end-0 m-2"
                                >
                                  <i className="mdi mdi-check me-1"></i>{" "}
                                  Selected
                                </Badge>
                              )}
                            </Card.Body>
                          </Card>
                        ))}
                      </div>
                      <div className="d-flex align-items-center mb-3">
                        <i
                          className="mdi mdi-brain-circuit text-primary me-2"
                          style={{ fontSize: "1.2rem" }}
                        ></i>
                        <h5 className="mb-0 fw-medium">
                          Select Knowledge Source
                        </h5>
                      </div>
                      <p className="text-muted mb-4">
                        Choose a knowledge base to power your chatbot with
                        relevant information. The selected dataset will be used
                        to answer user queries.
                      </p>
                      <div className="mt-3 text-end">
                        <Button
                          variant="link"
                          size="sm"
                          className="text-decoration-none"
                          onClick={() =>
                            (window.location.href = "/aif/datasets")
                          }
                        >
                          <i className="mdi mdi-plus-circle me-1"></i> Manage
                          Datasets
                        </Button>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-5 bg-light rounded">
                      <i
                        className="mdi mdi-database-off-outline d-block mb-3"
                        style={{ fontSize: "3rem", color: "#6c757d" }}
                      ></i>
                      <h5 className="mb-3">No Knowledge Base Available</h5>
                      <p className="text-muted mb-4">
                        You need to create a dataset first to power your chatbot
                        with knowledge.
                      </p>
                      <Button
                        variant="primary"
                        onClick={() =>
                          (window.location.href = "/aif/datasets/create")
                        }
                      >
                        <i className="mdi mdi-plus me-1"></i> Create Dataset
                      </Button>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="prompt">
            <Accordion.Header onClick={() => handleAccordionToggle("prompt")}>
              <i className="mdi mdi-text-box me-2"></i>
              Prompt Configuration
            </Accordion.Header>
            <Accordion.Body className="p-0">
              <Card className="border-0 shadow-sm">
                <Card.Body>
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <div className="d-flex align-items-center">
                      <i
                        className="mdi mdi-brain-circuit text-primary me-2"
                        style={{ fontSize: "1.2rem" }}
                      ></i>
                      <h5 className="mb-0 fw-medium">AI Model Settings</h5>
                    </div>
                    <OverlayTrigger
                      placement="left"
                      overlay={
                        <Tooltip>
                          These settings control how your AI model responds to
                          user queries
                        </Tooltip>
                      }
                    >
                      <i className="mdi mdi-information-outline text-muted cursor-pointer"></i>
                    </OverlayTrigger>
                  </div>
                  <p className="text-muted mb-4">
                    Configure how the AI responds to queries and adjust model
                    parameters for optimal performance.
                  </p>

                  <div className="mb-4 p-3 border rounded bg-white">
                    <div className="d-flex align-items-center mb-3">
                      <i className="mdi mdi-text-box-outline text-primary me-2"></i>
                      <Form.Label className="mb-0 fw-medium">
                        System Prompt
                      </Form.Label>
                    </div>
                    <Form.Control
                      as="textarea"
                      rows={6}
                      value={config.prompt.systemPrompt}
                      onChange={(e) =>
                        handleConfigChange(
                          "prompt",
                          "systemPrompt",
                          e.target.value
                        )
                      }
                      placeholder="You are a helpful assistant that..."
                      className="border-0 bg-light"
                    />
                    <div className="mt-2 text-muted small">
                      <i className="mdi mdi-information-outline me-1"></i>
                      Define the core behavior and personality of your chatbot
                    </div>
                  </div>

                  <Row className="mb-4">
                    <Col md={4}>
                      <div className="h-100 p-3 border rounded bg-white">
                        <div className="d-flex align-items-center mb-2">
                          <i className="mdi mdi-format-list-bulleted-type text-primary me-2"></i>
                          <Form.Label className="mb-0 fw-medium">
                            Prompt Type
                          </Form.Label>
                        </div>
                        <Form.Select
                          value={config.prompt.promptType}
                          onChange={(e) =>
                            handleConfigChange(
                              "prompt",
                              "promptType",
                              e.target.value
                            )
                          }
                          className="border-0 bg-light"
                        >
                          <option value="simple">Simple</option>
                          <option value="advanced">Advanced</option>
                          <option value="custom">Custom</option>
                        </Form.Select>
                        <div className="text-muted small mt-1">
                          Determines prompt structure
                        </div>
                      </div>
                    </Col>
                    <Col md={4}>
                      <div className="h-100 p-3 border rounded bg-white">
                        <div className="d-flex align-items-center mb-2">
                          <i className="mdi mdi-robot text-primary me-2"></i>
                          <Form.Label className="mb-0 fw-medium">
                            Model
                          </Form.Label>
                        </div>
                        <Form.Select
                          value={config.settings.model}
                          onChange={(e) =>
                            handleConfigChange(
                              "settings",
                              "model",
                              e.target.value
                            )
                          }
                          className="border-0 bg-light"
                        >
                          <option value="gpt-4">GPT-4</option>
                          <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                          <option value="claude-2">Claude 2</option>
                        </Form.Select>
                        <div className="text-muted small mt-1">
                          AI model to use
                        </div>
                      </div>
                    </Col>
                    <Col md={4}>
                      <div className="h-100 p-3 border rounded bg-white">
                        <div className="d-flex align-items-center mb-2">
                          <i className="mdi mdi-swap-horizontal text-primary me-2"></i>
                          <Form.Label className="mb-0 fw-medium">
                            Context Window
                          </Form.Label>
                        </div>
                        <Form.Control
                          type="number"
                          value={config.prompt.contextWindow}
                          onChange={(e) =>
                            handleConfigChange(
                              "prompt",
                              "contextWindow",
                              e.target.value
                            )
                          }
                          className="border-0 bg-light"
                        />
                        <div className="text-muted small mt-1">
                          Memory size in tokens
                        </div>
                      </div>
                    </Col>
                  </Row>

                  <div className="mb-4 p-4 border rounded bg-white">
                    <h6 className="mb-3 fw-medium">Generation Parameters</h6>
                    <Row>
                      <Col md={4}>
                        <div className="mb-3">
                          <div className="d-flex justify-content-between mb-1">
                            <Form.Label className="mb-0 small">
                              Temperature
                            </Form.Label>
                            <Badge
                              bg="light"
                              text="dark"
                              className="rounded-pill"
                            >
                              {config.settings.temperature.toFixed(2)}
                            </Badge>
                          </div>
                          <Form.Range
                            value={config.settings.temperature * 100}
                            onChange={(e) =>
                              handleConfigChange(
                                "settings",
                                "temperature",
                                e.target.value / 100
                              )
                            }
                            className="custom-range"
                          />
                          <div className="d-flex justify-content-between small text-muted">
                            <span>Precise</span>
                            <span>Creative</span>
                          </div>
                        </div>
                      </Col>
                      <Col md={4}>
                        <div className="mb-3">
                          <div className="d-flex justify-content-between mb-1">
                            <Form.Label className="mb-0 small">
                              Max Tokens
                            </Form.Label>
                            <Badge
                              bg="light"
                              text="dark"
                              className="rounded-pill"
                            >
                              {config.settings.maxTokens}
                            </Badge>
                          </div>
                          <Form.Range
                            min="100"
                            max="4000"
                            value={config.settings.maxTokens}
                            onChange={(e) =>
                              handleConfigChange(
                                "settings",
                                "maxTokens",
                                parseInt(e.target.value)
                              )
                            }
                            className="custom-range"
                          />
                          <div className="d-flex justify-content-between small text-muted">
                            <span>Short</span>
                            <span>Long</span>
                          </div>
                        </div>
                      </Col>
                      <Col md={4}>
                        <div className="mb-3">
                          <div className="d-flex justify-content-between mb-1">
                            <Form.Label className="mb-0 small">
                              Top P
                            </Form.Label>
                            <Badge
                              bg="light"
                              text="dark"
                              className="rounded-pill"
                            >
                              {config.settings.topP.toFixed(2)}
                            </Badge>
                          </div>
                          <Form.Range
                            value={config.settings.topP * 100}
                            onChange={(e) =>
                              handleConfigChange(
                                "settings",
                                "topP",
                                e.target.value / 100
                              )
                            }
                            className="custom-range"
                          />
                          <div className="d-flex justify-content-between small text-muted">
                            <span>Focused</span>
                            <span>Diverse</span>
                          </div>
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={6}>
                        <div className="mb-3">
                          <div className="d-flex justify-content-between mb-1">
                            <Form.Label className="mb-0 small">
                              Frequency Penalty
                            </Form.Label>
                            <Badge
                              bg="light"
                              text="dark"
                              className="rounded-pill"
                            >
                              {config.settings.frequencyPenalty.toFixed(2)}
                            </Badge>
                          </div>
                          <Form.Range
                            min="-200"
                            max="200"
                            value={config.settings.frequencyPenalty * 100}
                            onChange={(e) =>
                              handleConfigChange(
                                "settings",
                                "frequencyPenalty",
                                e.target.value / 100
                              )
                            }
                            className="custom-range"
                          />
                          <div className="d-flex justify-content-between small text-muted">
                            <span>Repetitive</span>
                            <span>Varied</span>
                          </div>
                        </div>
                      </Col>
                      <Col md={6}>
                        <div className="mb-3">
                          <div className="d-flex justify-content-between mb-1">
                            <Form.Label className="mb-0 small">
                              Presence Penalty
                            </Form.Label>
                            <Badge
                              bg="light"
                              text="dark"
                              className="rounded-pill"
                            >
                              {config.settings.presencePenalty.toFixed(2)}
                            </Badge>
                          </div>
                          <Form.Range
                            min="-200"
                            max="200"
                            value={config.settings.presencePenalty * 100}
                            onChange={(e) =>
                              handleConfigChange(
                                "settings",
                                "presencePenalty",
                                e.target.value / 100
                              )
                            }
                            className="custom-range"
                          />
                          <div className="d-flex justify-content-between small text-muted">
                            <span>Focused</span>
                            <span>Exploratory</span>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </div>

                  <div className="p-3 border rounded bg-light">
                    <div className="d-flex align-items-center">
                      <i className="mdi mdi-information-outline text-primary me-2"></i>
                      <div className="text-muted small">
                        These settings control how the AI generates responses.
                        Temperature affects creativity, while Top P, Frequency
                        Penalty, and Presence Penalty control response
                        diversity.
                      </div>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Accordion.Body>
          </Accordion.Item>

          <Accordion.Item eventKey="chat">
            <Accordion.Header onClick={() => handleAccordionToggle("chat")}>
              <i className="mdi mdi-chat-outline me-2"></i>
              Chat Interface
            </Accordion.Header>
            <Accordion.Body className="p-0">
              <Card className="border-0 shadow-sm">
                <Card.Body>
                  <div className="mb-4 p-3 border rounded bg-white">
                    <div className="d-flex align-items-center mb-2">
                      <i className="mdi mdi-message-text-outline text-primary me-2"></i>
                      <Form.Label className="mb-0 fw-medium">
                        Welcome Message
                      </Form.Label>
                    </div>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={config.settings.welcomeText}
                      onChange={(e) =>
                        handleConfigChange(
                          "settings",
                          "welcomeText",
                          e.target.value
                        )
                      }
                      placeholder="Hi! How can I help you today?"
                      className="border-0 bg-light"
                    />
                    <div className="text-muted small mt-1">
                      <i className="mdi mdi-information-outline me-1"></i>
                      This is the first message users will see when they start
                      chatting
                    </div>
                  </div>

                  <Row className="mb-4">
                    <Col md={6} className="pe-md-2">
                      <div className="h-100 p-3 border rounded bg-white">
                        <div className="d-flex align-items-center mb-2">
                          <i className="mdi mdi-frequently-asked-questions text-primary me-2"></i>
                          <Form.Label className="mb-0 fw-medium">
                            Suggested Questions
                          </Form.Label>
                        </div>
                        <Form.Control
                          as="textarea"
                          rows={5}
                          value={JSON.stringify(
                            config.suggestedQuestions,
                            null,
                            2
                          )}
                          onChange={(e) => {
                            try {
                              const parsed = JSON.parse(e.target.value);
                              handleConfigChange(
                                "suggestedQuestions",
                                null,
                                parsed
                              );
                            } catch (error) {
                              // Allow invalid JSON during editing
                            }
                          }}
                          placeholder='{"questions": ["How do I reset my password?", "What are your business hours?"]}'
                          className="border-0 bg-light font-monospace"
                        />
                        <div className="text-muted small mt-1">
                          Questions to show at the start of conversation
                        </div>
                      </div>
                    </Col>
                    <Col md={6} className="ps-md-2 mt-3 mt-md-0">
                      <div className="h-100 p-3 border rounded bg-white">
                        <div className="d-flex align-items-center mb-2">
                          <i className="mdi mdi-arrow-right-circle-outline text-primary me-2"></i>
                          <Form.Label className="mb-0 fw-medium">
                            Follow-up Questions
                          </Form.Label>
                        </div>
                        <Form.Control
                          as="textarea"
                          rows={5}
                          value={JSON.stringify(
                            config.suggestedQuestionsAfterAnswer,
                            null,
                            2
                          )}
                          onChange={(e) => {
                            try {
                              const parsed = JSON.parse(e.target.value);
                              handleConfigChange(
                                "suggestedQuestionsAfterAnswer",
                                null,
                                parsed
                              );
                            } catch (error) {
                              // Allow invalid JSON during editing
                            }
                          }}
                          placeholder='{"questions": ["Tell me more about...", "How does this compare to..."]}'
                          className="border-0 bg-light font-monospace"
                        />
                        <div className="text-muted small mt-1">
                          Questions to show after the bot responds
                        </div>
                      </div>
                    </Col>
                  </Row>

                  <div className="d-flex mt-4 p-3 rounded bg-light">
                    <i
                      className="mdi mdi-lightbulb-on-outline text-warning mt-1 me-2"
                      style={{ fontSize: "1.2rem" }}
                    ></i>
                    <div className="text-muted small">
                      <strong>Pro tip:</strong> Good suggested questions can
                      significantly improve user engagement and guide users
                      toward valuable interactions with your chatbot.
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Accordion.Body>
          </Accordion.Item>

          {/* <Accordion.Item eventKey="advanced">
            <Accordion.Header onClick={() => handleAccordionToggle("advanced")}>
              <i className="mdi mdi-tune me-2"></i>
              Advanced Configuration
            </Accordion.Header>
            <Accordion.Body className="p-0">
              <Card className="border-0 shadow-sm">
                <Card.Body>
                  <div className="d-flex align-items-center mb-3">
                    <i
                      className="mdi mdi-code-json text-primary me-2"
                      style={{ fontSize: "1.2rem" }}
                    ></i>
                    <h5 className="mb-0 fw-medium">Advanced Settings</h5>
                  </div>
                  <p className="text-muted mb-4">
                    Configure advanced options for your chatbot including
                    variables, forms, and file uploads.
                  </p>

                  <div className="mb-4 p-3 border rounded bg-white">
                    <div className="d-flex align-items-center mb-2">
                      <i className="mdi mdi-variable text-primary me-2"></i>
                      <Form.Label className="mb-0 fw-medium">
                        Template Variables
                      </Form.Label>
                    </div>
                    <div className="variable-tags mb-2 p-2 bg-light rounded">
                      {config.prompt.variables.length > 0 ? (
                        config.prompt.variables.map((variable, index) => (
                          <Badge
                            key={index}
                            bg="primary"
                            text="white"
                            className="me-2 mb-2 p-2"
                          >
                            {`{{${variable}}}`}
                            <i
                              className="mdi mdi-close-circle ms-2 cursor-pointer"
                              onClick={() => handleRemoveVariable(index)}
                            ></i>
                          </Badge>
                        ))
                      ) : (
                        <div className="text-muted small">
                          No variables defined. Add variables to make your
                          prompts dynamic.
                        </div>
                      )}
                    </div>
                    <InputGroup className="mt-3">
                      <Form.Control
                        placeholder="Add a variable (e.g., user_name)"
                        value={newVariable}
                        onChange={(e) => setNewVariable(e.target.value)}
                        className="border bg-white"
                      />
                      <Button variant="primary" onClick={handleAddVariable}>
                        <i className="mdi mdi-plus me-1"></i> Add
                      </Button>
                    </InputGroup>
                    <div className="text-muted small mt-2">
                      Variables can be used in prompts and will be replaced with
                      actual values
                    </div>
                  </div>

                  <Row className="mb-4">
                    <Col md={6} className="pe-md-2">
                      <div className="h-100 p-3 border rounded bg-white">
                        <div className="d-flex align-items-center mb-2">
                          <i className="mdi mdi-form-select text-primary me-2"></i>
                          <Form.Label className="mb-0 fw-medium">
                            User Input Form
                          </Form.Label>
                        </div>
                        <Form.Control
                          as="textarea"
                          rows={5}
                          value={JSON.stringify(config.userInputForm, null, 2)}
                          onChange={(e) => {
                            try {
                              const parsed = JSON.parse(e.target.value);
                              handleConfigChange("userInputForm", null, parsed);
                            } catch (error) {
                              // Allow invalid JSON during editing
                            }
                          }}
                          placeholder='{"fields": [{"name": "name", "type": "text", "label": "Your Name"}]}'
                          className="border-0 bg-light font-monospace"
                        />
                        <div className="text-muted small mt-1">
                          JSON configuration for custom input forms
                        </div>
                      </div>
                    </Col>
                    <Col md={6} className="ps-md-2 mt-3 mt-md-0">
                      <div className="h-100 p-3 border rounded bg-white">
                        <div className="d-flex align-items-center mb-2">
                          <i className="mdi mdi-upload-outline text-primary me-2"></i>
                          <Form.Label className="mb-0 fw-medium">
                            File Upload Config
                          </Form.Label>
                        </div>
                        <Form.Control
                          as="textarea"
                          rows={5}
                          value={JSON.stringify(config.fileUpload, null, 2)}
                          onChange={(e) => {
                            try {
                              const parsed = JSON.parse(e.target.value);
                              handleConfigChange("fileUpload", null, parsed);
                            } catch (error) {
                              // Allow invalid JSON during editing
                            }
                          }}
                          placeholder='{"allowed_types": ["pdf", "docx"], "max_size": 5}'
                          className="border-0 bg-light font-monospace"
                        />
                        <div className="text-muted small mt-1">
                          JSON configuration for file upload settings
                        </div>
                      </div>
                    </Col>
                  </Row>

                  <div className="mb-4 p-3 border rounded bg-white">
                    <div className="d-flex align-items-center mb-3">
                      <i className="mdi mdi-message-reply-text-outline text-primary me-2"></i>
                      <Form.Label className="mb-0 fw-medium">
                        Example Conversations
                      </Form.Label>
                    </div>
                    <div className="examples-container p-3 bg-light rounded">
                      {config.prompt.examples.length > 0 ? (
                        config.prompt.examples.map((example, index) => (
                          <div
                            key={index}
                            className="example-item mb-4 p-3 border rounded bg-white"
                          >
                            <div className="d-flex justify-content-between mb-2">
                              <h6 className="mb-0">Example {index + 1}</h6>
                              <Button
                                variant="outline-danger"
                                size="sm"
                                className="p-1 px-2"
                                onClick={() => handleRemoveExample(index)}
                              >
                                <i className="mdi mdi-delete-outline"></i>
                              </Button>
                            </div>
                            <div className="user-message p-2 bg-light rounded mb-2">
                              <Form.Label className="small fw-medium mb-1">
                                <i className="mdi mdi-account-outline me-1 text-primary"></i>
                                User:
                              </Form.Label>
                              <Form.Control
                                as="textarea"
                                rows={2}
                                value={example.user}
                                onChange={(e) =>
                                  handleUpdateExample(
                                    index,
                                    "user",
                                    e.target.value
                                  )
                                }
                                className="border-0"
                                placeholder="Enter example user message..."
                              />
                            </div>
                            <div className="assistant-message p-2 bg-light rounded">
                              <Form.Label className="small fw-medium mb-1">
                                <i className="mdi mdi-robot-outline me-1 text-primary"></i>
                                Assistant:
                              </Form.Label>
                              <Form.Control
                                as="textarea"
                                rows={2}
                                value={example.assistant}
                                onChange={(e) =>
                                  handleUpdateExample(
                                    index,
                                    "assistant",
                                    e.target.value
                                  )
                                }
                                className="border-0"
                                placeholder="Enter example assistant response..."
                              />
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center p-4 text-muted">
                          <i
                            className="mdi mdi-chat-remove-outline d-block mb-2"
                            style={{ fontSize: "2rem" }}
                          ></i>
                          <p>No example conversations added yet</p>
                        </div>
                      )}

                      <div className="text-center mt-3">
                        <Button
                          variant="outline-primary"
                          onClick={handleAddExample}
                        >
                          <i className="mdi mdi-plus me-1"></i> Add Example
                          Conversation
                        </Button>
                      </div>
                    </div>
                    <div className="text-muted small mt-2">
                      Example conversations help train your AI to respond in a
                      specific way
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Accordion.Body>
          </Accordion.Item> */}
        </Accordion>
        <Card
          className="border-0 shadow-sm mt-4 sticky-bottom bg-white"
          style={{ position: "sticky", bottom: 0, zIndex: 10 }}
        >
          <Card.Body className="d-flex justify-content-between align-items-center">
            <div className="d-flex align-items-center">
              <i
                className="mdi mdi-content-save-outline text-primary me-2"
                style={{ fontSize: "1.5rem" }}
              ></i>
              <div>
                <h5 className="mb-0">Save Your Configuration</h5>
                <p className="mb-0 text-muted small">
                  Save your changes to update your chatbot
                </p>
              </div>
            </div>
            <div className="d-flex gap-3">
              <Button variant="outline-secondary" onClick={() => navigate(-1)}>
                <i className="mdi mdi-cancel me-1"></i> Cancel
              </Button>
              <Button
                variant="primary"
                onClick={onSave}
                disabled={saving}
                className="px-4"
              >
                {saving ? (
                  <>
                    <Spinner
                      as="span"
                      animation="border"
                      size="sm"
                      role="status"
                      aria-hidden="true"
                      className="me-2"
                    />
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="mdi mdi-content-save me-1"></i>
                    Save Configuration
                  </>
                )}
              </Button>
            </div>
          </Card.Body>
        </Card>
        <div style={{ height: "20px" }}></div> {/* Smaller spacer */}
      </Form>
    </div>
  );
};

export default DesignTab;
