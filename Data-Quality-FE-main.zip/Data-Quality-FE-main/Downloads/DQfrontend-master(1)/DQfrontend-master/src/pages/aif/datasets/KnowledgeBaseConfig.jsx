import React, { useState, useEffect } from "react";
// import { useAuthContext } from "../../../context/useAuthContext";
import { useParams, useNavigate } from "react-router-dom";
import {
  Card,
  Form,
  Row,
  Col,
  Button,
  InputGroup,
  Tab,
  Nav,
  Badge,
  Alert,
  ProgressBar,
  Tooltip,
  OverlayTrigger,
} from "react-bootstrap";

import {
  FiSettings,
  FiDatabase,
  FiSearch,
  FiCpu,
  FiFilter,
  FiZap,
  FiInfo,
  FiCheck,
  FiX,
  FiSave,
  FiArrowLeft,
} from "react-icons/fi";
import {
  BsLightningCharge,
  BsShieldLock,
  BsGear,
  BsQuestionCircle,
} from "react-icons/bs";

const KnowledgeBaseConfig = () => {
  const navigate = useNavigate();
  // const { user } = useAuthContext();
  const { id } = useParams();
  const [isEditMode, setIsEditMode] = useState(!!id);
  const [isLoading, setIsLoading] = useState(!!id);
  const [formData, setFormData] = useState({
    // Basic Settings
    name: "",
    description: "",
    permission: "only_me",
    data_source_type: "file",
    indexing_technique: "high_quality",
    embedding_model: "openai",

    // Chunk Settings
    maxTokens: 512,
    overlap: 50,
    delimiter: "\n\n",
    chunkStrategy: "fixed",

    // Processing Rules
    deleteConsecutiveSpaces: false,
    deletePII: false,
    preserveHeaders: true,
    removeURLs: false,
    removeEmails: false,
    customRegexRules: "",

    // Vector Search Settings
    embeddingModel: "BERT-uncased",
    reRankModel: "Cohere",
    similarityMetric: "cosine",

    // Search Settings
    enableVectorSearch: true,
    enableKeywordSearch: true,
    enableHybridSearch: true,
    minRelevanceScore: 0.7,

    // Advanced Settings
    maxQueriesPerMinute: 60,
    cacheResults: true,
    cacheDuration: 24,

    // Workflow Settings
    emailProcessingWorkflow: false,
    postToAgent: false,
    queueTemplate: "",
  });

  useEffect(() => {
    // Fetch dataset data if in edit mode
    if (id) {
      fetchDatasetData();
    }
  }, [id]);

  const fetchDatasetData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/datasets/${id}`, {
        // headers: {
        //   Accept: "application/json",
        //   Authorization: `Bearer ${user?.access_token}`,
        // },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      // Update form data with fetched dataset details
      setFormData(prevData => ({
        ...prevData,
        name: data.name || "",
        description: data.description || "",
        permission: data.permission || "only_me",
        data_source_type: data.data_source_type || "file",
        indexing_technique: data.indexing_technique || "high_quality",
        embedding_model: data.embedding_model || "openai",
        // Add other field mappings here
      }));
    } catch (error) {
      console.error("Error fetching dataset:", error);
      // Show error in UI
    } finally {
      setIsLoading(false);
    }
  };

  const [activeTab, setActiveTab] = useState("basic");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const url = isEditMode ? `/api/datasets/${id}` : "/api/datasets/";
      const method = isEditMode ? "PATCH" : "POST";
      
      const response = await fetch(url, {
        method: method,
        // headers: {
        //   "Content-Type": "application/json",
        //   Authorization: `Bearer ${user?.access_token}`,
        // },
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          permission: formData.permission,
          data_source_type: formData.data_source_type,
          indexing_technique: formData.indexing_technique,
          embedding_model: formData.embedding_model,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
      navigate(-1);
    } catch (error) {
      console.error("Error saving knowledge base:", error);
      // TODO: Add error handling UI
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderTooltip = (text) => (
    <OverlayTrigger
      placement="top"
      overlay={<Tooltip id={`tooltip-${text}`}>{text}</Tooltip>}
    >
      <span className="ms-1 text-muted">
        <BsQuestionCircle size={14} />
      </span>
    </OverlayTrigger>
  );

  return (
    <>
      {isLoading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Loading dataset configuration...</p>
        </div>
      ) : (
        <>
          {showSuccess && (
            <Alert variant="success" className="mb-3 d-flex align-items-center">
              <FiCheck className="me-2" size={18} />
              Knowledge base configuration {isEditMode ? "updated" : "saved"} successfully!
            </Alert>
          )}

          <Card className="border-0 shadow-sm mt-3">
            {/* <Card.Header className="bg-white py-3 border-bottom">
              <div className="d-flex justify-content-between align-items-center">
                <h5 className="mb-0">
                  <FiDatabase className="me-2 text-primary" />
                  Configure Knowledge Base
                </h5>
                <Badge bg="light" text="dark" className="px-3 py-2">
                  <BsShieldLock className="me-1" />
                  Enterprise
                </Badge>
              </div>
            </Card.Header> */}

            <Card.Body className="p-0">
              <Tab.Container
                defaultActiveKey="basic"
                onSelect={(k) => setActiveTab(k)}
                className="knowledge-base-tabs"
              >
                <Row className="g-0">
                  <Col sm={3} className="border-end">
                    <Nav variant="pills" className="flex-column p-3">
                      <Nav.Item className="mb-2">
                        <Nav.Link
                          eventKey="basic"
                          className={`d-flex align-items-center py-2 px-3 rounded ${
                            activeTab === "basic" ? "active" : ""
                          }`}
                        >
                          <FiSettings className="me-2" />
                          <span>Basic Settings</span>
                        </Nav.Link>
                      </Nav.Item>
                      <Nav.Item className="mb-2">
                        <Nav.Link
                          eventKey="chunk"
                          className={`d-flex align-items-center py-2 px-3 rounded ${
                            activeTab === "chunk" ? "active" : ""
                          }`}
                        >
                          <FiCpu className="me-2" />
                          <span>Chunk Settings</span>
                        </Nav.Link>
                      </Nav.Item>
                      <Nav.Item className="mb-2">
                        <Nav.Link
                          eventKey="processing"
                          className={`d-flex align-items-center py-2 px-3 rounded ${
                            activeTab === "processing" ? "active" : ""
                          }`}
                        >
                          <FiFilter className="me-2" />
                          <span>Processing Rules</span>
                        </Nav.Link>
                      </Nav.Item>
                      <Nav.Item className="mb-2">
                        <Nav.Link
                          eventKey="search"
                          className={`d-flex align-items-center py-2 px-3 rounded ${
                            activeTab === "search" ? "active" : ""
                          }`}
                        >
                          <FiSearch className="me-2" />
                          <span>Search Configuration</span>
                        </Nav.Link>
                      </Nav.Item>
                      <Nav.Item className="mb-2">
                        <Nav.Link
                          eventKey="workflow"
                          className={`d-flex align-items-center py-2 px-3 rounded ${
                            activeTab === "workflow" ? "active" : ""
                          }`}
                        >
                          <BsLightningCharge className="me-2" />
                          <span>Workflow & Triggers</span>
                        </Nav.Link>
                      </Nav.Item>
                      <Nav.Item>
                        <Nav.Link
                          eventKey="advanced"
                          className={`d-flex align-items-center py-2 px-3 rounded ${
                            activeTab === "advanced" ? "active" : ""
                          }`}
                        >
                          <BsGear className="me-2" />
                          <span>Advanced Settings</span>
                        </Nav.Link>
                      </Nav.Item>
                    </Nav>
                  </Col>

                  <Col sm={9}>
                    <div className="p-4">
                      <Form onSubmit={handleSubmit}>
                        <Tab.Content>
                          <Tab.Pane eventKey="basic">
                            {/* <div className="d-flex justify-content-between align-items-center mb-4">
                              <h4 className="mb-0">Basic Settings</h4>
                              <Badge bg="primary" className="px-3 py-2">
                                <FiInfo className="me-1" />
                                Required
                              </Badge>
                            </div> */}

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Knowledge Base Name
                                <span className="text-danger ms-1">*</span>
                              </Form.Label>
                              <InputGroup>
                                <InputGroup.Text className="bg-light">
                                  <FiDatabase />
                                </InputGroup.Text>
                                <Form.Control
                                  type="text"
                                  name="name"
                                  value={formData.name}
                                  onChange={handleInputChange}
                                  placeholder="Enter a descriptive name"
                                  required
                                  className="border-start-0"
                                />
                              </InputGroup>
                              <Form.Text className="text-muted">
                                Choose a name that clearly identifies this knowledge
                                base
                              </Form.Text>
                            </Form.Group>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Description
                              </Form.Label>
                              <Form.Control
                                as="textarea"
                                rows={3}
                                name="description"
                                value={formData.description}
                                onChange={handleInputChange}
                                placeholder="Describe the purpose and content of this knowledge base"
                                className="border-0 bg-light"
                              />
                            </Form.Group>

                            <Form.Group className="mb-3">
                              <Form.Label>
                                Data Source Type
                                {renderTooltip(
                                  "Select the type of data source for this knowledge base"
                                )}
                              </Form.Label>
                              <Form.Select
                                name="data_source_type"
                                value={formData.data_source_type}
                                onChange={handleInputChange}
                              >
                                <option value="file">File Upload</option>
                                <option value="web">Web Scraping</option>
                                <option value="api">API Integration</option>
                              </Form.Select>
                            </Form.Group>

                            <Form.Group className="mb-3">
                              <Form.Label>
                                Indexing Technique
                                {renderTooltip(
                                  "Choose the indexing technique for document processing"
                                )}
                              </Form.Label>
                              <Form.Select
                                name="indexing_technique"
                                value={formData.indexing_technique}
                                onChange={handleInputChange}
                              >
                                <option value="high_quality">High Quality</option>
                                <option value="fast">Fast Processing</option>
                              </Form.Select>
                            </Form.Group>

                            <Form.Group className="mb-3">
                              <Form.Label>
                                Embedding Model
                                {renderTooltip(
                                  "Select the embedding model for vector search"
                                )}
                              </Form.Label>
                              <Form.Select
                                name="embedding_model"
                                value={formData.embedding_model}
                                onChange={handleInputChange}
                              >
                                <option value="openai">OpenAI</option>
                                <option value="cohere">Cohere</option>
                                <option value="huggingface">HuggingFace</option>
                              </Form.Select>
                            </Form.Group>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Visibility
                              </Form.Label>
                              <Form.Select
                                name="visibility"
                                value={formData.visibility}
                                onChange={handleInputChange}
                                className="border-0 bg-light"
                              >
                                <option value="private">Private</option>
                                <option value="public">Public</option>
                                <option value="restricted">Restricted</option>
                              </Form.Select>
                              <Form.Text className="text-muted">
                                Control who can access this knowledge base
                              </Form.Text>
                            </Form.Group>
                          </Tab.Pane>

                          <Tab.Pane eventKey="chunk">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                              <h4 className="mb-0">Chunk Settings</h4>
                              <Badge bg="info" className="px-3 py-2">
                                <FiCpu className="me-1" />
                                Processing
                              </Badge>
                            </div>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Max Tokens per Chunk
                                {renderTooltip(
                                  "Maximum number of tokens in each text chunk"
                                )}
                              </Form.Label>
                              <InputGroup>
                                <Form.Control
                                  type="number"
                                  name="maxTokens"
                                  value={formData.maxTokens}
                                  onChange={handleInputChange}
                                  className="border-0 bg-light"
                                />
                                <InputGroup.Text className="bg-light">
                                  tokens
                                </InputGroup.Text>
                              </InputGroup>
                            </Form.Group>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Overlap Tokens
                                {renderTooltip(
                                  "Number of tokens that overlap between consecutive chunks"
                                )}
                              </Form.Label>
                              <InputGroup>
                                <Form.Control
                                  type="number"
                                  name="overlap"
                                  value={formData.overlap}
                                  onChange={handleInputChange}
                                  className="border-0 bg-light"
                                />
                                <InputGroup.Text className="bg-light">
                                  tokens
                                </InputGroup.Text>
                              </InputGroup>
                            </Form.Group>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Chunk Strategy
                              </Form.Label>
                              <Form.Select
                                name="chunkStrategy"
                                value={formData.chunkStrategy}
                                onChange={handleInputChange}
                                className="border-0 bg-light"
                              >
                                <option value="fixed">Fixed Size</option>
                                <option value="semantic">
                                  Semantic Boundaries
                                </option>
                                <option value="hybrid">Hybrid</option>
                              </Form.Select>
                              <Form.Text className="text-muted">
                                Determines how text is split into chunks for
                                processing
                              </Form.Text>
                            </Form.Group>

                            <div className="p-3 bg-light rounded mb-4">
                              <h6 className="mb-3">Chunking Preview</h6>
                              <div className="d-flex align-items-center mb-2">
                                <div className="flex-grow-1">
                                  <ProgressBar
                                    now={70}
                                    variant="primary"
                                    className="rounded-pill"
                                    style={{ height: "8px" }}
                                  />
                                </div>
                                <span className="ms-3 text-muted">70%</span>
                              </div>
                              <small className="text-muted">
                                Estimated chunk size based on your settings
                              </small>
                            </div>
                          </Tab.Pane>

                          <Tab.Pane eventKey="processing">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                              <h4 className="mb-0">Processing Rules</h4>
                              <Badge bg="warning" className="px-3 py-2">
                                <FiFilter className="me-1" />
                                Data Cleaning
                              </Badge>
                            </div>

                            <div className="p-3 bg-light rounded mb-4">
                              <h6 className="mb-3">Text Processing Options</h6>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="deleteConsecutiveSpaces"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>
                                        Delete consecutive spaces and tabs
                                      </span>
                                      {renderTooltip(
                                        "Removes multiple spaces and tabs to clean up text"
                                      )}
                                    </div>
                                  }
                                  name="deleteConsecutiveSpaces"
                                  checked={formData.deleteConsecutiveSpaces}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="deletePII"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Delete PII and PHI Information</span>
                                      {renderTooltip(
                                        "Removes personally identifiable information and protected health information"
                                      )}
                                    </div>
                                  }
                                  name="deletePII"
                                  checked={formData.deletePII}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="preserveHeaders"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Preserve Headers</span>
                                      {renderTooltip(
                                        "Maintains document structure by preserving headers"
                                      )}
                                    </div>
                                  }
                                  name="preserveHeaders"
                                  checked={formData.preserveHeaders}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>
                            </div>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Custom Regex Rules
                              </Form.Label>
                              <Form.Control
                                as="textarea"
                                rows={3}
                                name="customRegexRules"
                                value={formData.customRegexRules}
                                onChange={handleInputChange}
                                placeholder="Enter custom regex patterns (one per line)"
                                className="border-0 bg-light"
                              />
                              <Form.Text className="text-muted">
                                Add custom regex patterns for advanced text
                                processing
                              </Form.Text>
                            </Form.Group>
                          </Tab.Pane>

                          <Tab.Pane eventKey="search">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                              <h4 className="mb-0">Search Configuration</h4>
                              <Badge bg="success" className="px-3 py-2">
                                <FiSearch className="me-1" />
                                Search
                              </Badge>
                            </div>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Embedding Model
                              </Form.Label>
                              <Form.Select
                                name="embeddingModel"
                                value={formData.embeddingModel}
                                onChange={handleInputChange}
                                className="border-0 bg-light"
                              >
                                <option value="BERT-uncased">BERT-uncased</option>
                                <option value="GPT">GPT Embeddings</option>
                                <option value="custom">Custom Model</option>
                              </Form.Select>
                              <Form.Text className="text-muted">
                                Select the model used for generating embeddings
                              </Form.Text>
                            </Form.Group>

                            <div className="p-3 bg-light rounded mb-4">
                              <h6 className="mb-3">Search Methods</h6>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="enableVectorSearch"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Enable Vector Search</span>
                                      {renderTooltip(
                                        "Uses semantic similarity for search"
                                      )}
                                    </div>
                                  }
                                  name="enableVectorSearch"
                                  checked={formData.enableVectorSearch}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="enableKeywordSearch"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Enable Keyword Search</span>
                                      {renderTooltip(
                                        "Uses traditional keyword matching"
                                      )}
                                    </div>
                                  }
                                  name="enableKeywordSearch"
                                  checked={formData.enableKeywordSearch}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="enableHybridSearch"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Enable Hybrid Search</span>
                                      {renderTooltip(
                                        "Combines vector and keyword search for better results"
                                      )}
                                    </div>
                                  }
                                  name="enableHybridSearch"
                                  checked={formData.enableHybridSearch}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>
                            </div>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Minimum Relevance Score
                                {renderTooltip(
                                  "Minimum score threshold for search results"
                                )}
                              </Form.Label>
                              <InputGroup>
                                <Form.Control
                                  type="number"
                                  name="minRelevanceScore"
                                  value={formData.minRelevanceScore}
                                  onChange={handleInputChange}
                                  step="0.1"
                                  min="0"
                                  max="1"
                                  className="border-0 bg-light"
                                />
                                <InputGroup.Text className="bg-light">
                                  0.0 - 1.0
                                </InputGroup.Text>
                              </InputGroup>
                            </Form.Group>
                          </Tab.Pane>

                          <Tab.Pane eventKey="workflow">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                              <h4 className="mb-0">Workflow & Triggers</h4>
                              <Badge bg="danger" className="px-3 py-2">
                                <BsLightningCharge className="me-1" />
                                Automation
                              </Badge>
                            </div>

                            <div className="p-3 bg-light rounded mb-4">
                              <h6 className="mb-3">Workflow Options</h6>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="emailProcessingWorkflow"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Enable Email Processing Workflow</span>
                                      {renderTooltip(
                                        "Automatically process incoming emails"
                                      )}
                                    </div>
                                  }
                                  name="emailProcessingWorkflow"
                                  checked={formData.emailProcessingWorkflow}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="postToAgent"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Post to Agent</span>
                                      {renderTooltip(
                                        "Send processed content to an agent"
                                      )}
                                    </div>
                                  }
                                  name="postToAgent"
                                  checked={formData.postToAgent}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>
                            </div>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Queue Template
                              </Form.Label>
                              <Form.Control
                                type="text"
                                name="queueTemplate"
                                value={formData.queueTemplate}
                                onChange={handleInputChange}
                                placeholder="Enter queue template"
                                className="border-0 bg-light"
                              />
                              <Form.Text className="text-muted">
                                Template for queue processing
                              </Form.Text>
                            </Form.Group>
                          </Tab.Pane>

                          <Tab.Pane eventKey="advanced">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                              <h4 className="mb-0">Advanced Settings</h4>
                              <Badge bg="secondary" className="px-3 py-2">
                                <BsGear className="me-1" />
                                Advanced
                              </Badge>
                            </div>

                            <Form.Group className="mb-4">
                              <Form.Label className="fw-bold">
                                Max Queries per Minute
                                {renderTooltip("Rate limiting for API requests")}
                              </Form.Label>
                              <InputGroup>
                                <Form.Control
                                  type="number"
                                  name="maxQueriesPerMinute"
                                  value={formData.maxQueriesPerMinute}
                                  onChange={handleInputChange}
                                  className="border-0 bg-light"
                                />
                                <InputGroup.Text className="bg-light">
                                  queries/min
                                </InputGroup.Text>
                              </InputGroup>
                            </Form.Group>

                            <div className="p-3 bg-light rounded mb-4">
                              <h6 className="mb-3">Caching Options</h6>

                              <Form.Group className="mb-3">
                                <Form.Check
                                  type="checkbox"
                                  id="cacheResults"
                                  label={
                                    <div className="d-flex align-items-center">
                                      <span>Enable Result Caching</span>
                                      {renderTooltip(
                                        "Cache search results for improved performance"
                                      )}
                                    </div>
                                  }
                                  name="cacheResults"
                                  checked={formData.cacheResults}
                                  onChange={handleInputChange}
                                  className="form-check-input-lg"
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Label className="fw-bold">
                                  Cache Duration (hours)
                                </Form.Label>
                                <InputGroup>
                                  <Form.Control
                                    type="number"
                                    name="cacheDuration"
                                    value={formData.cacheDuration}
                                    onChange={handleInputChange}
                                    disabled={!formData.cacheResults}
                                    className="border-0 bg-light"
                                  />
                                  <InputGroup.Text className="bg-light">
                                    hours
                                  </InputGroup.Text>
                                </InputGroup>
                              </Form.Group>
                            </div>
                          </Tab.Pane>
                        </Tab.Content>

                        <div className="mt-4 pt-3 border-top d-flex justify-content-between align-items-center">
                          <Button
                            variant="outline-secondary"
                            className="d-flex align-items-center"
                            onClick={() => navigate(-1)}
                          >
                            <FiArrowLeft className="me-2" />
                            Back
                          </Button>
                          <div>
                            <Button
                              variant="primary"
                              type="submit"
                              disabled={isSubmitting}
                              className="d-flex align-items-center"
                              onClick={handleSubmit}
                            >
                              {isSubmitting ? (
                                <>
                                  <span
                                    className="spinner-border spinner-border-sm me-2"
                                    role="status"
                                    aria-hidden="true"
                                  ></span>
                                  Saving...
                                </>
                              ) : (
                                <>
                                  <FiSave className="me-2" />
                                  {isEditMode ? "Update" : "Create"} Knowledge Base
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      </Form>
                    </div>
                  </Col>
                </Row>
              </Tab.Container>
            </Card.Body>
          </Card>
        </>
      )}
    </>
  );
};

export default KnowledgeBaseConfig;
