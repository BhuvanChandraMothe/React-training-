import React, { useState, useEffect, useRef } from "react";
import {
  Card,
  Form,
  Button,
  InputGroup,
  Spinner,
  Dropdown,
} from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import Markdown from "react-markdown";

const ChatPreview = ({ appData, user, modelConfig, selectedDatasetId }) => {
  const [chatMessages, setChatMessages] = useState([
    {
      text:
        modelConfig?.[0]?.opening_statement ||
        "👋 Hello! I'm your AI assistant. Test your chatbot here.",
      isBot: true,
      timestamp: "09:30 AM",
    },
  ]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [conversationId, setConversationId] = useState(null);
  const messagesEndRef = useRef(null);
  const navigate = useNavigate();
  const [datasets, setDatasets] = useState([]);
  const [loading, setLoading] = useState(false);

  const [windowHeight, setWindowHeight] = useState(window.innerHeight);

  // Fetch datasets when component mounts
  useEffect(() => {
    if (user?.access_token) {
      fetchDatasets();
    }
  }, [user?.access_token]);

  const fetchDatasets = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/datasets/", {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${user?.access_token}`,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      // console.log("Datasets loaded:", data);
      setDatasets(data);
    } catch (error) {
      console.error("Error fetching datasets:", error);
    } finally {
      setLoading(false);
    }
  };

  // useEffect(() => {
  //   // Scroll to bottom whenever messages change
  //   messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  // }, [chatMessages]);

  const handleSendMessage = async () => {
    if (!userInput.trim() || isLoading) return;

    // Add user message
    setChatMessages((prev) => [
      ...prev,
      {
        text: userInput,
        isUser: true,
        timestamp: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      },
    ]);
    setIsLoading(true);
    setIsTyping(true);

    // Add a temporary loading message that will be replaced
    const tempId = Date.now();
    setChatMessages((prev) => [
      ...prev,
      {
        id: tempId,
        text: "",
        isBot: true,
        isLoading: true,
        timestamp: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      },
    ]);

    try {
      const model = modelConfig?.[0]?.model || "gpt-3.5-turbo";

      // Use the first dataset by default if none selected
      const datasetToUse =
        selectedDatasetId ||
        (datasets && datasets.length > 0 ? datasets[0].id : null);

      const payload = {
        tenant_id: user?.user?.id, // Using user ID as tenant_id from auth context
        app_id: appData?.id, // Using selected app ID
        query: userInput,
        files: [datasetToUse], // Using the first dataset by default
        model: model,
        mode: "chat",
        tools: [],
        conversation_id: conversationId,
        stream: true,
      };

      console.log("Chat payload:", payload);

      // Use the correct API endpoint as in other components
      const response = await fetch("/api/apps/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${user?.access_token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Handle streaming response if supported, else fallback to plain JSON
      if (response.body && response.body.getReader) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let responseText = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });

          // Split by newlines (in case multiple events in one chunk)
          const lines = chunk.split("\n");
          for (let line of lines) {
            line = line.trim();
            if (line.startsWith("data:")) {
              // Remove 'data:' and any leading/trailing whitespace
              const clean = line.replace(/^data:\s*/, "");
              if (clean) {
                try {
                  // Try to parse as JSON to handle properly formatted responses
                  const jsonData = JSON.parse(clean);
                  if (jsonData.response) {
                    responseText = jsonData.response;
                  } else {
                    // Append with space if needed
                    responseText += clean;
                  }
                } catch (e) {
                  // Not valid JSON, so it's likely a text chunk
                  // Add a space if this seems to be a new word (heuristic)
                  if (
                    responseText.length > 0 &&
                    !responseText.endsWith(" ") &&
                    !responseText.endsWith("\n") &&
                    !clean.startsWith(" ") &&
                    !clean.startsWith("\n") &&
                    !clean.match(/^[,.!?;:)\]}"']/)
                  ) {
                    responseText += " ";
                  }
                  responseText += clean;
                }

                setChatMessages((prev) => {
                  const updatedMessages = [...prev];
                  // Find the temporary loading message by its ID and update it
                  const loadingMsgIndex = updatedMessages.findIndex(
                    (msg) => msg.id === tempId
                  );
                  if (loadingMsgIndex !== -1) {
                    updatedMessages[loadingMsgIndex] = {
                      ...updatedMessages[loadingMsgIndex],
                      text: responseText,
                      isLoading: false,
                    };
                  }
                  return updatedMessages;
                });
              }
            }
          }
        }
        // Extract conversation_id if returned in the response
        try {
          const responseObj = JSON.parse(responseText);
          if (responseObj.conversation_id) {
            setConversationId(responseObj.conversation_id);
          }
        } catch (e) {
          // Not JSON or doesn't have conversation_id
        }
      } else {
        // Fallback for non-streaming response
        const data = await response.json();
        setChatMessages((prev) => {
          const updatedMessages = [...prev];
          // Find the temporary loading message by its ID and update it
          const loadingMsgIndex = updatedMessages.findIndex(
            (msg) => msg.id === tempId
          );
          if (loadingMsgIndex !== -1) {
            updatedMessages[loadingMsgIndex] = {
              ...updatedMessages[loadingMsgIndex],
              text: data.response || "No response.",
              isLoading: false,
            };
          }
          return updatedMessages;
        });
        if (data.conversation_id) {
          setConversationId(data.conversation_id);
        }
      }
    } catch (error) {
      console.error("Error sending message:", error);
      setChatMessages((prev) => {
        const updatedMessages = [...prev];
        // Find the temporary loading message by its ID and update it
        const loadingMsgIndex = updatedMessages.findIndex(
          (msg) => msg.id === tempId
        );
        if (loadingMsgIndex !== -1) {
          updatedMessages[loadingMsgIndex] = {
            ...updatedMessages[loadingMsgIndex],
            text: "Sorry, there was an error processing your request.",
            isLoading: false,
          };
        }
        return updatedMessages;
      });
    } finally {
      setIsLoading(false);
      setIsTyping(false);
      setUserInput("");
    }
  };

  const handleClearChat = () => {
    setChatMessages([
      {
        text: "👋 Hello! I'm your AI assistant. Test your chatbot here.",
        isBot: true,
        timestamp: "09:30 AM",
      },
    ]);
    setConversationId(null);
  };

  const handleRunApp = () => {
    if (appData?.id) {
      // Create a conversation before navigating
      createConversation()
        .then((conversationId) => {
          navigate(`/chat/${appData.id}`);
        })
        .catch((error) => {
          console.error("Error creating conversation:", error);
          navigate(`/chat/${appData.id}`); // Navigate anyway even if creation fails
        });
    }
  };

  const createConversation = async () => {
    try {
      const payload = {
        app_id: appData.id,
        name: `Conversation 1`,
        mode: "chat",
        summary: "New conversation",
        status: "normal",
        end_user_id: user?.user?.id,
      };

      const response = await fetch("/api/conversations/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${user?.access_token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.id;
    } catch (error) {
      console.error("Error creating conversation:", error);
      throw error;
    }
  };

  window.onresize = () => {
    // console.log(window.innerHeight);
    setWindowHeight(window.innerHeight);
  };

  return (
    <Card
      className="shadow-sm border-0"
      style={{
        height: `calc(${windowHeight}px - 205px)`,
        maxHeight: "100vh",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* <Card.Header className="d-flex justify-content-between align-items-center py-2 bg-white border-bottom">
        <div className="d-flex align-items-center">
          <div className="position-relative me-2">
            <div
              className="bg-primary rounded-circle d-flex align-items-center justify-content-center"
              style={{ width: "28px", height: "28px" }}
            >
              <i className="mdi mdi-robot text-white fs-6"></i>
            </div>
            <span
              className="position-absolute bottom-0 end-0 bg-success rounded-circle"
              style={{
                width: "8px",
                height: "8px",
                border: "2px solid white",
              }}
            ></span>
          </div>
          <div>
            <h6 className="mb-0 fw-semibold" style={{ fontSize: "13px" }}>
              {appData?.name || "Enterprise Assistant"}
            </h6>
            <small className="text-muted" style={{ fontSize: "10px" }}>
              Online | {modelConfig?.[0]?.model || "GPT-3.5 Turbo"} |
              {datasets && datasets.length > 0
                ? ` ${datasets.length} datasets available`
                : " No datasets"}
            </small>
          </div>
        </div>
        <div>
          <Dropdown align="end">
            <Dropdown.Toggle
              variant="light"
              size="sm"
              className="border-0 rounded-circle"
              style={{ width: "30px", height: "30px" }}
            >
              <i className="mdi mdi-dots-vertical"></i>
            </Dropdown.Toggle>
            <Dropdown.Menu className="shadow-sm border-0">
              <Dropdown.Item onClick={handleClearChat}>
                <i className="mdi mdi-refresh text-primary me-2"></i>
                Clear Conversation
              </Dropdown.Item>
              <Dropdown.Item onClick={handleRunApp}>
                <i className="mdi mdi-play text-success me-2"></i>
                Run App
              </Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item>
                <i className="mdi mdi-cog text-secondary me-2"></i>
                Settings
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </Card.Header> */}
      <Card.Body
        className="p-0 flex-grow-1 d-flex flex-column"
        style={{ overflow: "hidden", position: "relative" }}
      >
        <div
          className="chat-container flex-grow-1 p-1"
          style={{ overflowY: "auto", backgroundColor: "#f8f9fa" }}
        >
          {chatMessages?.map((msg, idx) => (
            <div
              key={msg.id || idx}
              className={`d-flex ${
                msg.isBot ? "justify-content-start" : "justify-content-end"
              } mb-1`}
            >
              {msg.isBot && (
                <div className="me-1 mt-1">
                  <div
                    className="bg-primary rounded-circle d-flex align-items-center justify-content-center"
                    style={{ width: "24px", height: "24px", minWidth: "24px" }}
                  >
                    <i className="mdi mdi-robot text-white fs-6"></i>
                  </div>
                </div>
              )}
              <div
                className={`message-bubble p-2 ${
                  msg.isBot
                    ? "bg-white text-dark shadow-sm border border-light"
                    : "bg-primary text-white"
                }`}
                style={{
                  maxWidth: "90%",
                  padding: "6px 10px",
                  position: "relative",
                  wordWrap: "break-word",
                  borderRadius: msg.isBot
                    ? "0 12px 12px 12px"
                    : "12px 0 12px 12px",
                  boxShadow: msg.isBot
                    ? "0 1px 2px rgba(0,0,0,0.1)"
                    : "0 1px 2px rgba(0,0,0,0.2)",
                  minHeight: msg.isLoading ? "30px" : "auto",
                  minWidth: msg.isLoading ? "50px" : "auto",
                }}
              >
                {msg.isLoading ? (
                  <div className="typing-animation">
                    <div className="typing-dot"></div>
                    <div className="typing-dot"></div>
                    <div className="typing-dot"></div>
                  </div>
                ) : (
                  <div>
                    {/* <Markdown>{msg.text}</Markdown> */}
                    {msg.text}
                  </div>
                )}
              </div>
              {!msg.isBot && (
                <div className="ms-1 mt-1">
                  <div
                    className="bg-secondary rounded-circle d-flex align-items-center justify-content-center"
                    style={{ width: "24px", height: "24px", minWidth: "24px" }}
                  >
                    <i className="mdi mdi-account text-white fs-6"></i>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div
          className="position-absolute bottom-0 start-50 translate-middle-x w-100 p-2"
          style={{
            background: "transparent",
            zIndex: 1000,
          }}
        >
          <InputGroup
            className="shadow-lg rounded-pill"
            style={{
              maxWidth: "600px",
              margin: "0 auto",
              border: "2px solid rgba(13, 110, 253, 0.2)",
              background: "white",
            }}
          >
            <Form.Control
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Ask me anything..."
              className="border-0 py-2 px-3"
              style={{
                backgroundColor: "transparent",
                fontSize: "14px",
                borderRadius: "50px 0 0 50px",
              }}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            />
            <Button
              variant="primary"
              onClick={handleSendMessage}
              disabled={isLoading}
              className="d-flex align-items-center justify-content-center rounded-pill"
              style={{
                width: "45px",
                borderRadius: "0 50px 50px 0",
                boxShadow: "0 2px 8px rgba(13, 110, 253, 0.3)",
              }}
            >
              {isLoading ? (
                <Spinner size="sm" animation="border" />
              ) : (
                <i className="mdi mdi-send fs-6"></i>
              )}
            </Button>
          </InputGroup>
        </div>
      </Card.Body>
    </Card>
  );
};

export default ChatPreview;

// Replace the CSS style block at the end of the file
const style = document.createElement("style");
style.innerHTML = `.typing-animation {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 6px 0;
  height: 16px;
}

.typing-dot {
  display: inline-block;
  width: 8px;
  height: 8px;
  margin: 0 2px;
  border-radius: 50%;
  background-color: #0d6efd;
  opacity: 0.6;
}

.typing-dot:nth-child(1) {
  animation: loadingBounce 1s infinite;
  animation-delay: 0ms;
}

.typing-dot:nth-child(2) {
  animation: loadingBounce 1s infinite;
  animation-delay: 200ms;
}

.typing-dot:nth-child(3) {
  animation: loadingBounce 1s infinite;
  animation-delay: 400ms;
}

@keyframes loadingBounce {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-8px);
    opacity: 1;
  }
}
`;
document.head.appendChild(style);
