import React from "react";
import { Card, Button } from "react-bootstrap";
import { FaFlask, FaFileAlt, FaGlobe } from "react-icons/fa";
import "./AppCard.css";

const AppCard = ({ model, onAddToConfigured }) => {
  const getIconComponent = (iconName) => {
    const iconMap = {
      flask: <FaFlask className="fs-4" />,
      "file-alt": <FaFileAlt className="fs-4" />,
      globe: <FaGlobe className="fs-4" />,
    };

    return iconMap[iconName] || <FaFileAlt className="fs-4" />;
  };

  const handleAddToWorkspace = () => {
    if (onAddToConfigured) {
      onAddToConfigured(model);
    }
  };

  const pickRandomColor = () => {
    const colors = ["#2563eb", "#f97316", "#10b981", "#3b82f6", "#ef4444"];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  return (
    <Card className="h-100 border app-card">
      <Card.Body className="p-3">
        <div className="d-flex flex-column h-100">
          <div className="mb-2 d-flex align-items-center">
            <div
              className="app-icon rounded-circle d-flex align-items-center justify-content-center me-2"
              style={{
                backgroundColor: model.iconBg ?? pickRandomColor(),
                color: model.iconColor ?? "#ffffff",
              }}
            >
              {getIconComponent(model.iconName)}
            </div>
            <div className="d-flex flex-column justify-content-center">
              <h6 className="card-title mb-0 text-capitalize">
                {model.provider}
              </h6>
              <span className="app-type text-muted mt-1">
                {model.type ?? "Chatflow"}
              </span>
            </div>
          </div>

          <p className="app-description text-muted flex-grow-1 mb-2">
            {model.description}
          </p>
        </div>
      </Card.Body>

      <div className="add-to-workspace-overlay">
        <Button
          variant="primary"
          size="sm"
          className="add-to-workspace-btn"
          onClick={handleAddToWorkspace}
        >
          Add this Model
        </Button>
      </div>
    </Card>
  );
};

export default AppCard;
