import React, { useState, useEffect, useRef } from "react";
import {
  Row,
  Col,
  Card,
  Badge,
  Spinner,
  Container,
  Button,
  Dropdown,
  Modal,
  Form,
  Overlay,
  Popover,
} from "react-bootstrap";
import "reactflow/dist/style.css";
import { useNavigate, useParams } from "react-router-dom";
import { get, post, patch } from "../../../api/io";
import { toast } from "react-toastify";
import { MdOutlineWarningAmber } from "react-icons/md";
import {
  FaFolder,
  FaChevronLeft,
  FaChevronRight,
  FaRobot,
} from "react-icons/fa";
import { ImEmbed2 } from "react-icons/im";

import Sidebar from "./components/Sidebar";
import DesignTab from "./components/DesignTab";
import ApiTab from "./components/ApiTab";
import LogsTab from "./components/LogsTab";
import MonitoringTab from "./components/MonitoringTab";
import DebugPanel from "./components/DebugPanel";
import ChatPreview from "../chatbots/components/ChatPreview";
import ModelSelector from "../../../components/ModelSelector";
// import { useAuthContext } from "../../../context/useAuthContext";
// Import other tab components as needed (can be implemented later)
// import ApiAccessTab from './components/ApiAccessTab';
// import LogsTab from './components/LogsTab';
// import MonitoringTab from './components/MonitoringTab';
// import SettingsTab from './components/SettingsTab';
// import DeployTab from './components/DeployTab';
// import ExportTab from './components/ExportTab';

const AgentsConfig = () => {
  const [activeTab, setActiveTab] = useState("design");
  const [appDetails, setAppDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isMinimized, setIsMinimized] = useState(true);
  const [showRightModal, setShowRightModal] = useState(false);
  const [showModelSettingsModal, setShowModelSettingsModal] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const { id } = useParams();
  const navigate = useNavigate();
  // const { user } = useAuthContext();
  const modelTarget = useRef(null);
  const [isAgent, setIsAgent] = useState(window.location.pathname?.includes("agents"));

  // Add new state for form data
  const [formData, setFormData] = useState({
    configs: {
      tools: ["RAGTool"],
      temperature: 0.7,
      max_steps: 5,
      pre_prompt:
        "You are a helpful AI assistant that can use various tools to help users.",
    },
    dataset_id: "",
    opening_statement: "",
    suggested_questions: {},
    suggested_questions_after_answer: {},
    user_input_form: {},
    file_upload: {},
    pre_prompt: "",
    prompt_type: "simple",
    app_id: "",
  });

  // Add new state for datasets
  const [datasets, setDatasets] = useState([]);

  // Fetch app details
  useEffect(() => {
    const fetchAppDetails = async () => {
      if (!id) return;

      setLoading(true);
      try {
        const data = await get(`/apps/${id}`);
        setAppDetails(data);
      } catch (error) {
        console.error("Error fetching app details:", error);
        toast.error("Failed to load app details");
      } finally {
        setLoading(false);
      }
    };

    fetchAppDetails();
  }, [id]);

  // Fetch datasets
  useEffect(() => {
    const fetchDatasets = async () => {
      try {
        const response = await get("/datasets/");
        setDatasets(Array.isArray(response) ? response : []);
      } catch (error) {
        console.error("Error fetching datasets:", error);
        toast.error("Failed to load datasets");
      }
    };

    fetchDatasets();
  }, []);

  // Fetch existing config if any
  useEffect(() => {
    const fetchConfig = async () => {
      setLoading(true);
      try {
        if (id) {
          try {
            const config = await get(`/app-model-configs/app/${id}`);
            if (config) {
              const updatedConfig = {
                ...config[0],
                app_id: id,
                configs: config[0].configs,
              };
              setFormData(updatedConfig);
              // Update the config state with the fetched data
              setConfig((prev) => ({
                ...prev,
                settings: {
                  ...prev.settings,
                  ...config[0].configs,
                },
              }));
            } else {
              setFormData((prev) => ({
                ...prev,
                app_id: id,
              }));
            }
          } catch (error) {
            // console.log("No existing config, creating new one");
            setFormData((prev) => ({
              ...prev,
              app_id: id,
            }));
          }
        }
      } catch (error) {
        console.error("Error fetching config:", error);
        toast.error("Failed to load agent configuration");
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchConfig();
    } else {
      setLoading(false);
    }
  }, [id]);

  // Configuration state for agents
  const [config, setConfig] = useState({
    name: "",
    description: "",
    settings: {
      modelName: "gpt-3.5-turbo",
      temperature: 0.7,
      maxTokens: 1000,
      welcomeText: "Hi! I am your AI agent. How can I help you today?",
      enableSpeechToText: false,
      showDocumentSource: true,
      moderateOutput: true,
      variables: [],
      maxIterations: 4,
      prompt: `Respond to the human as helpfully and accurately as possible.

{{instruction}}

You have access to the following tools:

{{tools}}

Use a json blob to specify a tool by providing an {{TOOL_NAME_KEY}} key (tool name) and an {{ACTION_INPUT_KEY}} key (tool input).
Valid "{{TOOL_NAME_KEY}}" values: "Final Answer" or {{tool_names}}

Provide only ONE action per $JSON_BLOB, as shown:

\`\`\`
{
  "{{TOOL_NAME_KEY}}": $TOOL_NAME,
  "{{ACTION_INPUT_KEY}}": $ACTION_INPUT
}
\`\`\``,
    },
    knowledgeBase: {
      selectedKnowledgeBase: "",
      datasources: [],
    },
    workflow: {
      nodes: [],
      edges: [],
    },
  });

  const [selectedModel, setSelectedModel] = useState(
    config.settings.modelName || "gpt-3.5-turbo"
  );

  // Define model groups with their models (same as ModelSelector.jsx)
  const modelGroups = {
    OpenAI: [
      {
        id: "gpt-3.5-turbo-0125",
        name: "GPT-3.5 Turbo 0125",
        icon: <FaRobot className="text-success" />,
        tooltip: "Good balance of performance and cost",
      },
      {
        id: "gpt-3.5-turbo-1106",
        name: "GPT-3.5 Turbo 1106",
        icon: <FaRobot className="text-success" />,
        tooltip: "Updated version with improvements",
      },
      {
        id: "gpt-3.5-turbo-16k",
        name: "GPT-3.5 Turbo 16k",
        icon: <FaRobot className="text-success" />,
        tooltip: "Extended context length model",
      },
      {
        id: "gpt-3.5-turbo-instruct",
        name: "GPT-3.5 Turbo Instruct",
        icon: <FaRobot className="text-success" />,
        tooltip: "Optimized for instruction following",
      },
      {
        id: "gpt-3.5-turbo",
        name: "GPT-3.5 Turbo",
        icon: <FaRobot className="text-success" />,
        tooltip: "Default GPT-3.5 model",
      },
      {
        id: "gpt-4o-mini-2024-07-18",
        name: "GPT-4o Mini 2024-07-18",
        icon: <FaRobot className="text-primary" />,
        tooltip: "Newest compact GPT-4 model",
      },
      {
        id: "gpt-4o-mini",
        name: "GPT-4o Mini",
        icon: <FaRobot className="text-primary" />,
        tooltip: "Compact GPT-4 model",
      },
    ],
    Anthropic: [
      {
        id: "claude-3-opus",
        name: "Claude 3 Opus",
        icon: <FaRobot className="text-warning" />,
        tooltip: "Most powerful Claude model",
      },
      {
        id: "claude-3-sonnet",
        name: "Claude 3 Sonnet",
        icon: <FaRobot className="text-warning" />,
        tooltip: "Balanced performance",
      },
      {
        id: "claude-3-haiku",
        name: "Claude 3 Haiku",
        icon: <FaRobot className="text-warning" />,
        tooltip: "Fast and efficient",
      },
    ],
    Google: [
      {
        id: "gemini-pro",
        name: "Gemini Pro",
        icon: <FaRobot className="text-danger" />,
        tooltip: "Google's advanced model",
      },
      {
        id: "gemini-flash",
        name: "Gemini Flash",
        icon: <FaRobot className="text-danger" />,
        tooltip: "Fast response model",
      },
    ],
  };

  // Flatten all models for search
  const allModels = Object.values(modelGroups).flat();

  // Update selected model when config changes
  useEffect(() => {
    setSelectedModel(config.settings.modelName);
  }, [config.settings.modelName]);

  // Get information about the selected model
  const getSelectedModelInfo = () => {
    return (
      allModels.find((model) => model.id === selectedModel) || {
        id: selectedModel,
        name: selectedModel,
        icon: <FaRobot className="text-secondary" />,
        tooltip: "Model information not available",
      }
    );
  };

  const selectedModelInfo = getSelectedModelInfo();

  const handleConfigChange = (section, field, value) => {
    if (section === "configs") {
      setConfig((prev) => ({
        ...prev,
        settings: {
          ...prev.settings,
          [field]: value,
        },
      }));
    } else {
      setConfig((prev) => ({
        ...prev,
        [section]:
          typeof field === "string"
            ? value
            : {
                ...prev[section],
                [field]: value,
              },
      }));
    }
  };

  // Handle model selection
  const handleModelSelect = (modelId) => {
    setSelectedModel(modelId);
    // handleConfigChange("settings", "modelName", modelId);
    setShowModelDropdown(false);
  };

  const handleModelSettingsChange = (newSettings) => {
    const updatedSettings = {
      ...config.settings,
      ...newSettings,
    };

    setConfig((prev) => ({
      ...prev,
      settings: updatedSettings,
    }));
  };

  // Handle form changes
  const handleFormChange = (e) => {
    const { name, value } = e.target;

    if (name.includes(".")) {
      const [parent, child] = name.split(".");
      setFormData((prev) => ({
        ...prev,
        [parent]: {
          ...(prev[parent] || {}),
          [child]: value,
        },
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  // Handle tool toggle
  const handleToolToggle = (tool) => {
    setFormData((prev) => {
      const configs = prev.configs || {};
      const currentTools = [...(configs.tools || [])];
      const toolIndex = currentTools.indexOf(tool);

      if (toolIndex === -1) {
        currentTools.push(tool);
      } else {
        currentTools.splice(toolIndex, 1);
      }

      return {
        ...prev,
        configs: {
          ...configs,
          tools: currentTools,
        },
      };
    });
  };

  // Handle form submission
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      if (formData.id) {
        await patch(`/app-model-configs/${formData.id}`, formData);
        toast.success("Agent configuration updated successfully!");
      } else {
        await post("/app-model-configs/", formData);
        toast.success("Agent configuration saved successfully!");
      }
    } catch (error) {
      console.error("Error saving config:", error);
      toast.error("Failed to save agent configuration");
    } finally {
      setSaving(false);
    }
  };

  // Update handleModelSettingsSave to use the same API endpoints
  const handleModelSettingsSave = async () => {
    try {
      const configData = {
        ...formData,
        configs: {
          ...formData.configs,
          ...config.settings,
          temperature: config.settings.temperature,
          max_steps: config.settings.maxSteps,
          prompt_type: config.settings.promptType,
        },
      };

      if (formData.id) {
        await patch(`/app-model-configs/${formData.id}`, configData);
        toast.success("Model settings updated successfully!");
      } else {
        const response = await post("/app-model-configs/", configData);
        setFormData((prev) => ({
          ...prev,
          id: response.id,
        }));
        toast.success("Model settings saved successfully!");
      }

      setShowModelSettingsModal(false);
    } catch (error) {
      console.error("Error saving model settings:", error);
      toast.error("Failed to save model settings");
    }
  };

  // Add handleAgentSettingsSave function
  const handleAgentSettingsSave = async () => {
    try {
      const configData = {
        ...formData,
        configs: {
          ...formData.configs,
          max_steps: config.settings.maxSteps,
          prompt: config.settings.prompt,
        },
      };

      if (formData.id) {
        await patch(`/app-model-configs/${formData.id}`, configData);
        toast.success("Agent settings updated successfully!");
      } else {
        const response = await post("/app-model-configs/", configData);
        setFormData((prev) => ({
          ...prev,
          id: response.id,
        }));
        toast.success("Agent settings saved successfully!");
      }

      setShowRightModal(false);
    } catch (error) {
      console.error("Error saving agent settings:", error);
      toast.error("Failed to save agent settings");
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "design":
        return (
          <DesignTab
            formData={formData}
            datasets={datasets}
            onFormChange={handleFormChange}
            onToolToggle={handleToolToggle}
            onFormSubmit={handleFormSubmit}
            saving={saving}
            isAgent={isAgent}
          />
        );
      case "api":
        return <ApiTab formData={formData} onFormChange={handleFormChange} />;
      case "logs":
        return <LogsTab />;
      case "monitoring":
        return <MonitoringTab />;
      default:
        return <div>Coming soon: {activeTab} content</div>;
    }
  };

  // Helper function to get badge color based on status
  const getStatusColor = (status) => {
    switch (status) {
      case "normal":
        return "success";
      case "draft":
        return "warning";
      case "disabled":
        return "danger";
      default:
        return "secondary";
    }
  };

  // Helper function to get icon based on type
  const getTypeIcon = (type) => {
    switch (type) {
      case "chatbot":
        return "mdi-robot";
      case "agent":
        return "mdi-brain";
      case "workflow":
        return "mdi-flow";
      default:
        return "mdi-robot";
    }
  };

  const FileItem = () => {
    return (
      <Card
        className="p-3 mb-2 shadow-sm rounded border-0"
        style={{ backgroundColor: "#f8f9fa" }}
      >
        <Row className="align-items-center">
          <Col xs="auto">
            <FaFolder color="#6f42c1" size={20} />
          </Col>
          <Col>
            <span className="fw-medium">README.md</span>
          </Col>
          <Col xs="auto">
            <Badge bg="light" text="dark" className="rounded-pill border">
              ECO · INVERTED
            </Badge>
          </Col>
        </Row>
      </Card>
    );
  };

  const toggleSidebar = () => {
    setIsMinimized((prev) => !prev);
  };

  const toggleRightModal = () => {
    setShowRightModal(!showRightModal);
  };

  return (
    <div className="agents-container">
      <Row className="g-0 h-100 mt-3">
        <Col md={7} className="pe-2">
          <Card className="rounded-4">
            <Card.Body className="p-0 mt-2 mb-2">
              <Row className="g-0 h-100">
                {/* Left Sidebar */}
                <Col
                  md={isMinimized ? 1 : 3}
                  className="border-end rounded-3"
                  style={{ transition: "width 0.3s ease" }}
                >
                  <div className="d-flex justify-content-end p-2">
                    <Button
                      variant="light"
                      size="sm"
                      className="border-0"
                      onClick={toggleSidebar}
                      aria-label={
                        isMinimized ? "Expand sidebar" : "Minimize sidebar"
                      }
                    >
                      {isMinimized ? <FaChevronRight /> : <FaChevronLeft />}
                    </Button>
                  </div>

                  {!isMinimized && loading && (
                    <div className="p-4 text-center">
                      <Spinner animation="border" variant="primary" />
                      <p className="mt-2">Loading app details...</p>
                    </div>
                  )}

                  {!isMinimized && appDetails && (
                    <div className="p-2 border-bottom">
                      <Row className="align-items-center">
                        <Col xs="auto">
                          <div className="app-icon-wrapper rounded-circle bg-primary bg-opacity-10 px-2">
                            <i
                              className={`mdi ${getTypeIcon(
                                appDetails.type
                              )} text-primary fs-2`}
                            ></i>
                          </div>
                        </Col>
                        <Col>
                          <h4 className="mb-1">
                            {appDetails?.name?.toUpperCase() || ""}
                          </h4>
                          <p className="text-muted mb-1">
                            {appDetails?.description || ""}
                          </p>
                          <div>
                            <Badge bg="info" className="text-uppercase">
                              {appDetails.type || "AI Agent"}
                            </Badge>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  )}

                  {isMinimized ? (
                    <div className="d-flex flex-column align-items-center py-3">
                      {["design", "api", "logs", "monitoring"].map((tab) => (
                        <Button
                          key={tab}
                          variant={activeTab === tab ? "primary" : "light"}
                          className="mb-2 p-1"
                          size="sm"
                          onClick={() => setActiveTab(tab)}
                          title={tab.charAt(0).toUpperCase() + tab.slice(1)}
                        >
                          <i
                            className={`mdi mdi-${
                              tab === "design"
                                ? "palette"
                                : tab === "api"
                                ? "api"
                                : tab === "logs"
                                ? "text"
                                : "chart-line"
                            }`}
                          ></i>
                        </Button>
                      ))}
                    </div>
                  ) : (
                    <Sidebar
                      activeTab={activeTab}
                      setActiveTab={setActiveTab}
                    />
                  )}
                </Col>

                {/* Main Content Area - Always visible */}
                <Col
                  md={isMinimized ? 11 : 9}
                  style={{ transition: "width 0.3s ease" }}
                >
                  <div className="d-flex flex-column">
                    <div
                      className="flex-grow-1"
                      style={{
                        overflowY: "auto",
                        overflowX: "hidden",
                      }}
                    >
                      {renderTabContent()}
                    </div>
                  </div>
                </Col>
              </Row>
            </Card.Body>
          </Card>
        </Col>

        {/* Right Section - Debug Panel */}
        <Col md={5}>
          <Card className="rounded-4">
            <Card.Body className="p-0">
              {/* <DebugPanel /> */}

              <div className="m-1 d-flex justify-content-end">
                {/* <h5 className="me-auto font-weight-bold ps-2">Debug & Test</h5> */}
                <div className="d-flex align-items-center me-auto ps-1">
                  <div className="position-relative me-2">
                    <div
                      className="bg-primary rounded-circle d-flex align-items-center justify-content-center"
                      style={{ width: "28px", height: "28px" }}
                    >
                      <i className="mdi mdi-robot text-white fs-6"></i>
                    </div>
                    <span
                      className="position-absolute bottom-0 end-0 bg-success rounded-circle"
                      style={{
                        width: "8px",
                        height: "8px",
                        border: "2px solid white",
                      }}
                    ></span>
                  </div>
                  <div>
                    <h6
                      className="mb-0 fw-semibold"
                      style={{ fontSize: "13px" }}
                    >
                      Debug & Test
                    </h6>
                    <small className="text-muted" style={{ fontSize: "10px" }}>
                      Online | {config.settings.modelName || "GPT-3.5 Turbo"} |
                      2
                      {/* {datasets && datasets.length > 0
                        ? ` ${datasets.length} datasets available`
                        : " No datasets"} */}
                    </small>
                  </div>
                </div>
                {isAgent && (
                  <Button
                    variant="soft-info"
                    size="sm"
                    style={{ height: "30px" }}
                    className="btn-xs me-2 rounded-pill waves-effect waves-light mt-1"
                    onClick={toggleRightModal}
                >
                    <i className="mdi mdi-cog me-1"></i> Agent Settings
                  </Button>
                )}

                {isAgent && (
                  <Button
                    variant="soft-success"
                    size="sm"
                    style={{ height: "30px" }}
                    className="btn-xs rounded-pill waves-effect waves-light mt-1 pb-1"
                    onClick={() => setShowModelSettingsModal(true)}
                >
                  {/* <FaRobot className="text-success" /> */}
                  <i className="mdi mdi-robot me-1"></i> Model
                  <MdOutlineWarningAmber className="ms-2 text-warning" />
                  </Button>
                )}

                {/* <ModelSelector
                  selectedModel={config.settings.modelName}
                  onModelSelect={handleModelSelect}
                  modelSettings={{
                    temperature: config.settings.temperature,
                    topP: config.settings.topP,
                    presencePenalty: config.settings.presencePenalty,
                    frequencyPenalty: config.settings.frequencyPenalty,
                    maxTokens: config.settings.maxTokens,
                    responseFormat: config.settings.responseFormat,
                  }}
                  onModelSettingsChange={handleModelSettingsChange}
                  size="sm"
                /> */}
                {/* <Button
                  variant="primary"
                  className="d-flex align-items-center ms-2"
                  size="sm"
                >
                  Publish <i className="mdi mdi-chevron-down ms-1"></i>
                </Button> */}
                <Dropdown align="end" className="m-1 border-1">
                  <Dropdown.Toggle
                    as="a"
                    bsPrefix="card-drop"
                    className="cursor-pointer p-2"
                  >
                    <i className="mdi mdi-dots-vertical font-16 text-secondary"></i>
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item onClick={() => navigate(`/chat/${id}`)}>
                      <i className="mdi mdi-play text-success me-2"></i>
                      Run App
                    </Dropdown.Item>
                    <Dropdown.Item>
                      {/* <i className="mdi mdi-play text-success me-2"></i> */}
                      <ImEmbed2 className="text-success me-2" />
                      Embed App
                    </Dropdown.Item>
                    <Dropdown.Divider />
                    <Dropdown.Item>
                      <i className="mdi mdi-refresh text-primary me-2"></i>
                      Clear Conversation
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </div>

              {/* <ChatPreview
                appData={appDetails}
                user={user}
                modelConfig={config}
                selectedDatasetId={null}
              /> */}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* =============== Agent Settings Modal =============== */}
      <Modal
        show={showRightModal}
        onHide={toggleRightModal}
        dialogClassName="modal-right"
        className="fade"
      >
        <Modal.Header closeButton>
          <h4 className="modal-title">Agent Settings</h4>
        </Modal.Header>
        <Modal.Body style={{ width: "500px" }}>
          <div className="mb-4">
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-flex align-items-center">
                <FaRobot className="text-primary me-2" />
                <h6 className="mb-0">Agent Mode</h6>
                <i
                  className="mdi mdi-information-outline ms-2 text-muted"
                  style={{ fontSize: "16px" }}
                ></i>
              </div>
              <div>
                <Badge bg="light" text="dark" className="px-3 py-2">
                  ReAct
                </Badge>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <div className="d-flex align-items-center mb-2">
              <div className="d-flex align-items-center">
                <i
                  className="mdi mdi-repeat text-warning me-2"
                  style={{ fontSize: "20px" }}
                ></i>
                <h6 className="mb-0">Maximum Steps</h6>
                <i
                  className="mdi mdi-information-outline ms-2 text-muted"
                  style={{ fontSize: "16px" }}
                ></i>
              </div>
            </div>
            <div className="d-flex align-items-center">
              <Form.Range
                className="flex-grow-1 me-2"
                min={1}
                max={10}
                step={1}
                value={formData.configs.max_steps || 5}
                onChange={(e) =>
                  handleFormChange({
                    target: {
                      name: "configs.max_steps",
                      value: parseInt(e.target.value)
                    }
                  })
                }
              />
              <Badge bg="light" text="dark" className="px-3 py-2">
                {formData.configs.max_steps || 5}
              </Badge>
            </div>
            <div className="text-muted mt-1" style={{ fontSize: "10px" }}>
              Maximum number of reasoning steps
            </div>
          </div>

          <div className="mb-4">
            <h6 className="mb-3">Prompt</h6>
            <Form.Control
              as="textarea"
              rows={12}
              className="bg-light border-0"
              value={config.settings.prompt}
              onChange={(e) =>
                handleConfigChange("settings", "prompt", e.target.value)
              }
            />
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="light" onClick={toggleRightModal}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleAgentSettingsSave}>
            Save
          </Button>
        </Modal.Footer>
      </Modal>

      {/* =============== Model Settings Modal =============== */}
      <Modal
        show={showModelSettingsModal}
        onHide={() => setShowModelSettingsModal(false)}
        dialogClassName="modal-right"
        className="fade"
      >
        <div className="modal-content h-100 d-flex flex-column">
          <Modal.Header closeButton className="py-3 px-4 border-bottom">
            <h5 className="modal-title fs-6 fw-semibold m-0">Model Settings</h5>
          </Modal.Header>
          <Modal.Body className="p-0 flex-grow-1 overflow-auto">
            <div className="p-3">
              {/* Model Selection Section */}
              <div className="mb-4">
                <h6
                  className="mb-2 text-uppercase fw-bold"
                  style={{ fontSize: "11px", letterSpacing: "0.5px" }}
                >
                  MODEL
                </h6>
                <div className="position-relative" ref={modelTarget}>
                  <div
                    className="d-flex align-items-center p-2 rounded bg-light"
                    style={{ cursor: "pointer" }}
                    onClick={() => setShowModelDropdown(!showModelDropdown)}
                  >
                    <div className="me-2">{selectedModelInfo.icon}</div>
                    <div className="flex-grow-1">
                      <div className="d-flex align-items-center">
                        <span className="me-2 fw-medium small">
                          {selectedModelInfo.name}
                        </span>
                        <Badge
                          bg="secondary"
                          className="px-2"
                          style={{ fontSize: "9px" }}
                        >
                          CHAT
                        </Badge>
                      </div>
                      <div className="text-muted" style={{ fontSize: "10px" }}>
                        {selectedModelInfo.id}
                      </div>
                    </div>
                    <i
                      className={`mdi mdi-chevron-${
                        showModelDropdown ? "up" : "down"
                      }`}
                    ></i>
                  </div>

                  <Overlay
                    show={showModelDropdown}
                    target={modelTarget.current}
                    placement="bottom"
                    container={document.body}
                    rootClose
                    onHide={() => setShowModelDropdown(false)}
                  >
                    <Popover
                      className="model-selector-popover"
                      style={{ minWidth: "300px", maxWidth: "320px" }}
                    >
                      <Popover.Body className="p-2">
                        <div className="model-list">
                          {Object.entries(modelGroups).map(
                            ([groupName, models]) => (
                              <div key={groupName} className="model-group mb-2">
                                <div
                                  className="model-group-name mb-1 text-muted"
                                  style={{ fontSize: "11px" }}
                                >
                                  {groupName}
                                </div>
                                {models.map((model) => (
                                  <div
                                    key={model.id}
                                    className={`model-item d-flex align-items-center p-2 rounded ${
                                      selectedModel === model.id
                                        ? "selected bg-light"
                                        : ""
                                    }`}
                                    onClick={() => handleModelSelect(model.id)}
                                    style={{ cursor: "pointer" }}
                                  >
                                    <div className="model-icon me-2">
                                      {model.icon}
                                    </div>
                                    <div className="model-details flex-grow-1">
                                      <div className="model-name small">
                                        {model.name}
                                      </div>
                                      <div
                                        className="model-id text-muted"
                                        style={{ fontSize: "10px" }}
                                      >
                                        {model.id}
                                      </div>
                                    </div>
                                    {selectedModel === model.id && (
                                      <i className="mdi mdi-check text-success"></i>
                                    )}
                                  </div>
                                ))}
                              </div>
                            )
                          )}
                        </div>
                      </Popover.Body>
                    </Popover>
                  </Overlay>
                </div>
              </div>

              {/* Parameters Section */}
              <div>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h6
                    className="mb-0 text-uppercase fw-bold"
                    style={{ fontSize: "11px", letterSpacing: "0.5px" }}
                  >
                    PARAMETERS
                  </h6>
                  <Button
                    variant="light"
                    size="sm"
                    className="py-0 px-2 rounded-pill"
                    style={{ fontSize: "11px" }}
                  >
                    Load Presets
                  </Button>
                </div>

                {/* Temperature */}
                <div className="mb-3">
                  <div className="d-flex align-items-center mb-2">
                    <Form.Check
                      type="checkbox"
                      id="temp-toggle"
                      className="me-2"
                      checked={config.settings.temperature !== undefined}
                      onChange={(e) =>
                        handleConfigChange(
                          "configs",
                          "temperature",
                          e.target.checked ? 0.7 : undefined
                        )
                      }
                    />
                    <Form.Label htmlFor="temp-toggle" className="mb-0">
                      Temperature
                    </Form.Label>
                    <i className="mdi mdi-information-outline ms-2 text-muted"></i>
                  </div>
                  <div className="d-flex align-items-center">
                    <Form.Range
                      disabled={config.settings.temperature === undefined}
                      className="flex-grow-1 me-2"
                      min={0}
                      max={1}
                      step={0.1}
                      value={config.settings.temperature || 0.7}
                      onChange={(e) =>
                        handleConfigChange(
                          "configs",
                          "temperature",
                          parseFloat(e.target.value)
                        )
                      }
                    />
                    <div className="bg-light px-3 py-1 rounded small">
                      {config.settings.temperature || 0.7}
                    </div>
                  </div>
                  <div className="d-flex justify-content-between mt-1">
                    <span className="text-muted" style={{ fontSize: "10px" }}>
                      More Precise
                    </span>
                    <span className="text-muted" style={{ fontSize: "10px" }}>
                      More Creative
                    </span>
                  </div>
                </div>

                {/* Max Tokens */}
                <div className="mb-3">
                  <div className="d-flex align-items-center mb-2">
                    <Form.Check
                      type="checkbox"
                      id="max-tokens-toggle"
                      className="me-2"
                      checked={config.settings.maxTokens !== undefined}
                      onChange={(e) =>
                        handleConfigChange(
                          "configs",
                          "maxTokens",
                          e.target.checked ? 1000 : undefined
                        )
                      }
                    />
                    <Form.Label htmlFor="max-tokens-toggle" className="mb-0">
                      Max Tokens
                    </Form.Label>
                    <i className="mdi mdi-information-outline ms-2 text-muted"></i>
                  </div>
                  <div className="d-flex align-items-center">
                    <Form.Range
                      disabled={config.settings.maxTokens === undefined}
                      className="flex-grow-1 me-2"
                      min={100}
                      max={4000}
                      step={100}
                      value={config.settings.maxTokens || 1000}
                      onChange={(e) =>
                        handleConfigChange(
                          "configs",
                          "maxTokens",
                          parseInt(e.target.value)
                        )
                      }
                    />
                    <div className="bg-light px-3 py-1 rounded small">
                      {config.settings.maxTokens || 1000}
                    </div>
                  </div>
                  <div className="d-flex justify-content-between mt-1">
                    <span className="text-muted" style={{ fontSize: "10px" }}>
                      Short
                    </span>
                    <span className="text-muted" style={{ fontSize: "10px" }}>
                      Long
                    </span>
                  </div>
                </div>

                {/* Prompt Type */}
                <div className="mb-3">
                  <div className="d-flex align-items-center mb-2">
                    <Form.Check
                      type="checkbox"
                      id="prompt-type-toggle"
                      className="me-2"
                      checked={config.settings.promptType !== undefined}
                      onChange={(e) =>
                        handleConfigChange(
                          "configs",
                          "promptType",
                          e.target.checked ? "simple" : undefined
                        )
                      }
                    />
                    <Form.Label htmlFor="prompt-type-toggle" className="mb-0">
                      Prompt Type
                    </Form.Label>
                    <i className="mdi mdi-information-outline ms-2 text-muted"></i>
                  </div>
                  <Form.Select
                    disabled={config.settings.promptType === undefined}
                    size="sm"
                    value={config.settings.promptType || "simple"}
                    onChange={(e) =>
                      handleConfigChange(
                        "configs",
                        "promptType",
                        e.target.value
                      )
                    }
                    className="bg-light border-0"
                  >
                    <option value="simple">Simple</option>
                    <option value="advanced">Advanced</option>
                    <option value="custom">Custom</option>
                  </Form.Select>
                </div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer className="py-2 px-4 border-top mt-auto">
            <Button
              variant="light"
              size="sm"
              onClick={() => setShowModelSettingsModal(false)}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleModelSettingsSave}
            >
              Save
            </Button>
          </Modal.Footer>
        </div>

        <style>
          {`
            .modal-right {
              position: absolute;
              right: 0;
              margin: 0;
              height: 100vh;
              width: 400px !important;
            }
            .modal-right .modal-content {
              height: 100vh;
              border-radius: 0;
              border: none;
            }
            .modal.fade .modal-right {
              transform: translate(100%, 0);
              transition: transform 0.3s ease-out;
            }
            .modal.show .modal-right {
              transform: none;
            }
            .modal-backdrop.fade {
              opacity: 0;
              transition: opacity 0.3s ease-out;
            }
            .modal-backdrop.show {
              opacity: 0.5;
            }
            .modal-header {
              z-index: 1050;
              background: white;
            }
            .modal-header .btn-close {
              padding: 0.75rem;
              margin: 0;
            }
            .modal-footer {
              position: sticky;
              bottom: 0;
              background: white;
              z-index: 1050;
            }
            .model-item {
              transition: background-color 0.15s ease;
              font-size: 0.875rem;
            }
            .model-item:hover {
              background-color: #f8f9fa;
            }
            .model-item.selected {
              background-color: #e9ecef;
            }
            .model-item.selected:hover {
              background-color: #dee2e6;
            }
          `}
        </style>
      </Modal>
    </div>
  );
};

export default AgentsConfig;
