import React from 'react';
import { Row, Col, Card } from 'react-bootstrap';

const dataSources = [
  {
    category: "Storage & Documents",
    items: [
      { name: "Email", icon: "mdi mdi-email-outline", color: "#2196f3", bgColor: "#e3f2fd" },
      { name: "OneDrive", icon: "mdi mdi-microsoft-onedrive", color: "#1565c0", bgColor: "#bbdefb" },
      { name: "SharePoint", icon: "mdi mdi-microsoft", color: "#0d47a1", bgColor: "#e3f2fd" },
      { name: "Data Sheets", icon: "mdi mdi-file-table-outline", color: "#43a047", bgColor: "#e8f5e9" },
    ]
  },
  {
    category: "Cloud Services",
    items: [
      { name: "AWS S3", icon: "mdi mdi-aws", color: "#ff9800", bgColor: "#fff3e0" },
      { name: "Azure Blob", icon: "mdi mdi-microsoft-azure", color: "#0288d1", bgColor: "#e1f5fe" },
      { name: "Google Cloud", icon: "mdi mdi-google-cloud", color: "#1e88e5", bgColor: "#e3f2fd" },
      { name: "Digital Ocean", icon: "mdi mdi-digital-ocean", color: "#0097a7", bgColor: "#e0f7fa" },
    ]
  },
  {
    category: "Databases & APIs",
    items: [
      { name: "MySQL", icon: "mdi mdi-database", color: "#e65100", bgColor: "#fff3e0" },
      { name: "MongoDB", icon: "mdi mdi-leaf", color: "#2e7d32", bgColor: "#e8f5e9" },
      { name: "REST API", icon: "mdi mdi-api", color: "#c2185b", bgColor: "#fce4ec" },
      { name: "GraphQL", icon: "mdi mdi-graphql", color: "#7b1fa2", bgColor: "#f3e5f5" },
    ]
  },
  {
    category: "Enterprise Systems",
    items: [
      { name: "SAP", icon: "mdi mdi-database-check", color: "#0277bd", bgColor: "#e1f5fe" },
      { name: "Oracle", icon: "mdi mdi-oracle", color: "#d32f2f", bgColor: "#ffebee" },
      { name: "Salesforce", icon: "mdi mdi-cloud", color: "#0288d1", bgColor: "#e1f5fe" },
      { name: "Workday", icon: "mdi mdi-office-building", color: "#0097a7", bgColor: "#e0f7fa" },
    ]
  }
];

const DataSourcesGrid = () => {
  return (
    <div className="data-sources-container">
      <div className="mb-4">
        <h4 className="text-primary mb-3">Connect Your Data Sources</h4>
        <p className="text-muted">
          Select from over 200+ integrations to connect your data from various sources
        </p>
      </div>

      {dataSources.map((category, idx) => (
        <div key={idx} className="mb-4">
          <h5 className="mb-3 category-title">
            <i className="mdi mdi-folder-multiple-outline me-1"></i>
            {category.category}
          </h5>
          <Row>
            {category.items.map((item, i) => (
              <Col key={i} sm={6} md={4} lg={3} className="mb-3">
                <Card className="source-card h-100">
                  <Card.Body>
                    <div 
                      className="source-icon-wrapper mb-3"
                      style={{ backgroundColor: item.bgColor }}
                    >
                      <i 
                        className={`${item.icon} source-icon`}
                        style={{ color: item.color }}
                      ></i>
                    </div>
                    <h6 className="source-title mb-2">{item.name}</h6>
                    <button className="connect-btn">
                      <i className="mdi mdi-plus me-1"></i>
                      Connect
                    </button>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </div>
      ))}

      <style>{`
        .data-sources-container {
          padding: 1rem;
        }
        
        .category-title {
          color: #333;
          font-weight: 600;
          position: relative;
          padding-bottom: 8px;
          margin-bottom: 1.25rem;
        }
        
        .category-title:after {
          content: '';
          position: absolute;
          left: 0;
          bottom: 0;
          height: 2px;
          width: 40px;
          background: var(--bs-primary);
        }
        
        .source-card {
          transition: all 0.3s ease;
          border: none;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          min-height: 140px;
        }
        
        .source-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 8px 16px rgba(0,0,0,0.15);
        }
        
        .source-icon-wrapper {
          width: 40px;
          height: 40px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s ease;
        }
        
        .source-card:hover .source-icon-wrapper {
          transform: scale(1.1);
        }
        
        .source-icon {
          font-size: 20px;
        }
        
        .source-title {
          font-weight: 600;
          color: #333;
          font-size: 0.9rem;
          margin-bottom: 0.5rem;
        }
        
        .connect-btn {
          background: none;
          border: 1px solid var(--bs-primary);
          color: var(--bs-primary);
          padding: 4px 10px;
          font-size: 12px;
          border-radius: 4px;
          transition: all 0.2s ease;
          margin-top: auto;
        }
        
        .connect-btn:hover {
          background: var(--bs-primary);
          color: white;
        }
        
        .source-card .card-body {
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          padding: 1rem;
        }
      `}</style>
    </div>
  );
};

export default DataSourcesGrid; 