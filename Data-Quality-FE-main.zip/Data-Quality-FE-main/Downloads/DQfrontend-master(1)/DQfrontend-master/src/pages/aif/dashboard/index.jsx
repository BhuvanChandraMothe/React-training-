import React, { useEffect, useState } from "react";
import "./styles.css";
import AppSection from "./components/AppSection";
import { Row, Col, Button, Alert, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useAuthContext } from "../../../context/useAuthContext";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { get } from "../../../api/io";
import { useWorkspaceContext } from "../../../context/useWorkspaceContext";
import { getDashboardOverview } from "../../../api/dbapi";
import RadialGauge from "../../../components/RadialGauge ";
import RecentProfileRuns from "../../../components/RecentProfileRuns";
import DashboardView from "./components/Dashboard";
import { useStore } from "reactflow";

// Add animated welcome message component
const Dashboard = () => {
  const[data,setData]=useState('Last 30 days')
  const changeStatusGroup=(e)=>{
    setData(e)
  }
  return (
    <div className="mt-4">
       
        {/* <div className='row'> */}
         
<div className=' d-flex align-items-center'>
   <h4 className="header-title " style={{textWrap:'nowrap'}}> Data Quality Overview</h4>
   <div className="col-md-3 " style={{marginLeft:'10px'}}><select className="form-select my-1 ml-2 my-lg-0" onChange={e => changeStatusGroup(e.target.value)}>
                        <option defaultValue="">Select</option>
                        <option value="Last 30 days">Last 30 Days</option>
                        <option value="Last 7 days">Last 7 days</option>
                        <option value="Today">Today</option>
                      </select></div>
</div>
      {/* </div> */}
         <div className="animate-fade-in animate-delay-4">
 <DashboardView duration={data} />


        </div>
     
    </div>
  );
};

export default Dashboard;
