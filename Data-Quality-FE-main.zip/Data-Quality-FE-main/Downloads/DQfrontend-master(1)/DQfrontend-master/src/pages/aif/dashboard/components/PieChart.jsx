import React, { useMemo, useState, useRef, useEffect } from 'react';
import { Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend
} from 'chart.js';
import {
  Badge,
  Form,
  Pagination,
  Modal,
  Button
} from "react-bootstrap";
import { getTestTpeSummary, getTestResultsDetailed } from '../../../../api/dbapi';

ChartJS.register(ArcElement, Tooltip, Legend);

const PieCharts = ({ passed, failed, Warning }) => {
  const [detailedData, setDetailedData] = useState(null);
  const [detailedStatus, setDetailedStatus] = useState('');
  const [statusBySecondPi, setstatusBySecondPi] = useState('');
  const [logs, setLogs] = useState([]);
  const [filter, setFilter] = useState({ service: "", action: "", status: "", dateRange: "all" });
  const [sortConfig, setSortConfig] = useState({ key: "timestamp", direction: "desc" });
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
const handleCloseTableMenu = () => setShowTableMenu(false);
  // Refs for scrolling
  const secondPieRef = useRef(null);
  const tableRef = useRef(null);
  const firstPieRef = useRef(null);

  const getStatusBadge = (status) => {
    switch (status) {
      case "Passed":
        return <Badge bg="success">Success</Badge>;
      case "Failure":
        return <Badge bg="danger">Failure</Badge>;
      default:
        return <Badge bg="secondary">{status}</Badge>;
    }
  };

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      if (filter.service && log.service !== filter.service) return false;
      if (filter.action && log.action !== filter.action) return false;
      if (filter.status && log.status !== filter.status) return false;
      return true;
    });
  }, [logs, filter]);

  const sortedLogs = useMemo(() => {
    const sorted = [...filteredLogs];
    if (sortConfig.key) {
      sorted.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    }
    return sorted;
  }, [filteredLogs, sortConfig]);

  const handleSort = (key) => {
    setSortConfig((prev) => ({
      key,
      direction: prev.key === key && prev.direction === "asc" ? "desc" : "asc",
    }));
  };

  const pagedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedLogs.slice(start, start + pageSize);
  }, [sortedLogs, currentPage, pageSize]);

  const totalPages = Math.ceil(sortedLogs.length / pageSize);

  const renderPagination = () => (
    <div className="d-flex justify-content-between align-items-center mt-3">
      <div>
        <Form.Select
          className="d-inline-block me-2"
          style={{ width: "auto" }}
          value={pageSize}
          onChange={(e) => {
            setPageSize(Number(e.target.value));
            setCurrentPage(1);
          }}
        >
          <option value={10}>10 rows</option>
          <option value={25}>25 rows</option>
          <option value={50}>50 rows</option>
        </Form.Select>
        <span className="text-muted">
          Showing {Math.min(sortedLogs.length, (currentPage - 1) * pageSize + 1)} to{" "}
          {Math.min(sortedLogs.length, currentPage * pageSize)} of {sortedLogs.length} entries
        </span>
      </div>

      <Pagination className="mb-0">
        <Pagination.First onClick={() => setCurrentPage(1)} disabled={currentPage === 1} />
        <Pagination.Prev onClick={() => setCurrentPage((curr) => Math.max(curr - 1, 1))} disabled={currentPage === 1} />

        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          const pageNum = currentPage <= 3
            ? i + 1
            : currentPage >= totalPages - 2
              ? totalPages - 4 + i
              : currentPage - 2 + i;

          if (pageNum <= totalPages && pageNum > 0) {
            return (
              <Pagination.Item
                key={pageNum}
                active={pageNum === currentPage}
                onClick={() => setCurrentPage(pageNum)}
              >
                {pageNum}
              </Pagination.Item>
            );
          }
          return null;
        })}

        <Pagination.Next onClick={() => setCurrentPage((curr) => Math.min(curr + 1, totalPages))} disabled={currentPage === totalPages} />
        <Pagination.Last onClick={() => setCurrentPage(totalPages)} disabled={currentPage === totalPages} />
      </Pagination>
    </div>
  );
  const [showTableMenu, setShowTableMenu] = useState(false);


  const mainData = {
    labels: ['Passed', 'Failed', 'Warning'],
    datasets: [
      {
        data: [passed, failed, Warning],
        backgroundColor: ['#1abc9c', '#dc3545', '#6c757d'],
        borderColor: ['#fff', '#fff', '#fff'],
        borderWidth: 1
      }
    ]
  };

  const mainOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom'
      }
    },
    onHover: (event) => {
      event.native.target.style.cursor = 'pointer';
    },
    onClick: async (evt, elements) => {
      if (!elements.length) return;
      const chart = elements[0].element.$context.chart;
      const index = elements[0].index;
      const label = chart.data.labels[index];

      try {
        const res = await getTestTpeSummary(label);
        setDetailedStatus(label);
        setDetailedData(res);
        setLogs([]); // Clear previous logs

        // Scroll to second pie chart after setting data
        setTimeout(() => {
          if (secondPieRef.current) {
            secondPieRef.current.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      } catch (err) {
        console.error('Error fetching test type summary:', err);
      }
    }
  };

  const detailedPieData = detailedData
    ? {
        labels: Object.keys(detailedData),
        datasets: [
          {
            data: Object.values(detailedData),
            backgroundColor: [
              '#007bff', '#dc3545', '#ffc107', '#28a745', '#6f42c1',
              '#20c997', '#fd7e14', '#6610f2', '#e83e8c', '#6c757d', '#17a2b8', '#343a40'
            ],
            borderColor: '#fff',
            borderWidth: 1
          }
        ]
      }
    : null;

  const detailedOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom'
      }
    },
    onHover: (event) => {
      event.native.target.style.cursor = 'pointer';
    },
    onClick: async (evt, elements) => {
      if (!elements.length) return;
      const chart = elements[0].element.$context.chart;
      const index = elements[0].index;
      const label = chart.data.labels[index];

      try {
        const res = await getTestResultsDetailed(detailedStatus, label);
        setLogs(res);
        setstatusBySecondPi(label);
setShowTableMenu(true);  
        // Scroll to table after setting logs
        setTimeout(() => {
          if (tableRef.current) {
            tableRef.current.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      } catch (err) {
        console.error('Error fetching detailed table data:', err);
      }
    }
  };

  // Close second pie chart and scroll back to top
  const closeSecondPie = () => {
    setDetailedData(null);
    setDetailedStatus('');
    setLogs([]);
    setstatusBySecondPi('');
    setCurrentPage(1);

    setTimeout(() => {
      if (firstPieRef.current) {
        firstPieRef.current.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <>
      <div ref={firstPieRef} className="bg-white card p-3 rounded">
        <h4 className="text-black text-left">Test Status</h4>
        <div className="w-60 h-60 mx-auto">
          <Pie data={mainData} options={mainOptions} />
        </div>
      </div>

      {detailedData && (
        <div ref={secondPieRef} className="mt-2 card bg-white p-3 rounded position-relative">
             <Modal.Header closeButton onClick={closeSecondPie} className="custom-modal-header">
                      {/* <Modal.Title> */}
                      <h5>
                        Details for: {detailedStatus}
                        </h5>
                      {/* </Modal.Title> */}
                    </Modal.Header>
                    {/* <div className="w-80 h-80 mx-auto"> */}
                    <div style={{ height: '320px', width: '100%' }} className="mx-auto">
          <Pie data={detailedPieData} options={detailedOptions} />
          </div>
        </div>
      )}

      {/* {pagedLogs?.length > 0 && (
        <div ref={tableRef} className="mt-4 card bg-white p-3 rounded shadow-sm">
          <h6 className="mb-3">Detailed Data Table for: {statusBySecondPi}</h6>
          <div className="table-responsive">
            <table className="table table-striped table-sm">
              <thead className="text-muted small">
                <tr>
                  <th>Table Name</th>
                  <th>Column Name</th>
                  <th>Description</th>
                  <th>DQ Prevalence</th>
                  <th>DQ Record Score</th>
                  <th>Test Type</th>
                  <th>Test Suite ID</th>
                  <th>Severity</th>
                  <th>Result Status</th>
                  <th>Result Message</th>
                  <th>Test Time</th>
                </tr>
              </thead>
              <tbody>
                {pagedLogs.map((row, i) => (
                  <tr key={i}>
                    <td>{row.table_name}</td>
                    <td>{row.column_names}</td>
                    <td>{row.test_description}</td>
                    <td>{row.dq_prevalence}</td>
                    <td>{row.dq_record_ct}</td>
                    <td>{row.test_type}</td>
                    <td>{row.test_suite_id}</td>
                    <td>{row.severity}</td>
                    <td>{getStatusBadge(row.result_status)}</td>
                    <td>{row.result_message}</td>
                    <td>{new Date(row.test_time).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {renderPagination()}
          </div>
        </div>
      )} */}
     <Modal
  show={showTableMenu}
  onHide={handleCloseTableMenu}
  size="xl"
  centered
  scrollable
>
  <Modal.Header closeButton>
    <Modal.Title>Detailed Data Table for: {statusBySecondPi}</Modal.Title>
  </Modal.Header>
  <Modal.Body>
    {pagedLogs.length > 0 ? (
      <>
        <div className="table-responsive" style={{ maxHeight: '60vh', overflowY: 'auto' }}>
          <table className="table table-striped table-sm">
            <thead className="text-muted small">
              <tr>
                <th>Table Name</th>
                <th>Column Name</th>
                <th>Description</th>
                <th>DQ Prevalence</th>
                <th>DQ Record Score</th>
                <th>Test Type</th>
                <th>Test Suite ID</th>
                <th>Severity</th>
                <th>Result Status</th>
                <th>Result Message</th>
                <th>Test Time</th>
              </tr>
            </thead>
            <tbody>
              {pagedLogs.map((row, i) => (
                <tr key={i}>
                  <td>{row.table_name}</td>
                  <td>{row.column_names}</td>
                  <td>{row.test_description}</td>
                  <td>{row.dq_prevalence}</td>
                  <td>{row.dq_record_ct}</td>
                  <td>{row.test_type}</td>
                  <td>{row.test_suite_id}</td>
                  <td>{row.severity}</td>
                  <td>{getStatusBadge(row.result_status)}</td>
                  <td>{row.result_message}</td>
                  <td>{new Date(row.test_time).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {renderPagination()}
      </>
    ) : (
      <p>No detailed data available.</p>
    )}
  </Modal.Body>
</Modal>

    </>
  );
};

export default PieCharts;
