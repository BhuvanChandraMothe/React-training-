import { useNavigate } from "react-router-dom";
import { Card, Nav, Modal, Form, Button, Toast, ToastContainer } from "react-bootstrap";
import { useState, useEffect } from "react";
import axios from "axios";
import DocumentTable from "./DocumentTable";
// import { useAuthContext } from "../../../context/useAuthContext";
import DataSourcesGrid from "./DataSourcesGrid";

// Dataset Skeleton Loading Component
const DatasetSkeleton = () => {
  return (
    <div className="col-xl-3 col-md-6">
      <div 
        className="card folder-card h-100" 
        style={{ 
          opacity: 1,
          border: "1px solid #e2e6ea",
          boxShadow: "0 2px 8px rgba(0,0,0,0.08)"
        }}
      >
        <div className="card-body p-2">
          <div className="d-flex align-items-center mb-2">
            <div
              className="folder-icon me-2 p-2 rounded-circle"
              style={{ 
                width: 40, 
                height: 40, 
                backgroundColor: "#e9ecef",
                animation: "pulse 1.3s infinite ease-in-out" 
              }}
            ></div>
            <div className="flex-grow-1">
              <div 
                style={{ 
                  height: 18, 
                  width: '70%', 
                  borderRadius: 4, 
                  backgroundColor: "#dee2e6",
                  animation: "pulse 1.7s infinite ease-in-out" 
                }}
                className="mb-1"
              ></div>
              <div className="d-flex align-items-center">
                <div 
                  style={{ 
                    height: 16, 
                    width: 60, 
                    borderRadius: 4, 
                    backgroundColor: "#e2e6ea",
                    animation: "pulse 1.5s infinite ease-in-out" 
                  }}
                  className="me-2"
                ></div>
                <div 
                  style={{ 
                    height: 14, 
                    width: 80, 
                    borderRadius: 4, 
                    backgroundColor: "#e2e6ea",
                    animation: "pulse 1.8s infinite ease-in-out" 
                  }}
                ></div>
              </div>
            </div>
            <div className="dropdown">
              <div 
                style={{ 
                  height: 24, 
                  width: 24, 
                  borderRadius: 4, 
                  backgroundColor: "#e9ecef",
                  animation: "pulse 1.4s infinite ease-in-out" 
                }}
              ></div>
            </div>
          </div>
          <div className="mt-3">
            <div 
              style={{ 
                height: 16, 
                width: '90%', 
                borderRadius: 4, 
                backgroundColor: "#dee2e6",
                animation: "pulse 1.9s infinite ease-in-out" 
              }}
              className="mb-2"
            ></div>
            <div 
              style={{ 
                height: 16, 
                width: '80%', 
                borderRadius: 4, 
                backgroundColor: "#dee2e6",
                animation: "pulse 1.6s infinite ease-in-out" 
              }}
              className="mb-2"
            ></div>
            <div className="d-flex align-items-center">
              <div 
                style={{ 
                  height: 14, 
                  width: 14, 
                  borderRadius: 4, 
                  backgroundColor: "#e2e6ea",
                  animation: "pulse 1.3s infinite ease-in-out" 
                }}
                className="me-1"
              ></div>
              <div 
                style={{ 
                  height: 14, 
                  width: '60%', 
                  borderRadius: 4, 
                  backgroundColor: "#e2e6ea",
                  animation: "pulse 1.7s infinite ease-in-out" 
                }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Add CSS animation to head
const injectCss = () => {
  if (!document.getElementById('skeleton-animation-style')) {
    const style = document.createElement('style');
    style.id = 'skeleton-animation-style';
    style.innerHTML = `
      @keyframes pulse {
        0% { opacity: 0.5; }
        50% { opacity: 0.9; }
        100% { opacity: 0.5; }
      }
    `;
    document.head.appendChild(style);
  }
};

// left side panel
const LeftSide = ({ onFolderClick, activeFolder }) => {
  return (
    <div className="h-100 d-flex flex-column">
      <h5 className="p-3 mb-0">Documents list</h5>
      <div className="flex-grow-1" style={{ overflowY: "auto" }}>
        <Nav className="flex-column nav-pills p-3 pt-0">
          <Nav.Link
            className={`mb-2 ${activeFolder === "documents" ? "active" : ""}`}
            onClick={() => onFolderClick("documents")}
          >
            <i className="mdi mdi-file-document me-2"></i>
            Documents
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${
              activeFolder === "data-sources" ? "active" : ""
            }`}
            onClick={() => onFolderClick("data-sources")}
          >
            <i className="mdi mdi-source-pull me-2"></i>
            Data Sources
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeFolder === "logs" ? "active" : ""}`}
            onClick={() => onFolderClick("logs")}
          >
            <i className="mdi mdi-golf me-2"></i>
            Destinations
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeFolder === "monitoring" ? "active" : ""}`}
            onClick={() => onFolderClick("monitoring")}
          >
            <i className="mdi mdi-hook me-2"></i>
            Triggers/Hooks
          </Nav.Link>
          <Nav.Link
            className={`mb-2 ${activeFolder === "settings" ? "active" : ""}`}
            onClick={() => onFolderClick("settings")}
          >
            <i className="mdi mdi-timeline-check-outline me-2"></i>
            Pipelines
          </Nav.Link>

          <div className="border-top my-3"></div>

          <Nav.Link to="#" className="list-group-item border-0">
            <i className="mdi mdi-share-variant font-18 align-middle me-2"></i>
            Share with me
          </Nav.Link>
          <Nav.Link to="#" className="list-group-item border-0">
            <i className="mdi mdi-clock-outline font-18 align-middle me-2"></i>
            Recent
          </Nav.Link>
          <Nav.Link to="#" className="list-group-item border-0">
            <i className="mdi mdi-star-outline font-18 align-middle me-2"></i>
            Starred
          </Nav.Link>
          <Nav.Link to="#" className="list-group-item border-0">
            <i className="mdi mdi-delete font-18 align-middle me-2"></i>
            Deleted Files
          </Nav.Link>
        </Nav>
      </div>
    </div>
  );
};

const AddDocumentModal = ({ show, onHide, selectedDataset, refreshDocuments }) => {
  const [documentName, setDocumentName] = useState("");
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [toast, setToast] = useState({
    show: false,
    message: "",
    type: "success" // success or danger
  });
  // const { user } = useAuthContext();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsUploading(true);

    const formData = new FormData();
    formData.append("name", documentName);
    formData.append("dataset_id", selectedDataset);
    formData.append("file", file);

    try {
      const response = await fetch("/api/documents/", {
        method: "POST",
        // headers: {
        //   Authorization: `Bearer ${user?.access_token}`,
        // },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      // Clear form fields
      setDocumentName("");
      setFile(null);
      
      // Show success toast
      setToast({
        show: true,
        message: "Document uploaded successfully!",
        type: "success"
      });
      
      // Close the modal
      onHide();
      
      // Refresh the documents list
      refreshDocuments();
    } catch (error) {
      console.error("Error uploading document:", error);
      
      // Show error toast
      setToast({
        show: true,
        message: `Failed to upload document: ${error.message}`,
        type: "danger"
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <>
      <Modal show={show} onHide={onHide} centered className="add-document-modal">
        <Modal.Header closeButton>
          <Modal.Title>Add New Document</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-4">
              <Form.Label>Document Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter document name"
                value={documentName}
                onChange={(e) => setDocumentName(e.target.value)}
                required
                className="rounded"
                disabled={isUploading}
              />
            </Form.Group>
            <Form.Group className="mb-4">
              <Form.Label>Upload Document</Form.Label>
              <div className="upload-box p-4 rounded-3 text-center border-2 border-dashed">
                <i className="mdi mdi-cloud-upload font-24 mb-2"></i>
                <p className="mb-2">Drag and drop your file here or</p>
                <Form.Control
                  type="file"
                  onChange={(e) => setFile(e.target.files[0])}
                  required
                  className="d-none"
                  id="fileUpload"
                  disabled={isUploading}
                />
                <Button
                  variant="primary"
                  className="rounded-pill px-4"
                  onClick={() => document.getElementById("fileUpload").click()}
                  disabled={isUploading}
                >
                  Browse Files
                </Button>
                {file && (
                  <p className="mt-2 text-success">Selected: {file.name}</p>
                )}
              </div>
            </Form.Group>
            <div className="text-end mt-4">
              <Button
                variant="secondary"
                onClick={onHide}
                className="me-2 rounded"
                disabled={isUploading}
              >
                Cancel
              </Button>
              <Button 
                variant="primary" 
                type="submit" 
                className="rounded"
                disabled={isUploading}
              >
                {isUploading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                    Uploading...
                  </>
                ) : (
                  'Upload Document'
                )}
              </Button>
            </div>
          </Form>
        </Modal.Body>
      </Modal>

      <ToastContainer position="top-end" className="p-3">
        <Toast 
          onClose={() => setToast({...toast, show: false})} 
          show={toast.show} 
          delay={3000} 
          autohide 
          bg={toast.type}
        >
          <Toast.Header>
            <strong className="me-auto">
              {toast.type === "success" ? "Success" : "Error"}
            </strong>
          </Toast.Header>
          <Toast.Body className={toast.type === "success" ? "" : "text-white"}>
            {toast.message}
          </Toast.Body>
        </Toast>
      </ToastContainer>
    </>
  );
};

const FileManager = () => {
  const [activeFolder, setActiveFolder] = useState("documents");
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [showFolderView, setShowFolderView] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [documentsLoading, setDocumentsLoading] = useState(false);
  const [kbSearchTerm, setKbSearchTerm] = useState("");
  const [documentSearchTerm, setDocumentSearchTerm] = useState("");
  const [toast, setToast] = useState({
    show: false,
    message: "",
    type: "success" // success or danger
  });
  const navigate = useNavigate();

  // Inject CSS for skeleton loading animation
  useEffect(() => {
    injectCss();
  }, []);

  const handleCreateKB = () => {
    navigate("/datasets/config");
  };

  const handleFolderClick = (folder) => {
    setActiveFolder(folder);
    // if (folder === "documents") {
    //   setShowFolderView(true);
    // }
  };

  const [documentsData, setDocumentsData] = useState([]);
  const [dataSets, setDataSets] = useState([]);
  // const { user } = useAuthContext();

  useEffect(() => {
    setIsLoading(true);
    fetch("/api/datasets/", {
      headers: {
        Accept: "application/json",
        // Authorization: `Bearer ${user?.access_token}`,
      },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        // Transform API data to match our UI structure
        const transformedData = {
          Contracts: data.map((dataset) => ({
            docName: dataset.name,
            status: dataset.permission === "only_me" ? "private" : "shared",
            summary: dataset.description,
            createdBy: dataset.tenant_id,
            updatedBy: dataset.tenant_id,
            createdOn: dataset.created_at,
            updatedOn: dataset.updated_at,
            documentCount: dataset.document_count,
            wordCount: dataset.word_count,
            id: dataset.id,
          })),
        };
        setDataSets(data);
        setIsLoading(false);
      })
      .catch((err) => {
        console.error("Error:", err.message);
        setDataSets([]);
        setIsLoading(false);
      });
  }, []);

  useEffect(() => {
    if (selectedFolder) {
      getDocumentsByKB();
    }
  }, [selectedFolder]);

  // console.log(selectedFolder);
  const getDocumentsByKB = () => {
    if (!selectedFolder) return;
    
    setDocumentsLoading(true);
    fetch(`/api/documents/?dataset_id=${selectedFolder}`, {
      headers: {
        Accept: "application/json",
        // Authorization: `Bearer ${user?.access_token}`,
      },
    })
      .then((response) => {
        // console.log("Response status:", response.status);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        // console.log("Responsessss data:", data);
        setDocumentsData(data);
        setDocumentsLoading(false);
      })
      .catch((err) => {
        console.error("Error:", err.message);
        setDocumentsData([]);
        setDocumentsLoading(false);
        
        // Show error toast
        setToast({
          show: true,
          message: `Failed to load documents: ${err.message}`,
          type: "danger"
        });
      });
  };

  const handleAddDocument = () => {
    axios
      .post(
        "/api/documents/",
        {
          name: "New Dataset",
          description: "Description",
          permission: "only_me",
        },
        {
          headers: {
            Accept: "application/json",
            // Authorization: `Bearer ${user?.access_token}`,
          },
        }
      )
      .then((response) => {
        // console.log("Response data:", response.data);
        // Handle success
      })
      .catch((err) => {
        console.error("Error:", err.message);
      });
  };

  // Get the name of the selected dataset
  const getSelectedDatasetName = () => {
    if (!selectedFolder) return "";
    const selectedDataset = dataSets.find(dataset => dataset.id === selectedFolder);
    return selectedDataset ? selectedDataset.name : "";
  };

  // Filter knowledge bases based on search term
  const filteredDataSets = dataSets.filter(dataset => {
    if (!kbSearchTerm.trim()) return true;
    
    const searchTermLower = kbSearchTerm.toLowerCase();
    return (
      (dataset.name && dataset.name.toLowerCase().includes(searchTermLower)) || 
      (dataset.description && dataset.description.toLowerCase().includes(searchTermLower))
    );
  });

  // Filter documents based on search term
  const filteredDocuments = documentsData.filter(doc => {
    if (!documentSearchTerm.trim()) return true;
    
    const searchTermLower = documentSearchTerm.toLowerCase();
    return (
      (doc.name && doc.name.toLowerCase().includes(searchTermLower)) || 
      (doc.doc_metadata?.original_filename && doc.doc_metadata.original_filename.toLowerCase().includes(searchTermLower)) ||
      (doc.doc_type && doc.doc_type.toLowerCase().includes(searchTermLower)) ||
      (doc.indexing_status && doc.indexing_status.toLowerCase().includes(searchTermLower))
    );
  });

  const renderContent = () => {
    if (activeFolder === "data-sources") {
      return (
        <div className="row">
          <div className="col-xl-3">
            <div className="card border-0 shadow-sm">
              <div className="card-body p-0">
                <LeftSide
                  onFolderClick={handleFolderClick}
                  activeFolder={selectedFolder}
                />
              </div>
            </div>
          </div>
          <div className="col-xl-9">
            <div className="card border-0 shadow-sm">
              <div className="card-body p-0">
                <DataSourcesGrid />
              </div>
            </div>
          </div>
        </div>
      );
    }
    if (showFolderView) {
      return (
        <div className="folders-page p-3">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <div>
              <h4 className="mb-1">Knowledge Bases</h4>
              <p className="text-muted mb-0">
                Manage and organize your knowledge base content
              </p>
            </div>
            <div className="d-flex align-items-center gap-2">
              <div className="position-relative">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search kb"
                  value={kbSearchTerm}
                  onChange={(e) => setKbSearchTerm(e.target.value)}
                />
                <span className="mdi mdi-magnify search-icon"></span>
                {kbSearchTerm && (
                  <button
                    className="btn btn-sm position-absolute end-0 top-0 me-1 mt-1"
                    onClick={() => setKbSearchTerm("")}
                    title="Clear search"
                  >
                    <i className="mdi mdi-close text-muted"></i>
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="row g-2">
            <div className="col-xl-3 col-md-6">
              <div
                className="card folder-card h-100 create-kb-card"
                onClick={handleCreateKB}
                style={{
                  cursor: "pointer",
                  transition: "transform 0.2s, box-shadow 0.2s",
                  border: "2px dashed #e9ecef",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-2px)";
                  e.currentTarget.style.boxShadow =
                    "0 .3rem 1rem rgba(0,0,0,.08)";
                  e.currentTarget.style.borderColor = "#556ee6";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "none";
                  e.currentTarget.style.boxShadow = "";
                  e.currentTarget.style.borderColor = "#e9ecef";
                }}
              >
                <div className="card-body d-flex flex-column align-items-center justify-content-center p-3">
                  <div className="create-icon mb-2">
                    <i className="mdi mdi-plus-circle font-32 text-primary"></i>
                  </div>
                  <h5 className="card-title mb-1">Create New</h5>
                  <p className="text-muted text-center mb-0">
                    Create a new knowledge base
                  </p>
                </div>
              </div>
            </div>

            {isLoading ? (
              // Show skeleton loaders when loading
              <>
                <DatasetSkeleton />
                <DatasetSkeleton />
                <DatasetSkeleton />
                <DatasetSkeleton />
                <DatasetSkeleton />
                <DatasetSkeleton />
                <DatasetSkeleton />
              </>
            ) : filteredDataSets.length > 0 ? (
              // Show filtered data when loaded and there are results
              filteredDataSets.map((dataset) => {
                const isPrivate = dataset.permission === "only_me";

                return (
                  <div key={dataset.id} className="col-xl-3 col-md-6">
                    <div
                      className="card folder-card h-100 shadow-sm"
                      onClick={() => {
                        setSelectedFolder(dataset.id);
                        setShowFolderView(false);
                      }}
                      style={{
                        cursor: "pointer",
                        transition: "transform 0.2s, box-shadow 0.2s",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = "translateY(-2px)";
                        e.currentTarget.style.boxShadow =
                          "0 .3rem 1rem rgba(0,0,0,.08)";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = "none";
                        e.currentTarget.style.boxShadow = "";
                      }}
                    >
                      <div className="card-body p-2">
                        <div className="d-flex align-items-center mb-2">
                          <div
                            className="folder-icon me-2 p-2 rounded-circle"
                            style={{ backgroundColor: "rgba(85, 110, 230, 0.1)" }}
                          >
                            <i className="mdi mdi-folder font-20 text-primary"></i>
                          </div>
                          <div className="flex-grow-1">
                            <h6 className="card-title mb-1 text-truncate">
                              {dataset.name}
                            </h6>
                            <div className="d-flex align-items-center">
                              <span
                                className={`badge ${
                                  isPrivate
                                    ? "bg-warning-subtle text-warning"
                                    : "bg-success-subtle text-success"
                                } me-2`}
                              >
                                {isPrivate ? "Private" : "Shared"}
                              </span>
                              <small className="text-muted">
                                {dataset.document_count || 0} Documents
                              </small>
                            </div>
                          </div>
                          <div className="dropdown">
                            <button
                              className="btn btn-link text-muted p-0"
                              type="button"
                              // onClick={(e) => e.stopPropagation()}
                              onClick={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                // navigate(`/datasets/config/${dataset.id}`);
                              }}
                              data-bs-toggle="dropdown"
                              aria-expanded="false"
                            >
                              <i className="mdi mdi-dots-vertical"></i>
                            </button>
                            <ul className="dropdown-menu dropdown-menu-end">
                              <li>
                                <button 
                                  className="dropdown-item" 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    navigate(`/datasets/config/${dataset.id}`);
                                  }}
                                >
                                  <i className="mdi mdi-pencil me-2"></i>Edit
                                </button>
                              </li>
                              <li>
                                <button className="dropdown-item">
                                  <i className="mdi mdi-share-variant me-2"></i>Share
                                </button>
                              </li>
                              <li>
                                <button className="dropdown-item">
                                  <i className="mdi mdi-delete me-2"></i>Delete
                                </button>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div className="mt-3">
                          <p className="text-muted mb-2">
                            {dataset.description || "No description"}
                          </p>
                          <div className="d-flex align-items-center text-muted small">
                            <i className="mdi mdi-clock-outline me-1"></i>
                            <span>
                              Created{" "}
                              {new Date(dataset.created_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              // Show no results message
              <div className="col-12 text-center py-5">
                <div className="empty-state">
                  <i className="mdi mdi-file-search-outline text-muted font-48"></i>
                  <h5 className="mt-3">No knowledge bases found</h5>
                  <p className="text-muted">
                    We couldn't find any knowledge bases matching "{kbSearchTerm}".
                  </p>
                  <button 
                    className="btn btn-light mt-3"
                    onClick={() => setKbSearchTerm("")}
                  >
                    Clear Search
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }

    return (
      <div className="detailed-view">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <div className="d-flex align-items-center">
            <button
              className="btn btn-light back-btn me-2"
              onClick={() => setShowFolderView(true)}
            >
              <div className="d-flex align-items-center">
                <div className="back-icon">
                  <i className="mdi mdi-arrow-left"></i>
                </div>
              </div>
            </button>
            <h4 className="mb-0 ms-2">{getSelectedDatasetName()}</h4>
          </div>
          <div className="d-flex align-items-center gap-2">
            <div className="position-relative">
              <input
                type="text"
                className="form-control"
                placeholder="Search documents..."
                value={documentSearchTerm}
                onChange={(e) => setDocumentSearchTerm(e.target.value)}
              />
              <span className="mdi mdi-magnify search-icon"></span>
              {documentSearchTerm && (
                <button
                  className="btn btn-sm position-absolute end-0 top-0 me-1 mt-1"
                  onClick={() => setDocumentSearchTerm("")}
                  title="Clear search"
                >
                  <i className="mdi mdi-close text-muted"></i>
                </button>
              )}
            </div>
            <div className="d-flex gap-2">
              <Button
                variant="primary"
                className="rounded px- me-2"
                onClick={() => setShowAddModal(true)}
              >
                <i className="mdi mdi-plus me-1"></i>
                Add Document
              </Button>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-xl-3">
            <div className="card border-0 shadow-sm">
              <div className="card-body p-0">
                <LeftSide
                  onFolderClick={handleFolderClick}
                  activeFolder="documents"
                />
              </div>
            </div>
          </div>
          <div className="col-xl-9">
            <div className="card border-0 shadow-sm">
              <div className="card-body p-0">
                <DocumentTable 
                  documents={filteredDocuments} 
                  loading={documentsLoading} 
                  refreshDocuments={getDocumentsByKB} 
                />
              </div>
            </div>
          </div>
        </div>
        <AddDocumentModal
          show={showAddModal}
          onHide={() => setShowAddModal(false)}
          selectedDataset={selectedFolder}
          refreshDocuments={getDocumentsByKB}
        />
      </div>
    );
  };

  return (
    <>
      <Card className="mt-3">{renderContent()}</Card>
      
      <ToastContainer position="top-end" className="p-3">
        <Toast 
          onClose={() => setToast({...toast, show: false})} 
          show={toast.show} 
          delay={3000} 
          autohide 
          bg={toast.type}
        >
          <Toast.Header>
            <strong className="me-auto">
              {toast.type === "success" ? "Success" : "Error"}
            </strong>
          </Toast.Header>
          <Toast.Body className={toast.type === "success" ? "" : "text-white"}>
            {toast.message}
          </Toast.Body>
        </Toast>
      </ToastContainer>
    </>
  );
};

export default FileManager;
