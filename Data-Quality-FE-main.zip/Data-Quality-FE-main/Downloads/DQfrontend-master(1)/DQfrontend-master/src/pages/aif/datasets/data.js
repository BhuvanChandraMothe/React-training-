export const documentsData = {
  Contracts: [
    {
      docName: "Service Agreement 2024",
      status: "active",
      summary: "Annual service agreement with vendor XYZ for cloud infrastructure",
      createdBy: "John Doe",
      updatedBy: "Jane Smith",
      createdOn: "2024-01-15T10:30:00",
      updatedOn: "2024-03-20T14:45:00",
    },
    {
      docName: "NDA Template",
      status: "draft",
      summary: "Standard non-disclosure agreement template for new clients",
      createdBy: "Jane Smith",
      updatedBy: "Jane Smith",
      createdOn: "2024-02-01T09:15:00",
      updatedOn: "2024-02-01T09:15:00",
    },
  ],
  NDA: [
    {
      docName: "Client NDA - ABC Corp",
      status: "pending",
      summary: "Non-disclosure agreement for project Alpha with ABC Corporation",
      createdBy: "Mike Johnson",
      updatedBy: "John Doe",
      createdOn: "2024-03-01T11:20:00",
      updatedOn: "2024-03-15T16:30:00",
    },
  ],
  Invoices: [
    {
      docName: "Invoice #2024-001",
      status: "active",
      summary: "Q1 2024 service invoice for client XYZ",
      createdBy: "Sarah Wilson",
      updatedBy: "Sarah Wilson",
      createdOn: "2024-01-05T08:00:00",
      updatedOn: "2024-01-05T08:00:00",
    },
  ],
  Salaries: [
    {
      docName: "Salary Report Q1 2024",
      status: "active",
      summary: "Quarterly salary report and analysis",
      createdBy: "HR Team",
      updatedBy: "Finance Team",
      createdOn: "2024-01-10T09:00:00",
      updatedOn: "2024-01-10T15:30:00",
    },
  ],
  "Annual Reports": [
    {
      docName: "Annual Report 2023",
      status: "active",
      summary: "Complete annual financial and business report",
      createdBy: "Finance Team",
      updatedBy: "CEO Office",
      createdOn: "2024-02-15T10:00:00",
      updatedOn: "2024-02-28T16:45:00",
    },
  ],
};

export const quickAccessFiles = [
  {
    name: "Contracts",
    icon: "mdi mdi-file-document-outline",
    count: 12,
    size: "140 MB",
  },
  {
    name: "NDA",
    icon: "mdi mdi-file-lock-outline",
    count: 8,
    size: "25 MB",
  },
  {
    name: "Invoices",
    icon: "mdi mdi-file-pdf-box",
    count: 24,
    size: "85 MB",
  },
  {
    name: "Salaries",
    icon: "mdi mdi-file-excel-outline",
    count: 5,
    size: "10 MB",
  },
  {
    name: "Annual Reports",
    icon: "mdi mdi-file-presentation-box",
    count: 3,
    size: "45 MB",
  },
];

export const recentFiles = [
  {
    name: "Q4 Financial Report.xlsx",
    modifiedBy: "John Doe",
    modifiedOn: "2024-03-20T14:45:00",
    size: "2.3 MB",
    type: "excel",
  },
  {
    name: "Project Proposal.docx",
    modifiedBy: "Jane Smith",
    modifiedOn: "2024-03-19T11:30:00",
    size: "1.8 MB",
    type: "word",
  },
  {
    name: "Client Presentation.pptx",
    modifiedBy: "Mike Johnson",
    modifiedOn: "2024-03-18T09:15:00",
    size: "5.2 MB",
    type: "powerpoint",
  },
]; 