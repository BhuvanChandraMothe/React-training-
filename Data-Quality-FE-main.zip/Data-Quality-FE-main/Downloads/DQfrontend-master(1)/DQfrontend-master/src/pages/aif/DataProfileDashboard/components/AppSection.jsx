import React from "react";
import { Row, Col, Button, InputGroup, Form } from "react-bootstrap";
import AppCard from "./AppCard";
import { useNavigate } from "react-router-dom";

const AppSection = ({
  title,
  apps,
  buttonText,
  buttonIcon,
  isTemplate = false,
  onAppDelete,
  searchQuery = "",
  onSearch = null,
  hideCreateCard = false,
  renderSearchComponent = null,
}) => {
  const navigate = useNavigate();

  const handleAppDelete = (id) => {
    if (onAppDelete) {
      onAppDelete(id);
    }
  };

  const handleSearchChange = (e) => {
    if (onSearch) {
      onSearch(e.target.value);
    }
  };

  return (
    <div className="mb-4">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h4 className="text-primary m-0 section-header">{title}</h4>
          <p className="text-muted small mb-0 mt-1">
            {isTemplate
              ? "Start with these pre-built templates to quickly create your own AI applications"
              : "Manage and access your AI-powered applications"}
          </p>
        </div>
        {onSearch ? (
          renderSearchComponent ? (
            renderSearchComponent()
          ) : (
            <div className="search-compact" style={{ maxWidth: "200px" }}>
              <InputGroup size="sm">
                <Form.Control
                  type="text"
                  placeholder="Search apps..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  className="border-right-0"
                />
                <InputGroup.Text className="bg-white">
                  <i className="mdi mdi-magnify"></i>
                </InputGroup.Text>
              </InputGroup>
            </div>
          )
        ) : (
          <Button
            variant="soft-primary"
            size="sm"
            className="rounded-pill px-3 d-flex align-items-center"
          >
            <span>{buttonText}</span>
            <i className={`${buttonIcon} ms-1`}></i>
          </Button>
        )}
      </div>
      <Row className="g-3">
        {title === "Active Apps" && !hideCreateCard && (
          <Col key={1} sm={6} lg={4} xl={3}>
            <div
              className="card folder-card h-100 create-kb-card"
              onClick={() => navigate("/create-app")}
              style={{
                cursor: "pointer",
                transition: "transform 0.2s, box-shadow 0.2s",
                border: "2px dashed rgb(143, 157, 247)",
                backgroundColor: "#ffffff",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow =
                  "0 .3rem 1rem rgba(0,0,0,.08)";
                e.currentTarget.style.borderColor = "#556ee6";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.boxShadow = "";
                e.currentTarget.style.borderColor = "#e9ecef";
              }}
            >
              <div className="card-body d-flex flex-column align-items-center justify-content-center p-3">
                <div className="create-icon mb-2">
                  <i className="mdi mdi-plus-circle font-32 text-primary"></i>
                </div>
                <h5 className="card-title mb-1">Create</h5>
                <p className="text-muted text-center mb-0">new app</p>
              </div>
            </div>
          </Col>
        )}
        {apps?.map((app, idx) => (
          <Col key={idx} sm={6} lg={4} xl={3}>
            <AppCard
              {...app}
              mode={app?.mode}
              isTemplate={isTemplate}
              onDelete={handleAppDelete}
              searchQuery={searchQuery}
            />
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default AppSection;
