import React from 'react';
import { Button } from 'react-bootstrap';

const SearchBar = () => {
  return (
    <div className="d-md-flex justify-content-between align-items-center mb-3">
      <form className="search-bar">
        <div className="position-relative">
          <input
            type="text"
            className="form-control form-control-light"
            placeholder="Search files..."
          />
          <span className="mdi mdi-magnify"></span>
        </div>
      </form>
      <div className="mt-2 mt-md-0">
        <Button variant="white" size="sm" className="me-1">
          <i className="mdi mdi-format-list-bulleted"></i>
        </Button>
        <Button variant="white" size="sm" className="me-1">
          <i className="mdi mdi-view-grid"></i>
        </Button>
        <Button variant="white" size="sm" className="me-1">
          <i className="mdi mdi-information-outline"></i>
        </Button>
      </div>
    </div>
  );
};

export default SearchBar; 