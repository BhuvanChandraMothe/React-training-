import React, { useState, useEffect, useMemo } from "react";
import {
    Card,
    Row,
    Col,
    Badge,
    Button,
    Form,
    InputGroup,
    Table,
    Pagination,
    Modal,
} from "react-bootstrap";
// import { useAuthContext } from "../../../context/useAuthContext";
import PageTitle from "../../../components/PageTitle";
import {
    getSchedules, postSchedules, deleteSchedule,
    updateSchedule,
    getTableGroup,
    getAnomaly,
    fetchTestSuites
} from "../../../api/dbapi";
import "../Logs/logs.css";
import { useToaster } from "../../../Toaster/Toaster";
 
const Anomaly = () => {
  const [data,setData]=useState([])
    const { showToast } = useToaster();
    const [testStatus, setTestStatus] = useState(null);
    const [openModel, setModelOpen] = useState(false);
    const [openTableGroup, setOpenTableGroupData] = useState(false);
    // const { user } = useAuthContext();
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [expandedLogId, setExpandedLogId] = useState(null);
    const [filter, setFilter] = useState({
        service: "",
        action: "",
        status: "",
        dateRange: "all",
    });
    const openDatabasePopup = () => {
        setModelOpen(true)
        setFormData({})
    }
    const [tableGroup,setTableGroup]=useState([])
    const [formData, setFormData] = useState({
       test_suite: "",
       test_suite_description: "",
       severity: "",
       table_groups_id: "",
     });
 
    const [formErrors, setFormErrors] = useState({});
    const [currentPage, setCurrentPage] = useState(1);
      const [pageSize, setPageSize] = useState(10);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        setFormErrors((prev) => ({ ...prev, [name]: "" }));
    };
    
 const handleSubmit = async () => {
    setIsSubmitting(true);
    setTestStatus(null);
     let errors = {};
    if (!formData.table_groups_id) {
        errors.table_groups_id = "Table group is required.";
    }

    if (formData.group_by_tables === "true" && formData.group_by_profile_runs === "true") {
        errors.grouping = "Only one of 'Group by Tables' or 'Group by Profile Runs' can be true.";
    }

    if (Object.keys(errors).length > 0) {
        setFormErrors(errors);
        // showToast("Please fix the validation errors.", "error");
        setIsSubmitting(false);
        return;
    }
    try {
        setLoading(true);
        const savePayload = {
            conn_id: formData.conn_id,
            group_id: formData.group_id,
            cron_expression: formData.schedule_cron_expression
        };
        // console.log("save Schedule with payload:", savePayload);

        try {
            const response = await getAnomaly(
                formData.table_groups_id,
                formData?.group_by_profile_runs,
                formData?.group_by_tables
            );

            // Normalize response
            let flattenedData = [];

            if (response.anomaly_results_by_run) {
                Object.values(response.anomaly_results_by_run).forEach(runEntry => {
                    Object.values(runEntry).forEach(tableEntries => {
                        flattenedData.push(...tableEntries);
                    });
                });
            }

            if (response.anomaly_results_by_table) {
                Object.values(response.anomaly_results_by_table).forEach(tableEntries => {
                    flattenedData.push(...tableEntries);
                });
            }

            // console.log("Anomalies Flattened:", flattenedData);
            setData(flattenedData); // This is the normalized array
            showToast("Anomaly fetched successfully!", "success");
        } catch (error) {
            console.error("Update failed:", error);
            showToast("Failed.", "error");
            return;
        }

        setModelOpen(false);
        fetchConnections();
        setFormData({
            conn_id: "",
            group_id: "",
            schedule_cron_expression: "",
        });
    } catch (error) {
        const errorMessage = error.message || "Something went wrong.";
        showToast(errorMessage, "error");
    } finally {
        setIsSubmitting(false);
        setLoading(false);
    }
};

const handleGroupByChange = (e, field) => {
  const value = e.target.value === "true"; // Convert string to boolean
  let updatedData = { ...formData, [field]: value };

  // Enforce the rule: Only one can be true or both false
  if (value === true) {
    if (field === 'group_by_profile_runs') {
      updatedData.group_by_tables = false;
    } else if (field === 'group_by_tables') {
      updatedData.group_by_profile_runs = false;
    }
  }

  setFormData(updatedData);
};

 
    const handleModalClose = () => {
        setModelOpen(false);
        setFormErrors({});
    };
    const [searchQuery, setSearchQuery] = useState("");
    const [sortConfig, setSortConfig] = useState({
        key: "timestamp",
        direction: "desc",
    });
     useEffect(() => {
        fetchConnections();
        fetchTableData()
      }, []);
       const fetchTableData = async () => {
        try {
          setLoading(true);
          const data = await getTableGroup();
          setTableGroup(data);
          setLoading(false);
        } catch (error) {
          setLoading(false);
          console.error("Error fetching connections:", error);
        }
      };
      const fetchConnections = async () => {
        try {
          setLoading(true);
          const data = await fetchTestSuites();
          setLogs(data);
          setLoading(false);
        } catch (error) {
          setLoading(false);
          console.error("Error fetching connections:", error);
        }
      };
    // Filter and search logs
    const filteredLogs = useMemo(() => {
        return logs.filter((log) => {
            // Apply filters
            if (filter.service && log.service !== filter.service) return false;
            if (filter.action && log.action !== filter.action) return false;
            if (filter.status && log.status !== filter.status) return false;
            return true;
        });
    }, [logs, filter, searchQuery]);
    const [deleteDialogOpen, setDeleteDialogOpen] = React.useState(false); // State for delete confirmation dialog
    const onEdit = (data) => {
        setFormData(data);
        setModelOpen(true);
    };
    const addTableGroup = (data) => {
        setFormData(data);
        setOpenTableGroupData(true);
    };
    const handleCloseModal = () => setDeleteDialogOpen(false);  
    const handleCloseModals = () => setOpenTableGroupData(false);
    const handleDelete = async (data) => {
        try {
            await deleteSchedule(data?.scheduled_job_id, 'delete_permanent'); // or 'deactivate'
            alert('Schedule deleted successfully!');
            fetchConnections()
        } catch (error) {
            alert('Failed to delete schedule.');
        }
    };
        // Handle sorting
    const handleSort = (key) => {
        setSortConfig((prevSortConfig) => ({
            key,
            direction:
                prevSortConfig.key === key && prevSortConfig.direction === "asc"
                    ? "desc"
                    : "asc",
        }));
    };
    const getSortIndicator = (key) => {
        if (sortConfig.key !== key) return null;
        return sortConfig.direction === "asc" ? "↑" : "↓";
    };
    // Apply sorting
      const sortedLogs = useMemo(() => {
        const sorted = [...filteredLogs];
        if (sortConfig.key) {
          sorted.sort((a, b) => {
            if (a[sortConfig.key] < b[sortConfig.key]) {
              return sortConfig.direction === "asc" ? -1 : 1;
            }
            if (a[sortConfig.key] > b[sortConfig.key]) {
              return sortConfig.direction === "asc" ? 1 : -1;
            }
            return 0;
          });
        }
        return sorted;
      }, [filteredLogs, sortConfig]);
    // Paged logs
      const pagedLogs = useMemo(() => {
        const start = (currentPage - 1) * pageSize;
        return sortedLogs.slice(start, start + pageSize);
      }, [sortedLogs, currentPage, pageSize]);
 
    return (
        <>
            <PageTitle
                breadCrumbItems={[
                    { label: "Dashboard", path: "/aif/dashboard" },
                    { label: "Anomaly", path: "/aif/logs", active: true },
                ]}
                title={"Anomaly"}
            />
 
            <Row>
                <Col>
                    <Card>
                        <Card.Body>
                            {/* <h4 className="header-title">Anomaly</h4> */}
 
                     <Row className="mb-3 align-items-end mt-2">
  {/* Search Input */}
  <Col md={3}>
    <InputGroup>
      <InputGroup.Text>
        <i className="mdi mdi-magnify"></i>
      </InputGroup.Text>
      <Form.Control
        placeholder="Search Anomaly..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
    </InputGroup>
  </Col>

  {/* Table Group */}
  <Col md={3}>
    <Form.Group className="mb-0">
      <Form.Label className="mb-1">Table Group</Form.Label>
      <Form.Select
        name="table_groups_id"
        value={formData.table_groups_id}
        onChange={handleInputChange}
           isInvalid={!!formErrors.table_groups_id}
      >
        <option value="" disabled>Select Group</option>
        {tableGroup.map((type) => (
          <option key={type.id} value={type.id}>
            {type.table_groups_name}
          </option>
        ))}
      </Form.Select>
       <Form.Control.Feedback type="invalid" className="text-danger">
    {formErrors.table_groups_id}
  </Form.Control.Feedback>
    </Form.Group>
  </Col>

  {/* Group by Tables */}
  <Col md={2}>
    <Form.Group className="mb-0">
      <Form.Label className="mb-1">Group by Tables</Form.Label>
      <Form.Select
        name="group_by_tables"
        value={formData.group_by_tables}
        onChange={(e) => handleGroupByChange(e, "group_by_tables")}
      >
        <option value="false">False</option>
        <option value="true">True</option>
      </Form.Select>
    </Form.Group>
  </Col>

  {/* Group by Profile Runs */}
  <Col md={2}>
    <Form.Group className="mb-0">
      <Form.Label className="mb-1">Group by Profile Runs</Form.Label>
      <Form.Select
        name="group_by_profile_runs"
        value={formData.group_by_profile_runs}
        onChange={(e) => handleGroupByChange(e, "group_by_profile_runs")}
      >
        <option value="false">False</option>
        <option value="true">True</option>
      </Form.Select>
    </Form.Group>
  </Col>

  {/* Submit Button */}
  <Col md={2}>
    <div className="d-flex justify-content-end">
      <Button
        variant="primary"
        onClick={handleSubmit}
        disabled={isSubmitting}
      >
         View Anomalies
      </Button>
    </div>
  </Col>
</Row>

                           
                                <>
                                    {!data ? (
                                        <div className="text-center py-5">
                                            <i
                                                className="mdi mdi-file-search text-muted"
                                                style={{ fontSize: "3rem" }}
                                            ></i>
                                            <h5 className="mt-3">No anamoly found</h5>
                                            <p className="text-muted">
                                                Try adjusting your search or filter criteria
                                            </p>
                                        </div>
                                    ) : (
                                        <>
                                           
                                          <div className="table-responsive">
  <Table striped hover>
    <thead>
      <tr>
        <th className="sortable" onClick={() => handleSort("id")} style={{ cursor: "pointer" }}>
          Anomaly Name {getSortIndicator("anomaly_name")}
        </th>
        <th className="sortable" onClick={() => handleSort("id")} style={{ cursor: "pointer" }}>
          Anomaly Description {getSortIndicator("anomaly_desc")}
        </th>
         <th className="sortable" onClick={() => handleSort("id")} style={{ cursor: "pointer" }}>
          Suggested Action {getSortIndicator("suggested_action")}
        </th>
        <th className="sortable" onClick={() => handleSort("id")} style={{ cursor: "pointer" }}>
          Issue likelihood {getSortIndicator("issue_likelihood")}
        </th>
        
        
        <th className="sortable" onClick={() => handleSort("table_name")} style={{ cursor: "pointer" }}>
          Table Name {getSortIndicator("table_name")}
        </th>
        <th className="sortable" onClick={() => handleSort("column_name")} style={{ cursor: "pointer" }}>
          Column Name {getSortIndicator("column_name")}
        </th>
        <th className="sortable" onClick={() => handleSort("detail")} style={{ cursor: "pointer" }}>
          Detail {getSortIndicator("detail")}
        </th>
        <th className="sortable" onClick={() => handleSort("profiling_starttime")} style={{ cursor: "pointer" }}>
          Profile Run Time{getSortIndicator("profiling_starttime")}
        </th>
        <th className="sortable" onClick={() => handleSort("dq_prevalence")} style={{ cursor: "pointer" }}>
          DQ Prevalence {getSortIndicator("dq_prevalence")}
        </th>
      </tr>
    </thead>
    <tbody>
      {Array.isArray(data) && data.length > 0 ? (
        data.map((item) => (
          <tr key={item.id}>
            <td>{item.anomaly_name}</td>
            <td>{item?.anomaly_description}</td>
            <td>{item?.suggested_action}</td>
            <td>{item?.issue_likelihood}</td>
            <td>{item.table_name}</td>
            <td>{item.column_name}</td>
            <td>{item.detail}</td>
            <td>{item.profiling_starttime}</td>
            <td>{item.dq_prevalence !== null ? item.dq_prevalence : "N/A"}</td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="9" className="text-center">Select the table group to view anomalies.</td>
        </tr>
      )}
    </tbody>
  </Table>
</div>

 
                                            {/* {renderPagination()} */}
                                        </>
                                    )}
                                </>
                            {/* )} */}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
          <Modal show={openModel} onHide={handleModalClose} centered>
  <Modal.Header closeButton>
    <Modal.Title>
      {formData?.conn_id ? "" : "View Anomalies"}
    </Modal.Title>
  </Modal.Header>

  <Modal.Body>
    <Form>
      <Row>
        <Col md={12}>
          <Form.Group className="mb-2">
            <Form.Label>Table Group</Form.Label>
            <Form.Select
              name="table_groups_id"
              value={formData.table_groups_id}
              onChange={handleInputChange}
            >
              <option value="" disabled>
                Select Database Type
              </option>
              {tableGroup.map((type) => (
                <option key={type?.id} value={type?.id}>
                  {type?.table_groups_name}
                </option>
              ))}
            </Form.Select>
          </Form.Group>
        </Col>
   <Col md={12}>
          <Form.Group className="mb-2">
            <Form.Label>Group by Tables</Form.Label>
            <Form.Select
              name="group_by_tables"
              value={formData.group_by_tables}
              onChange={(e) => handleGroupByChange(e, 'group_by_tables')}
            >
              <option value="false">False</option>
              <option value="true">True</option>
            </Form.Select>
          </Form.Group>
        </Col>
        {/* group_by_profile_runs */}
        <Col md={12}>
          <Form.Group className="mb-2">
            <Form.Label>Group by Profile Runs</Form.Label>
            <Form.Select
              name="group_by_profile_runs"
              value={formData.group_by_profile_runs}
              onChange={(e) => handleGroupByChange(e, 'group_by_profile_runs')}
            >
              <option value="false">False</option>
              <option value="true">True</option>
            </Form.Select>
          </Form.Group>
        </Col>

        {/* group_by_tables */}
     
      </Row>
    </Form>
  </Modal.Body>

  <Modal.Footer>
    <Button variant="secondary" onClick={handleModalClose}>
      Cancel
    </Button>
    <Button variant="primary" onClick={() => handleSubmit()} disabled={isSubmitting}>
      {formData?.conn_id ? "Update" : "Submit"}
    </Button>
  </Modal.Footer>
</Modal>

           
        </>
    );
};
 
export default Anomaly;
 
 