import React from "react";
import { Nav } from "react-bootstrap";

const Sidebar = ({ onFolderClick, activeFolder }) => {
  return (
    <>
      <div className="h-100 d-flex flex-column">
        <h5 className="p-3 mb-0">Documents list</h5>
        <div className="flex-grow-1" style={{ overflowY: "auto" }}>
          <Nav className="flex-column nav-pills p-3 pt-0">
            <Nav.Link
              className={`mb-2 ${activeFolder === "design" ? "active" : ""}`}
              onClick={() => onFolderClick("design")}
            >
              <i className="mdi mdi-file-document me-2"></i>
              Documents
            </Nav.Link>
            <Nav.Link
              className={`mb-2 ${
                activeFolder === "data-sources" ? "active" : ""
              }`}
              onClick={() => onFolderClick("data-sources")}
            >
              <i className="mdi mdi-source-pull me-2"></i>
              Data Sources
            </Nav.Link>
            <Nav.Link
              className={`mb-2 ${activeFolder === "logs" ? "active" : ""}`}
              onClick={() => onFolderClick("logs")}
            >
              <i className="mdi mdi-golf me-2"></i>
              Destinations
            </Nav.Link>
            <Nav.Link
              className={`mb-2 ${
                activeFolder === "monitoring" ? "active" : ""
              }`}
              onClick={() => onFolderClick("monitoring")}
            >
              <i className="mdi mdi-hook me-2"></i>
              Triggers/Hooks
            </Nav.Link>
            <Nav.Link
              className={`mb-2 ${activeFolder === "settings" ? "active" : ""}`}
              onClick={() => onFolderClick("settings")}
            >
              <i className="mdi mdi-timeline-check-outline me-2"></i>
              Pipelines
            </Nav.Link>

            <div className="border-top my-3"></div>

            <Nav.Link to="#" className="list-group-item border-0">
              <i className="mdi mdi-share-variant font-18 align-middle me-2"></i>
              Share with me
            </Nav.Link>
            <Nav.Link to="#" className="list-group-item border-0">
              <i className="mdi mdi-clock-outline font-18 align-middle me-2"></i>
              Recent
            </Nav.Link>
            <Nav.Link to="#" className="list-group-item border-0">
              <i className="mdi mdi-star-outline font-18 align-middle me-2"></i>
              Starred
            </Nav.Link>
            <Nav.Link to="#" className="list-group-item border-0">
              <i className="mdi mdi-delete font-18 align-middle me-2"></i>
              Deleted Files
            </Nav.Link>
          </Nav>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
