import React, { createContext, useContext, useState, useEffect } from 'react';
import { get } from '../api/io';
import { useNavigate } from 'react-router-dom';
// import { useAuthContext } from './useAuthContext';
const WorkspaceContext = createContext();

export const WorkspaceProvider = ({ children }) => {
  const navigate = useNavigate();
  const [currentWorkspace, setCurrentWorkspace] = useState(null);
  const [workspaces, setWorkspaces] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [workspaceChangeCount, setWorkspaceChangeCount] = useState(0);

  // useEffect(() => {
  //   fetchWorkspaces();
  // }, []);

  const fetchWorkspaces = async () => {
    setIsLoading(true);
    try {
      const data = await get("/workspaces/");
      const workspacesList = Array.isArray(data) ? data : [];
      setWorkspaces(workspacesList);

      // Get current workspace from session storage
      const storedWorkspaceId = sessionStorage.getItem("currentWorkspace");
      
      if (storedWorkspaceId) {
        const storedWorkspace = workspacesList.find(w => w.id === storedWorkspaceId);
        if (storedWorkspace) {
          setCurrentWorkspace(storedWorkspace);
        } else if (workspacesList.length > 0) {
          // If stored workspace not found, set first workspace as current
          setCurrentWorkspace(workspacesList[0]);
          sessionStorage.setItem("currentWorkspace", workspacesList[0].id);
        }
      } else if (workspacesList.length > 0) {
        // If no stored workspace, set first workspace as current
        setCurrentWorkspace(workspacesList[0]);
        sessionStorage.setItem("currentWorkspace", workspacesList[0].id);
      }
    } catch (error) {
      console.error("Error fetching workspaces:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const switchWorkspace = (workspace) => {
    setCurrentWorkspace(workspace);
    sessionStorage.setItem("currentWorkspace", workspace.id);
    // Increment the counter to trigger a refresh in components that depend on workspace changes
    setWorkspaceChangeCount(prev => prev + 1);
    navigate("/");
  };

  return (
    <WorkspaceContext.Provider value={{
      currentWorkspace,
      workspaces,
      isLoading,
      switchWorkspace,
      refreshWorkspaces: fetchWorkspaces,
      workspaceChangeCount
    }}>
      {children}
    </WorkspaceContext.Provider>
  );
};

export const useWorkspaceContext = () => {
  const context = useContext(WorkspaceContext);
  if (!context) {
    throw new Error('useWorkspaceContext must be used within a WorkspaceProvider');
  }
  return context;
}; 