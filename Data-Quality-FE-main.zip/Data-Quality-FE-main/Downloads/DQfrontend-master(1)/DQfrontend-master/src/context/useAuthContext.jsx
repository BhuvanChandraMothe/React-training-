import { createContext, useContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useCookies } from "react-cookie";
import { useKeycloak } from "@react-keycloak/web";
import { setAccessToken } from "../api/io";

const AuthContext = createContext(undefined);

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuthContext must be used within an AuthProvider");
  }
  return context;
}

const authSessionKey = "_UBOLD_AUTH_KEY_";

export function AuthProvider({ children }) {
  const navigate = useNavigate();
  const { keycloak, initialized } = useKeycloak();
  const [cookies, setCookie, removeCookie] = useCookies([authSessionKey]);
  
  const getSession = () => {
    const fetchedCookie = cookies[authSessionKey];
    if (!fetchedCookie) return;
    else return fetchedCookie;
  };

  const [user, setUser] = useState(getSession());

  useEffect(() => {
    if (user?.access_token) {
      setAccessToken(user.access_token);
    }
  }, [user]);

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch (e) {
      return null;
    }
  };

  useEffect(() => {
    if (initialized && keycloak.authenticated) {
      const tokenData = parseJwt(keycloak.idToken);
      const userData = {
        access_token: keycloak.token,
        refresh_token: keycloak.refreshToken,
        id_token: keycloak.idToken,
        token_type: 'Bearer',
        session_state: keycloak.sessionId,
        scope: keycloak.realmAccess?.roles?.join(' ') || 'openid email profile',
        user: {
          id: tokenData?.sub,
          email: tokenData?.email,
          name: tokenData?.name,
          given_name: tokenData?.given_name,
          family_name: tokenData?.family_name,
          preferred_username: tokenData?.preferred_username,
          email_verified: tokenData?.email_verified
        }
      };
      saveSession(userData);
      navigate("/");
    }
  }, [initialized, keycloak.authenticated]);

  const saveSession = (user) => {
    setCookie(authSessionKey, user);
    setUser(user);
  };

  const removeSession = () => {
    removeCookie(authSessionKey);
    setUser(undefined);
    if (keycloak.authenticated) {
      keycloak.logout();
    } else {
      navigate("/auth/login");
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!cookies[authSessionKey],
        saveSession,
        removeSession,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
