import {
  FiActivity,
  FiAirplay,
  FiAperture,
  FiBarChart2,
  FiBook,
  FiBookmark,
  FiBriefcase,
  FiCalendar,
  FiClipboard,
  FiCpu,
  FiFileText,
  FiFolderPlus,
  FiGift,
  FiGrid,
  FiHome,
  FiLayers,
  FiMail,
  FiMap,
  FiMessageSquare,
  FiPackage,
  FiPocket,
  FiRss,
  FiShare2,
  FiShoppingCart,
  FiUsers,
  FiDatabase,
} from "react-icons/fi";
import { MdOutlineDashboard, MdOutlineDataset, MdOutlineWorkspaces } from "react-icons/md";
import { TbMessageChatbot, TbSchema } from "react-icons/tb";
import { GoWorkflow } from "react-icons/go";
import { VscTools } from "react-icons/vsc";
import { AiOutlineAudit } from "react-icons/ai";
import { MdAutoAwesome } from "react-icons/md";
import { TbWorldSearch } from "react-icons/tb";
import { FaDatabase } from "react-icons/fa";
import { AiOutlineSchedule } from "react-icons/ai";
import { BsClipboard2Check, BsClipboardCheck } from "react-icons/bs";
import { SiDowndetector } from "react-icons/si";
import { MdAssessment } from "react-icons/md";

const MENU_ITEMS = [
  {
    key: "aif-dashboard",
    label: "Dashboard",
    isTitle: false,
    icon: MdOutlineDashboard,
    url: "/",
  },
    {
    key: "aif-audit-profileRunDashbaord",
    label: "Data Profile Dashbaord",
    isTitle: false,
    icon: MdAssessment ,
    url: "/profileRunDashbaord",
  }, 
  {
    key: "aif-audit-database",
    label: "Database",
    isTitle: false,
    icon: FaDatabase,
    url: "/databaseConnection",
  },
   {
    key: "aif-audit-profile runs",
    label: "Profiling Run Records",
    isTitle: false,
    icon: AiOutlineAudit,
    url: "/profileRuns",
  },
   {
    key: "aif-audit-testcase",
    label: "Test Cases",
    isTitle: false,
    icon: BsClipboardCheck ,
    url: "/testcases",
  }, 
 
  //  {
  //   key: "aif-audit-schema",
  //   label: "Schema Profiling",
  //   isTitle: false,
  //   icon: TbSchema ,
  //   url: "/schema",
  // }, 
   {
    key: "aif-audit-schedules",
    label: "Schedules",
    isTitle: false,
    icon: AiOutlineSchedule ,
    url: "/schedules",
  },
  {
    key: "aif-audit-anamaly",
    label: "Anomaly ",
    isTitle: false,
    icon: SiDowndetector ,
    url: "/anomaly",
  },
 
 
];



export { MENU_ITEMS };
