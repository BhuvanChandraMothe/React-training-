import axios from 'axios';

// Create axios instance with default config
const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
});

// ==== Token Management ====
let accessToken = null;
let onUnauthorized = null;

/**
 * Get tenant from domain name
 * @returns {string} The tenant name
 */
const getTenantFromDomain = () => {
  const hostname = window.location.hostname;
  // Remove any port number if present
  const domain = hostname.split(':')[0];
  
  // Split by dots and get the first part (subdomain)
  const parts = domain.split('.');
  const tenant = parts[0];
  
  // // If we're on localhost or IP address, return default tenant
  // if (tenant === 'localhost' || /^\d+\.\d+\.\d+\.\d+$/.test(domain)) {
  //   return 'enablr'; // default tenant
  // }
  
  return tenant;
};

/**
 * Set the access token for authenticated requests.
 * @param {string} token
 */
export const setAccessToken = (token) => {
  accessToken = token;
};

/**
 * Set a custom handler for 401 Unauthorized errors.
 * @param {Function} handler
 */
export const setUnauthorizedHandler = (handler) => {
  onUnauthorized = handler;
};

// ==== Interceptors ====
api.interceptors.request.use(
  (config) => {
    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
      config.headers["x-tenant"] = getTenantFromDomain();
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && typeof onUnauthorized === 'function') {
      onUnauthorized();
    }
    return Promise.reject(error);
  }
);

// ==== Unified API Request ====
/**
 * @param {Object} config - Axios request config
 * @returns {Promise<any>}
 */
export const io = async (config) => {
  try {
    const response = await api(config);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// ==== Convenience Methods ====
export const get = (url, params) => io({ method: 'GET', url, params });
export const post = (url, data) => io({ method: 'POST', url, data });
export const patch = (url, data) => io({ method: 'PATCH', url, data });
export const del = (url) => io({ method: 'DELETE', url });

export default api;
