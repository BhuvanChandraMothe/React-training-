// import { AuthProvider } from '@/context/useAuthContext';
import { LayoutProvider } from '@/context/useLayoutContext';
import { WorkspaceProvider } from '@/context/useWorkspaceContext';
import { CookiesProvider } from 'react-cookie';

const AppProvidersWrapper = ({
  children
}) => {
  return <CookiesProvider defaultSetOptions={{
    path: '/'
  }}>
      {/* <AuthProvider> */}
        <LayoutProvider>
          <WorkspaceProvider>
            {children}
          </WorkspaceProvider>
        </LayoutProvider>
      {/* </AuthProvider> */}
    </CookiesProvider>;
};

export default AppProvidersWrapper;