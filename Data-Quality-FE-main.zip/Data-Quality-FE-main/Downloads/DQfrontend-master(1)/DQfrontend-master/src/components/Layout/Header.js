import { Box, Flex, Button, Heading, Container } from '@chakra-ui/react';

const Header = () => {
  return (
    <Box bg="brand.primary" py={4}>
      <Container maxW="container.xl">
        <Flex justify="space-between" align="center">
          <Heading size="md" color="white">
            Your Logo
          </Heading>
          <Flex gap={4}>
            <Button variant="ghost" color="white" _hover={{ bg: 'whiteAlpha.200' }}>
              Dashboard
            </Button>
            <Button variant="ghost" color="white" _hover={{ bg: 'whiteAlpha.200' }}>
              Features
            </Button>
            <Button bg="white" color="brand.primary" _hover={{ bg: 'whiteAlpha.900' }}>
              Get Started
            </Button>
          </Flex>
        </Flex>
      </Container>
    </Box>
  );
};

export default Header; 