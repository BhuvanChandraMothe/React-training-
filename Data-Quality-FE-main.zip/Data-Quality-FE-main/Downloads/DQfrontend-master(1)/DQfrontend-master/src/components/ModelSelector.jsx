import React, { useState, useRef, useEffect } from "react";
import { Overlay, Popover, Form, Badge, Button, Row, Col, InputGroup } from "react-bootstrap";
import { FaRobot, FaSearch, FaInfoCircle, FaCheckCircle, FaQuestionCircle } from "react-icons/fa";
import { MdOutlineWarningAmber } from "react-icons/md";
import "./ModelSelector.css";

const ModelSelector = ({ 
  selectedModel = "gpt-3.5-turbo",
  onModelSelect,
  size = "md",
  modelSettings = {
    temperature: 0,
    topP: 1,
    presencePenalty: 0,
    frequencyPenalty: 0,
    maxTokens: 512,
    responseFormat: ""
  },
  onModelSettingsChange
}) => {
  const [show, setShow] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [activeView, setActiveView] = useState("models"); // "models" or "parameters"
  const [settings, setSettings] = useState(modelSettings);
  const target = useRef(null);
  
  // Define model groups with their models
  const modelGroups = {
    OpenAI: [
      { id: "gpt-3.5-turbo-0125", name: "GPT-3.5 Turbo 0125", icon: <FaRobot className="text-success" />, tooltip: "Good balance of performance and cost" },
      { id: "gpt-3.5-turbo-1106", name: "GPT-3.5 Turbo 1106", icon: <FaRobot className="text-success" />, tooltip: "Updated version with improvements" },
      { id: "gpt-3.5-turbo-16k", name: "GPT-3.5 Turbo 16k", icon: <FaRobot className="text-success" />, tooltip: "Extended context length model" },
      { id: "gpt-3.5-turbo-instruct", name: "GPT-3.5 Turbo Instruct", icon: <FaRobot className="text-success" />, tooltip: "Optimized for instruction following" },
      { id: "gpt-3.5-turbo", name: "GPT-3.5 Turbo", icon: <FaRobot className="text-success" />, tooltip: "Default GPT-3.5 model" },
      { id: "gpt-4o-mini-2024-07-18", name: "GPT-4o Mini 2024-07-18", icon: <FaRobot className="text-primary" />, tooltip: "Newest compact GPT-4 model" },
      { id: "gpt-4o-mini", name: "GPT-4o Mini", icon: <FaRobot className="text-primary" />, tooltip: "Compact GPT-4 model" }
    ],
    Anthropic: [
      { id: "claude-3-opus", name: "Claude 3 Opus", icon: <FaRobot className="text-warning" />, tooltip: "Most powerful Claude model" },
      { id: "claude-3-sonnet", name: "Claude 3 Sonnet", icon: <FaRobot className="text-warning" />, tooltip: "Balanced performance" },
      { id: "claude-3-haiku", name: "Claude 3 Haiku", icon: <FaRobot className="text-warning" />, tooltip: "Fast and efficient" }
    ],
    Google: [
      { id: "gemini-pro", name: "Gemini Pro", icon: <FaRobot className="text-danger" />, tooltip: "Google's advanced model" },
      { id: "gemini-flash", name: "Gemini Flash", icon: <FaRobot className="text-danger" />, tooltip: "Fast response model" }
    ]
  };

  // Flatten all models for search
  const allModels = Object.values(modelGroups).flat();

  // Filter models based on search text
  const filteredModels = searchText.trim() === "" 
    ? modelGroups 
    : {
        "Search Results": allModels.filter(model => 
          model.name.toLowerCase().includes(searchText.toLowerCase()) || 
          model.id.toLowerCase().includes(searchText.toLowerCase())
        )
      };

  // Get information about the selected model
  const getSelectedModelInfo = () => {
    return allModels.find(model => model.id === selectedModel) || { 
      id: selectedModel, 
      name: selectedModel, 
      icon: <FaRobot className="text-secondary" />,
      tooltip: "Model information not available"
    };
  };
  
  const selectedModelInfo = getSelectedModelInfo();

  // Handle model selection
  const handleModelSelect = (modelId, event) => {
    // Stop event propagation to prevent bubbling
    if (event) {
      event.stopPropagation();
    }
    
    if (onModelSelect) {
      onModelSelect(modelId);
    }
    // Switch to parameters view after selecting a model
    setActiveView("parameters");
    // Don't close the dropdown when selecting a model
  };

  // Handle setting changes
  const handleSettingChange = (settingName, value, event) => {
    // Stop event propagation
    if (event) {
      event.stopPropagation();
    }
    
    const updatedSettings = {
      ...settings,
      [settingName]: value
    };
    setSettings(updatedSettings);
    
    if (onModelSettingsChange) {
      onModelSettingsChange(updatedSettings);
    }
  };

  // Apply settings and close popover
  const handleApply = (event) => {
    if (event) {
      event.stopPropagation();
    }
    
    if (onModelSettingsChange) {
      onModelSettingsChange(settings);
    }
    setShow(false);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Only handle outside clicks if we're not in the middle of selecting a model and moving to parameters
      if (show && 
          !event.target.closest('.model-selector-container') && 
          !event.target.closest('.model-item')) {
        setShow(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [show]);

  // Reset to model selection view when popover is closed
  useEffect(() => {
    if (!show) {
      setTimeout(() => setActiveView("models"), 300);
      setSearchText("");
    }
  }, [show]);

  // Update local settings when prop changes
  useEffect(() => {
    setSettings(modelSettings);
  }, [modelSettings]);

  const renderParametersView = () => (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <Button 
          variant="link" 
          className="text-decoration-none p-0" 
          onClick={() => setActiveView("models")}
        >
          <i className="mdi mdi-arrow-left me-1"></i> Back to models
        </Button>
        <Badge bg="primary" className="px-2 py-1">{selectedModelInfo.name}</Badge>
      </div>

      <div className="parameters-list">
        <div className="parameter-item mb-3">
          <Form.Group className="d-flex align-items-center mb-2">
            <Form.Check 
              type="checkbox" 
              id="temperature-toggle"
              checked={settings.temperature !== undefined}
              onChange={(e) => {
                e.stopPropagation();
                handleSettingChange("temperature", e.target.checked ? 0 : undefined, e);
              }}
              className="me-2" 
            />
            <Form.Label htmlFor="temperature-toggle" className="mb-0 d-flex align-items-center" onClick={(e) => e.stopPropagation()}>
              Temperature <FaQuestionCircle className="ms-1 text-muted small" title="Controls randomness of responses" />
            </Form.Label>
          </Form.Group>
          <div className="d-flex align-items-center">
            <Form.Range 
              disabled={settings.temperature === undefined}
              min={0} 
              max={1} 
              step={0.1} 
              value={settings.temperature || 0}
              onChange={(e) => {
                e.stopPropagation();
                handleSettingChange("temperature", parseFloat(e.target.value), e);
              }}
              onClick={(e) => e.stopPropagation()}
              className="flex-grow-1 me-2"
            />
            <Form.Control 
              type="number" 
              min={0} 
              max={1} 
              step={0.1}
              value={settings.temperature || 0}
              onChange={(e) => {
                e.stopPropagation();
                handleSettingChange("temperature", parseFloat(e.target.value), e);
              }}
              onClick={(e) => e.stopPropagation()}
              disabled={settings.temperature === undefined}
              className="parameter-value-input"
            />
          </div>
        </div>

        <div className="parameter-item mb-3">
          <Form.Group className="d-flex align-items-center mb-2">
            <Form.Check 
              type="checkbox" 
              id="topP-toggle"
              checked={settings.topP !== undefined}
              onChange={(e) => handleSettingChange("topP", e.target.checked ? 1 : undefined)}
              className="me-2" 
            />
            <Form.Label htmlFor="topP-toggle" className="mb-0 d-flex align-items-center">
              Top P <FaQuestionCircle className="ms-1 text-muted small" title="Controls diversity via nucleus sampling" />
            </Form.Label>
          </Form.Group>
          <div className="d-flex align-items-center">
            <Form.Range 
              disabled={settings.topP === undefined}
              min={0} 
              max={1} 
              step={0.1} 
              value={settings.topP || 1}
              onChange={(e) => handleSettingChange("topP", parseFloat(e.target.value))}
              className="flex-grow-1 me-2"
            />
            <Form.Control 
              type="number" 
              min={0} 
              max={1} 
              step={0.1}
              value={settings.topP || 1}
              onChange={(e) => handleSettingChange("topP", parseFloat(e.target.value))}
              disabled={settings.topP === undefined}
              className="parameter-value-input"
            />
          </div>
        </div>

        <div className="parameter-item mb-3">
          <Form.Group className="d-flex align-items-center mb-2">
            <Form.Check 
              type="checkbox" 
              id="presencePenalty-toggle"
              checked={settings.presencePenalty !== undefined}
              onChange={(e) => handleSettingChange("presencePenalty", e.target.checked ? 0 : undefined)}
              className="me-2" 
            />
            <Form.Label htmlFor="presencePenalty-toggle" className="mb-0 d-flex align-items-center">
              Presence Penalty <FaQuestionCircle className="ms-1 text-muted small" title="Penalizes new tokens based on whether they appear in the text so far" />
            </Form.Label>
          </Form.Group>
          <div className="d-flex align-items-center">
            <Form.Range 
              disabled={settings.presencePenalty === undefined}
              min={0} 
              max={2} 
              step={0.1} 
              value={settings.presencePenalty || 0}
              onChange={(e) => handleSettingChange("presencePenalty", parseFloat(e.target.value))}
              className="flex-grow-1 me-2"
            />
            <Form.Control 
              type="number" 
              min={0} 
              max={2} 
              step={0.1}
              value={settings.presencePenalty || 0}
              onChange={(e) => handleSettingChange("presencePenalty", parseFloat(e.target.value))}
              disabled={settings.presencePenalty === undefined}
              className="parameter-value-input"
            />
          </div>
        </div>

        <div className="parameter-item mb-3">
          <Form.Group className="d-flex align-items-center mb-2">
            <Form.Check 
              type="checkbox" 
              id="frequencyPenalty-toggle"
              checked={settings.frequencyPenalty !== undefined}
              onChange={(e) => handleSettingChange("frequencyPenalty", e.target.checked ? 0 : undefined)}
              className="me-2" 
            />
            <Form.Label htmlFor="frequencyPenalty-toggle" className="mb-0 d-flex align-items-center">
              Frequency Penalty <FaQuestionCircle className="ms-1 text-muted small" title="Penalizes tokens based on their frequency in the text so far" />
            </Form.Label>
          </Form.Group>
          <div className="d-flex align-items-center">
            <Form.Range 
              disabled={settings.frequencyPenalty === undefined}
              min={0} 
              max={2} 
              step={0.1} 
              value={settings.frequencyPenalty || 0}
              onChange={(e) => handleSettingChange("frequencyPenalty", parseFloat(e.target.value))}
              className="flex-grow-1 me-2"
            />
            <Form.Control 
              type="number" 
              min={0} 
              max={2} 
              step={0.1}
              value={settings.frequencyPenalty || 0}
              onChange={(e) => handleSettingChange("frequencyPenalty", parseFloat(e.target.value))}
              disabled={settings.frequencyPenalty === undefined}
              className="parameter-value-input"
            />
          </div>
        </div>

        <div className="parameter-item mb-3">
          <Form.Group className="d-flex align-items-center mb-2">
            <Form.Check 
              type="checkbox" 
              id="maxTokens-toggle"
              checked={settings.maxTokens !== undefined}
              onChange={(e) => handleSettingChange("maxTokens", e.target.checked ? 512 : undefined)}
              className="me-2" 
            />
            <Form.Label htmlFor="maxTokens-toggle" className="mb-0 d-flex align-items-center">
              Max Tokens <FaQuestionCircle className="ms-1 text-muted small" title="Maximum number of tokens to generate" />
            </Form.Label>
          </Form.Group>
          <div className="d-flex align-items-center">
            <Form.Range 
              disabled={settings.maxTokens === undefined}
              min={1} 
              max={2048} 
              step={1} 
              value={settings.maxTokens || 512}
              onChange={(e) => handleSettingChange("maxTokens", parseInt(e.target.value))}
              className="flex-grow-1 me-2"
            />
            <Form.Control 
              type="number" 
              min={1} 
              max={2048} 
              step={1}
              value={settings.maxTokens || 512}
              onChange={(e) => handleSettingChange("maxTokens", parseInt(e.target.value))}
              disabled={settings.maxTokens === undefined}
              className="parameter-value-input"
            />
          </div>
        </div>

        <div className="parameter-item mb-3">
          <Form.Group className="d-flex align-items-center mb-2">
            <Form.Check 
              type="checkbox" 
              id="responseFormat-toggle"
              checked={settings.responseFormat !== undefined && settings.responseFormat !== ""}
              onChange={(e) => handleSettingChange("responseFormat", e.target.checked ? "Please select" : "")}
              className="me-2" 
            />
            <Form.Label htmlFor="responseFormat-toggle" className="mb-0 d-flex align-items-center">
              Response Format <FaQuestionCircle className="ms-1 text-muted small" title="Format of the model's response" />
            </Form.Label>
          </Form.Group>
          <Form.Select 
            value={settings.responseFormat || "Please select"}
            onChange={(e) => handleSettingChange("responseFormat", e.target.value)}
            disabled={settings.responseFormat === undefined || settings.responseFormat === ""}
          >
            <option value="Please select">Please select</option>
            <option value="text">Text</option>
            <option value="json_object">JSON Object</option>
            <option value="markdown">Markdown</option>
          </Form.Select>
        </div>
      </div>
    </>
  );

  const renderModelsView = () => (
    <>
      <div className="model-search mb-3">
        <div className="position-relative">
          <FaSearch className="position-absolute search-icon" />
          <Form.Control
            type="text"
            placeholder="Search model"
            value={searchText}
            onChange={(e) => {
              e.stopPropagation();
              setSearchText(e.target.value);
            }}
            onClick={(e) => e.stopPropagation()}
            className="ps-4 bg-light border-0"
          />
        </div>
      </div>
      
      <div className="model-list">
        {Object.entries(filteredModels).map(([groupName, models]) => (
          models.length > 0 && (
            <div key={groupName} className="model-group mb-3">
              <div className="model-group-name mb-2">{groupName}</div>
              {models.map(model => (
                <div 
                  key={model.id}
                  className={`model-item d-flex align-items-center p-2 ${selectedModel === model.id ? 'selected' : ''}`}
                  onClick={(e) => handleModelSelect(model.id, e)}
                >
                  <div className="model-icon me-2">
                    {model.icon}
                  </div>
                  <div className="model-details flex-grow-1">
                    <div className="model-name">{model.name}</div>
                    <div className="model-id text-muted small">{model.id}</div>
                  </div>
                  {selectedModel === model.id && (
                    <FaCheckCircle className="text-success ms-2" />
                  )}
                  <div className="model-tooltip-icon ms-2">
                    <FaInfoCircle className="text-muted" title={model.tooltip} />
                  </div>
                </div>
              ))}
            </div>
          )
        ))}
        
        {Object.values(filteredModels).flat().length === 0 && (
          <div className="text-center py-4 text-muted">
            No models found matching "{searchText}"
          </div>
        )}
      </div>
    </>
  );

  return (
    <div className="model-selector-container">
      <Button
        ref={target}
        onClick={() => setShow(!show)}
        variant="light"
        className={`d-flex align-items-center rounded-4 model-selector-button ${size === "sm" ? "py-1 px-2" : "py-2 px-3"}`}
        size={size}
      >
        <div className="d-flex align-items-center">
          {selectedModelInfo.icon}
          <span className={`ms-2 ${size === "sm" ? "small" : ""}`}>{selectedModelInfo.name}</span>
        </div>
        <MdOutlineWarningAmber className="ms-2 text-warning" />
      </Button>

      <Overlay
        show={show}
        target={target.current}
        placement="bottom"
        container={document.body}
        rootClose={false}
        onHide={() => setShow(false)}
      >
        <Popover 
          className="model-selector-popover" 
          style={{ minWidth: "320px", maxWidth: "350px" }}
          onClick={(e) => e.stopPropagation()}
        >
          <Popover.Header 
            as="h3" 
            className="bg-light d-flex justify-content-between align-items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <span>{activeView === "models" ? "Select AI Model" : "Model Parameters"}</span>
            <Badge bg="primary" pill>Enterprise</Badge>
          </Popover.Header>
          <Popover.Body onClick={(e) => e.stopPropagation()}>
            {activeView === "models" ? renderModelsView() : renderParametersView()}
            
            <hr />
            
            <div className="d-flex justify-content-between align-items-center">
              <Button 
                variant="link" 
                className="text-decoration-none p-0 small" 
                onClick={(e) => {
                  e.stopPropagation();
                  activeView === "models" ? window.open('#', '_blank') : setActiveView("models");
                }}
              >
                {activeView === "models" ? (
                  <><FaInfoCircle className="me-1" /> Model Provider Settings</>
                ) : (
                  "Load Presets"
                )}
              </Button>
              <Button 
                size="sm" 
                variant="primary" 
                onClick={(e) => handleApply(e)}
              >
                Apply
              </Button>
            </div>
          </Popover.Body>
        </Popover>
      </Overlay>
    </div>
  );
};

export default ModelSelector; 