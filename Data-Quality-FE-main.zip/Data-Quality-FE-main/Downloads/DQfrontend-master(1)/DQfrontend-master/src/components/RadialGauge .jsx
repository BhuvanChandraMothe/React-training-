// // // components/RadialGauge.js
import React from 'react';
import {
  CircularProgressbar,
  buildStyles
} from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

import { Box, CircularProgress, Typography } from "@mui/material";


const RadialGauge = ({ value, title, subValueLabel, subValue, trendData, gaugeColor = '#ffc107', sparklineNullColor = 'teal', sparklineDistinctColor = 'purple' }) => {
    // const theme = useTheme();
    const normalizedValue = Math.min(100, Math.max(0, value));

    return (
        <Box sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            position: 'relative',
            width: 200,
            height: 200,
            p: 1.5,
            borderRadius: '10px',
            backgroundColor: 'white'
            // boxShadow: '',
        }}>
            <Box sx={{ position: 'relative', width: 150, height: 150, mb: 1 }}>
                <CircularProgress
                    variant="determinate"
                    value={100}
                    size={150}
                    thickness={4}
                    sx={{
                        // color: theme.palette.action.disabledBackground,
                        position: 'absolute',
                        left: 0,
                        top: 0,
                    }}
                />
                <CircularProgress
                    variant="determinate"
                    value={normalizedValue}
                    size={150}
                    thickness={4}
                    sx={{
                        color: gaugeColor,
                        position: 'absolute',
                        left: 0,
                        top: 0,
                        transform: 'rotate(-90deg)',
                        transformOrigin: 'center center',
                    }}
                />
                <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                >
                    <Typography variant="h6" component="div" sx={{ fontWeight: 'bold',marginTop:'20px'  }}>
                        {`${Math.round(value)}%`} 
                    </Typography>
                      <Typography variant="subtitle2" sx={{  mt: 0.5,fontSize:'12px',fontWeight:'bold',textAlign:'center' }}>
                {title}
            </Typography>
                </Box>
            </Box>
          

            {/* <Box sx={{ mt: 1 }}>
                <Sparkline
                    data={trendData}
                    color={sparklineDistinctColor}
                    nullColor={sparklineNullColor}
                    width={120}
                    height={30}
                />
            </Box> */}

            {/* {subValueLabel && (
                <div style={{marginTop:'0px'}}>
                <Typography variant="caption" sx={{  mt: 2 }}>
                    <Typography component="span" sx={{ fontWeight: 'bold',marginTop:'30px' }}>{subValueLabel}:</Typography> {subValue || 0}
                </Typography>
                </div>
            )} */}
        </Box>
    );
};
export default RadialGauge
const Sparkline = ({ data, color, nullColor, width = 100, height = 30 }) => {
    if (!data || data.length < 2) {
        return <Box sx={{ width, height, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8rem', color: nullColor }}>Not enough data</Box>;
    }

    const maxDataValue = Math.max(...data);
    const minDataValue = Math.min(...data);

    const points = data.map((d, i) => {
        const x = (i / (data.length - 1)) * width;
        const y = height - ((d - minDataValue) / (maxDataValue - minDataValue + 0.001)) * height;
        return `${x},${y}`;
    }).join(' ');

    const isDownwardTrend = data[data.length - 1] < data[0];
    const trendColor = isDownwardTrend ? 'purple' : color;

    return (
        <Box sx={{ width, height, overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
                <polyline
                    fill="none"
                    stroke={trendColor}
                    strokeWidth="1.5"
                    points={points}
                />
            </svg>
        </Box>
    );
};