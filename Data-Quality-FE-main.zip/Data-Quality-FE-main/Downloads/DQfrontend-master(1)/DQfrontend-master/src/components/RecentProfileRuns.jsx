import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Table, Button, Badge, Spinner, Dropdown } from 'react-bootstrap';
import { format } from 'date-fns'; // For date formatting

// Recharts components for the DQ Score trend chart
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer
} from 'recharts';
import { getProfilingTableDetails, getTableNamesForProfilingRun } from '../api/dbapi';
import RadialGauge from "../../src/components/RadialGauge ";
// Helper function for status badge
const getStatusBadge = (status) => {
    switch (status) {
        case "Complete":
            return <Badge bg="success">Complete</Badge>;
        case "failure":
            return <Badge bg="danger">Failure</Badge>;
        case "info":
            return <Badge bg="info">Info</Badge>;
        default:
            return <Badge bg="secondary">{status}</Badge>;
    }
};

// Helper function to format numbers for tables
function formatNumber(value) {
    return Number(value).toLocaleString('en-US', {
        minimumFractionDigits: 0, // No decimal places for counts like distinct values
        maximumFractionDigits: 0,
    });
}

function RecentProfileRuns({ data }) {
    const logs = data?.runs || [];
    const [expandedRunId, setExpandedRunId] = useState(null); // State to track which run is expanded
    const [selectedTableName, setSelectedTableName] = useState(null); // State for selected table within expanded details

    // States for data fetching within the expanded details
    const [tableNames, setTableNames] = useState([]);
    const [loadingTableNames, setLoadingTableNames] = useState(false);
    const [errorTableNames, setErrorTableNames] = useState(null)

    const [tableDetails, setTableDetails] = useState(null);
    const [loadingTableDetails, setLoadingTableDetails] = useState(false);
    const [errorTableDetails, setErrorTableDetails] = useState(null);
    useEffect(() => {
        const fetchNames = async () => {
            if (!expandedRunId) {
                setTableNames([]);
                setSelectedTableName(null);
                return;
            }
            setLoadingTableNames(true);
            setErrorTableNames(null);
            try {
                const names = await getTableNamesForProfilingRun(expandedRunId);
                setTableNames(names);
                setSelectedTableName(null);
                if (names.length > 0) {
                    setSelectedTableName(names[0].tableName);
                } else {
                    setSelectedTableName(null);
                }
            } catch (err) {
                setErrorTableNames("Please select your Table Name");
                setTableNames([]);
                setSelectedTableName(null);
            } finally {
                setLoadingTableNames(false);
            }
        };

        fetchNames();
    }, [expandedRunId]);

    useEffect(() => {
        const fetchDetails = async () => {
            if (expandedRunId && selectedTableName) {
                setLoadingTableDetails(true);
                setErrorTableDetails(null);
                try {
                    const data = await getProfilingTableDetails(expandedRunId, selectedTableName);
                    setTableDetails(data);
                    // console.log(data);

                } catch (err) {
                    console.error("Error fetching table details:", err);
                    setErrorTableDetails("Select Table Name to view the details.");
                    setTableDetails(null);
                } finally {
                    setLoadingTableDetails(false);
                }
            }
        };

        fetchDetails();
    }, [expandedRunId, selectedTableName]);

    const handleRowClick = (runId) => {
        setExpandedRunId(prevId => prevId === runId ? null : runId);
    };


    // Prepare data for the DQ score trend chart
    const dqScoreChartData = (tableDetails?.tableDQScoreHistory || [])
        .filter(item => item.dqScore !== null && item.dqScore !== undefined)
        .map(item => ({
            profilingTime: item.profilingTime,
            'DQ Score': item.dqScore ? parseFloat((item.dqScore * 100).toFixed(1)) : 0
        }))
        .sort((a, b) => new Date(a.profilingTime).getTime() - new Date(b.profilingTime).getTime());

    return (
        <div>
            <h4 className="mb-2">Recent Profile Runs</h4>
            <Row>
                <Col>
                    <Card>
                        <Card.Body>
                            <div className="table-responsive">
                                <Table striped >
                                    <thead>
                                        <tr>
                                            <th className="sortable" style={{ cursor: 'pointer' }}>Connection Id</th>
                                            <th className="sortable" style={{ cursor: 'pointer' }}>Database Name</th>
                                              <th className="sortable" style={{ cursor: 'pointer' }}>Table Group Name</th>
                                            <th className="sortable" style={{ cursor: 'pointer' }}> Scheme Name</th>
                                            <th className="sortable" style={{ cursor: 'pointer' }}> Status</th>
                                            <th className="sortable" style={{ cursor: 'pointer' }}> Created At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {logs.length > 0 ? (
                                            logs.map((run,index) => (
                                                <React.Fragment key={index}>
                                                    <tr onClick={() => handleRowClick(run.run_uuid)}
                                                        style={{ cursor: 'pointer', backgroundColor: expandedRunId === run.database_connection_id ? '#e9ecef' : 'inherit' }}>
                                                        <td>{run.database_connection_id}</td>
                                                        <td>{run?.database_name}</td>
                                                        <td>{run?.table_group_name}</td>
                                                        <td>{run?.schema_name}</td>
                                                        <td>{getStatusBadge(run.status)}</td>
                                                        <td>{run.run_display_id || 0}</td>
                                                    </tr>
                                                    {expandedRunId === run.run_uuid && (
                                                        <tr >
                                                            <td colSpan="7" > {/* Adjust colSpan if more columns are added */}
                                                                <Card className="mt-3 mb-3 p-3 shadow">
                                                                    {tableNames.length > 0 && (
                                                                        <div className="mb-3">
                                                                            <label><strong>Select Table:</strong></label>
                                                                            <select
                                                                                value={selectedTableName || ""}
                                                                                onChange={(e) => {
                                                                                    const selected = e.target.value;
                                                                                    setSelectedTableName(selected);
                                                                                }}
                                                                                className="form-select"
                                                                            >
                                                                                <option value="" disabled>
                                                                                    Select Table Name
                                                                                </option>
                                                                                {tableNames.map((table, idx) => (
                                                                                    <option key={idx} value={table.tableName}>
                                                                                        {table.tableName}
                                                                                    </option>
                                                                                ))}
                                                                            </select>
                                                                        </div>
                                                                    )}
                                                                    <>
                                                                        {loadingTableDetails ? (
                                                                            <div className="text-center my-4">
                                                                                <Spinner animation="border" />
                                                                                <p className="mt-2">Loading table details...</p>
                                                                            </div>
                                                                        ) : errorTableDetails ? (
                                                                            <div className="text-danger mt-4">{errorTableDetails}</div>
                                                                        ) : tableDetails ? (
                                                                            <>
                                                                                <div className="col-12">
                                                                                    <div className="row gx-2 gy-3 justify-content-center">
                                                                                        <div className="col-12 col-sm-6 col-md-3 d-flex justify-content-center">
                                                                                            <RadialGauge
                                                                                                value={
                                                                                                    tableDetails?.profilingScore
                                                                                                        ? parseFloat(tableDetails.profilingScore * 100).toFixed(1)
                                                                                                        : ''
                                                                                                }
                                                                                                title="Data Quality Score"
                                                                                            />
                                                                                        </div>
                                                                                        <div className="col-12 col-sm-6 col-md-3 d-flex justify-content-center">
                                                                                            <RadialGauge
                                                                                                value={
                                                                                                    tableDetails?.completenessPercentage
                                                                                                        ? parseFloat(tableDetails.completenessPercentage).toFixed(1)
                                                                                                        : ''
                                                                                                }
                                                                                                title="Completeness Score"
                                                                                            />
                                                                                        </div>
                                                                                        <div className="col-12 col-sm-6 col-md-3 d-flex justify-content-center">
                                                                                            <RadialGauge
                                                                                                value={tableDetails?.distinctValuePercentage || 0}
                                                                                                title="Distinctness Score"
                                                                                            />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <h5 className="mt-4">DQ Score Trend for {tableDetails.tableName}</h5>
                                                                                <div style={{ width: '100%', height: 250 }}>
                                                                                    {dqScoreChartData.length > 1 ? (
                                                                                        <ResponsiveContainer width="100%" height="100%">
                                                                                            <LineChart
                                                                                                data={dqScoreChartData}
                                                                                                margin={{ top: 5, right: 10, left: 0, bottom: 5 }}
                                                                                            >
                                                                                                <CartesianGrid strokeDasharray="3 3" />
                                                                                                <XAxis
                                                                                                    dataKey="profilingTime"
                                                                                                    tickFormatter={(tick) => format(new Date(tick), 'dd/MM/yyyy h:mm a')}
                                                                                                    angle={-30}
                                                                                                    textAnchor="end"
                                                                                                    height={60}
                                                                                                />
                                                                                                <YAxis domain={[0, 100]} tickFormatter={(tick) => `${tick}%`} />
                                                                                                <Tooltip
                                                                                                    formatter={(value, name) => [`${value.toFixed(1)}%`, name]}
                                                                                                    labelFormatter={(label) => `Time: ${format(new Date(label), 'MMM dd,yyyy, h:mm a')}`}
                                                                                                />
                                                                                                <Legend />
                                                                                                <Line type="monotone" dataKey="DQ Score" stroke="#8884d8" activeDot={{ r: 8 }} />
                                                                                            </LineChart>
                                                                                        </ResponsiveContainer>
                                                                                    ) : (
                                                                                        <div className="text-center text-muted my-4">Not enough historical data to show DQ score trend.</div>
                                                                                    )}
                                                                                </div>
                                                                                <h5 className="mt-4">Column Data Types</h5>
                                                                                <div className="table-responsive" style={{ maxHeight: '300px', overflowY: 'auto' }}>
                                                                                    <Table striped bordered hover size="sm">
                                                                                        <thead>
                                                                                            <tr>
                                                                                                <th>Column Name</th>
                                                                                                <th>Column Type</th>
                                                                                                <th>General Type</th>
                                                                                            </tr>
                                                                                        </thead>
                                                                                        <tbody>
                                                                                            {tableDetails.columnDataTypes?.length > 0 ? (
                                                                                                tableDetails.columnDataTypes.map((col, idx) => (
                                                                                                    <tr key={idx}>
                                                                                                        <td>{col.columnName}</td>
                                                                                                        <td>{col.columnType}</td>
                                                                                                        <td>{col.generalType}</td>
                                                                                                    </tr>
                                                                                                ))
                                                                                            ) : (
                                                                                                <tr><td colSpan="3" className="text-center text-muted">No column data types found.</td></tr>
                                                                                            )}
                                                                                        </tbody>
                                                                                    </Table>
                                                                                </div>
                                                                                <h5 className="mt-4">Data Distribution</h5>
                                                                                <div className="table-responsive" style={{ maxHeight: '300px', overflowY: 'auto' }}>
                                                                                    <Table striped bordered hover size="sm">
                                                                                        <thead>
                                                                                            <tr>
                                                                                                <th>Column</th>
                                                                                                <th>Data Type</th>
                                                                                                <th>Distinct Values</th>
                                                                                                <th>Missing Values</th>
                                                                                                <th>Empty Values</th>
                                                                                            </tr>
                                                                                        </thead>
                                                                                        <tbody>
                                                                                            {tableDetails.dataDistribution?.length > 0 ? (
                                                                                                tableDetails.dataDistribution.map((dist, idx) => (
                                                                                                    <tr key={idx}>
                                                                                                        <td>{dist.column}</td>
                                                                                                        <td>{dist.dataType}</td>
                                                                                                        <td>{formatNumber(dist.distinctValues)}</td>
                                                                                                        <td>{formatNumber(dist.missingValues)}</td>
                                                                                                        <td>{formatNumber(dist.emptyValues)}</td>
                                                                                                    </tr>
                                                                                                ))
                                                                                            ) : (
                                                                                                <tr><td colSpan="5" className="text-center text-muted">No data distribution details found.</td></tr>
                                                                                            )}
                                                                                        </tbody>
                                                                                    </Table>
                                                                                </div>
                                                                            </>
                                                                        ) : (
                                                                            <p className="text-muted mt-4">Selected table details will be displayed here.</p>
                                                                        )}
                                                                    </>
                                                                </Card>
                                                            </td>
                                                        </tr>
                                                    )}
                                                </React.Fragment>
                                            ))
                                        ) : (
                                            <tr>
                                                <td colSpan="5" className="text-center">
                                                    No recent profile runs found.
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </Table>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </div>
    );
}

export default RecentProfileRuns;
