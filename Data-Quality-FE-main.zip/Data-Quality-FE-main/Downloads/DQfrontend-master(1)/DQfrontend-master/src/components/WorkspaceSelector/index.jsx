import React from "react";
import { Dropdown } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useWorkspaceContext } from "@/context/useWorkspaceContext";

const WorkspaceSelector = () => {
  const { currentWorkspace, workspaces, switchWorkspace } = useWorkspaceContext();
  const navigate = useNavigate();

  return (
    <Dropdown className="d-none d-lg-inline-block me-3">
      <Dropdown.Toggle
        variant="link"
        className="nav-link waves-effect waves-light"
        style={{
          fontWeight: 500,
          color: "var(--ct-topbar-item-color)",
          display: "flex",
          alignItems: "center",
          gap: "5px",
        }}
      >
        <i className="mdi mdi-briefcase-outline font-16"></i>
        {currentWorkspace ? currentWorkspace.name : "Select Workspace"}<i className="mdi mdi-chevron-down"></i>
      </Dropdown.Toggle>

      <Dropdown.Menu className="dropdown-menu-animated dropdown-lg">
        <div className="dropdown-header noti-title">
          <h5 className="text-overflow mb-2">Your Workspaces</h5>
        </div>

        {workspaces?.map((workspace) => (
          <Dropdown.Item
            key={workspace.id}
            className={`notify-item ${
              currentWorkspace?.id === workspace.id ? "active" : ""
            }`}
            onClick={() => switchWorkspace(workspace)}
          >
            <div className="d-flex align-items-center">
              <div
                className="flex-shrink-0 me-2"
                style={{
                  width: "32px",
                  height: "32px",
                  backgroundColor: "#f8f9fa",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <i className="mdi mdi-briefcase-outline font-16"></i>
              </div>
              <div className="flex-grow-1">
                <h6 className="mb-0">{workspace.name}</h6>
                <small className="text-muted">{workspace.description}</small>
              </div>
              {currentWorkspace?.id === workspace.id && (
                <i className="mdi mdi-check-circle text-success"></i>
              )}
            </div>
          </Dropdown.Item>
        ))}

        <Dropdown.Divider />

        <Dropdown.Item onClick={() => navigate("/workspaces")}>
          <i className="mdi mdi-plus-circle-outline me-1"></i>
          Create New Workspace
        </Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default WorkspaceSelector; 