import "bootstrap/dist/css/bootstrap.min.css";
import "@/assets/scss/Default.scss";
import "@/assets/scss/Icons.scss";
import AllRoutes from "@/routes/Routes.jsx";
import AppProvidersWrapper from "@/components/AppProvidersWrapper.jsx";
import "./App.css";
import useAuth from "./useAuth";
import Loader from "./components/Loader";
function App() {
  const { isLogin, keycloak } = useAuth();
  localStorage.setItem("token", keycloak?.idToken);
  localStorage.setItem("userName", keycloak?.idTokenParsed?.preferred_username); // Show a loading screen while Keycloak is initializing
  if (!keycloak) {
    return (
      <div>
        <Loader />
      </div>
    );
  }
  if (!isLogin) {
    return <div>Redirecting to login...</div>;
  }
  return (
    <AppProvidersWrapper>
      <AllRoutes />
    </AppProvidersWrapper>
  );
}

export default App;
