import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { BrowserRouter } from "react-router-dom";
import Keycloak from "keycloak-js";
import { ReactKeycloakProvider } from "@react-keycloak/web";
import axios from "axios";
import instances from "./api/instances.json";
import { ToasterProvider } from "./Toaster/Toaster.jsx";

const getTenantFromDomain = () => {
  const hostname = window.location.hostname;
  // Remove any port number if present
  const domain = hostname?.replace(/^https?:\/\//, '')?.split(':')[0];
    
  // Split by dots and get the first part (subdomain)
  const parts = domain.split('.');
  const tenant = parts[0];
  
  // If we're on localhost or IP address, return default tenant
  if (tenant === 'localhost' || tenant === 'dev' || /^\d+\.\d+\.\d+\.\d+$/.test(domain)) {
    return 'aifabric'; // default tenant
  }
  
  return tenant;
};

const getKeycloakConfig = async () => {
  const tenant = getTenantFromDomain();
  
  // Check if we have cached config for this tenant
  const cachedConfig = localStorage.getItem(`keycloak_config_${tenant}`);
  if (cachedConfig) {
    return JSON.parse(cachedConfig);
  }

  try {
    // Fetch auth configuration from API
    const response = await axios.get(
      `${instances.tenants.baseUrl}/api/v1/tenants/${tenant}`,
      { headers: { "x-tenant": tenant } }
    );

    // Extract realm and clientId from the nested response structure
    const { data } = response.data;
    const { tenant_config } = data;
    const { keycloak: tenantKeycloakConfig } = tenant_config;

    const config = {
      realm: tenantKeycloakConfig.realm.name,
      clientId: tenantKeycloakConfig.client.name
    };

    // Cache the config in localStorage
    localStorage.setItem(`keycloak_config_${tenant}`, JSON.stringify(config));

    return config;
  } catch (error) {
    console.error("Error fetching Keycloak config:", error);
    throw error;
  }
};

const initializeApp = async () => {
  try {
    // Get dynamic config
    const { realm, clientId } = await getKeycloakConfig();

    // Base Keycloak configuration
    const keycloakConfig = {
      url: instances.auth.baseUrl,
      realm: realm,
      clientId: clientId,
      onLoad: "check-sso",
      silentCheckSsoRedirectUri:
        window.location.origin + "/silent-check-sso.html",
      checkLoginIframe: false,
      enableLogging: true,
      pkceMethod: "S256",
    };

    const keycloak = new Keycloak(keycloakConfig);

    // Add event listeners for debugging
    keycloak.onAuthSuccess = () => {
      console.log("Keycloak authentication successful");
    };

    keycloak.onAuthError = (error) => {
      console.error("Keycloak authentication error:", error);
    };

    keycloak.onAuthRefreshSuccess = () => {
      console.log("Keycloak token refresh successful");
    };

    keycloak.onAuthRefreshError = (error) => {
      console.error("Keycloak token refresh error:", error);
    };

    const root = createRoot(document.getElementById("root"));

    const keycloakProviderInitConfig = {
      onLoad: "check-sso",
      silentCheckSsoRedirectUri:
        window.location.origin + "/silent-check-sso.html",
      checkLoginIframe: false,
    };

    const handleKeycloakEvent = (event, error) => {
      if (event === "onInitError") {
        console.error("Keycloak initialization error:", error);
      }
    };

    const handleKeycloakTokens = (tokens) => {
      if (tokens.token) {
        // Store the current path before any redirects
        const currentPath = window.location.pathname + window.location.search;
        sessionStorage.setItem("redirectPath", currentPath);
      }
    };

    root.render( <ToasterProvider>
      <BrowserRouter basename="/">
     
          <App />
          
       
      </BrowserRouter>
      </ToasterProvider>
    );
  } catch (error) {
    console.error("Failed to initialize app:", error);
    // You might want to show an error UI here
    const root = createRoot(document.getElementById("root"));
    root.render(
      <div>Failed to initialize application. Please try again later.</div>
    );
  }
};

// Start the initialization
initializeApp();
