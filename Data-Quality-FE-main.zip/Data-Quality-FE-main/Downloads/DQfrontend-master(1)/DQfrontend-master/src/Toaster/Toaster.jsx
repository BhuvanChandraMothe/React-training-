import React, { createContext, useState, useContext, useEffect } from 'react';

// Create context
const ToasterContext = createContext(undefined);

// Provider
export const ToasterProvider = ({ children }) => {
  const [toast, setToast] = useState(null);

  const showToast = (message, type, data) => {
    setToast({ message, type, data });
  };

  const hideToast = () => {
    setToast(null);
  };

  // Auto-dismiss after 5 seconds
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        hideToast();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  return (
    <ToasterContext.Provider value={{ showToast }}>
      {children}

      {/* Toast Component */}
      {toast && (
        <div
          className={`position-fixed top-0 end-0 m-4 p-3 rounded shadow bg-${getBootstrapBgColor(
            toast.type
          )} text-dark`}
          style={{
            zIndex: 1050,
            marginTop: '40px',
            maxWidth: '350px',
            width: '100%',
          }}
        >
          <div className="d-flex justify-content-between align-items-start">
            <div className="d-flex">
              {/* <img
                src={getImageSrc(toast.type)}
                alt={toast.type}
                style={{ width: '24px', height: '24px', marginRight: '8px' }}
              /> */}
              <div>
                <div className="fw-semibold text-white">{toast.message}</div>
                {/* {toast.data && (
                  <div className="text-muted small">{toast.data}</div>
                )} */}
              </div>
            </div>
            <button
              onClick={hideToast}
              className="btn-close ms-2"
              aria-label="Close"
            ></button>
          </div>
        </div>
      )}
    </ToasterContext.Provider>
  );
};

// Helper to get icon based on type
const getImageSrc = (type) => {
  switch (type) {
    case 'success':
      return '/images/successToaster.svg';
    case 'deleted':
      return '/images/Delete.svg';
    case 'error':
    default:
      return '/images/error.svg';
  }
};

// Helper to map toast type to Bootstrap background class
const getBootstrapBgColor = (type) => {
  switch (type) {
    case 'success':
      return 'primary'; // bg-success
    case 'deleted':
    case 'error':
      return 'danger'; // bg-danger
    default:
      return 'light'; // bg-light
  }
};

// Custom hook
export const useToaster = () => {
  const context = useContext(ToasterContext);
  if (context === undefined) {
    throw new Error('useToaster must be used within a ToasterProvider');
  }
  return context;
};
