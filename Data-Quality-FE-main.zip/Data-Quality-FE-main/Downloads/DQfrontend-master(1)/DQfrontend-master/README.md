# AIF Application

This is a cleaned-up version of a template, keeping only the components and features needed for the AIF project.

## Project Structure

- `/src/pages/aif` - Main application code for the AIF project
  - `/dashboard` - Dashboard components
  - `/datasets` - Dataset management components
  - `/chatbots` - Chatbot management components  
  - `/agents` - AI agents management components
- `/src/components` - Reusable UI components
- `/src/assets` - CSS, SCSS, and other static assets
- `/src/layouts` - Layout components
- `/src/routes` - Routing configuration

## Getting Started

1. Install dependencies:
```
npm install
```

2. Start the development server:
```
npm run dev
```

3. Build for production:
```
npm run build
```

## Features

- Modern React (React 19)
- Bootstrap 5
- Responsive design
- Reusable components
- React Router v7

## Cleaned Up Features

This project has been cleaned up to remove unnecessary dependencies and files from the original template. The following has been removed:

- Unused pages and demos
- Unnecessary dependencies
- Example pages and templates
- Fake backend configurations

Only the essential components needed for the AIF application have been retained.
